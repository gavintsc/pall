-- PallyPal Market: Auction House prices (Auctionator-style).
-- Price data comes from your own scans and searches. Every buy and post needs
-- your click, like the game requires. Nothing is ever bought or posted on its own.
local ADDON, ns = ...
local UI = ns.UI
local DB

local Market = {}
ns.Market = Market

local function ret(ok, ...) if ok then return ... end end
local function safe(f, ...)
    if not f then return end
    return ret(pcall(f, ...))
end
Market.safe = safe

local function now() return time() end

-- money: 12345 -> "1g 23s 45c" (with the game's coin icons when available)
function Market.Money(c)
    c = math.floor((c or 0) + 0.5)
    if GetCoinTextureString then
        local ok, s = pcall(GetCoinTextureString, c)
        if ok and s then return s end
    end
    local g, s2, cc = math.floor(c / 10000), math.floor(c / 100) % 100, c % 100
    local out = {}
    if g > 0 then table.insert(out, g .. "g") end
    if s2 > 0 then table.insert(out, s2 .. "s") end
    if cc > 0 or #out == 0 then table.insert(out, cc .. "c") end
    return table.concat(out, " ")
end

-- plain text version for typing boxes: 12345 -> "1g 23s 45c"
function Market.MoneyPlain(c)
    c = math.floor((c or 0) + 0.5)
    local g, s2, cc = math.floor(c / 10000), math.floor(c / 100) % 100, c % 100
    local out = {}
    if g > 0 then table.insert(out, g .. "g") end
    if s2 > 0 then table.insert(out, s2 .. "s") end
    if cc > 0 or #out == 0 then table.insert(out, cc .. "c") end
    return table.concat(out, " ")
end

-- "1g 20s", "1.5", "75s", "3000c" -> copper
function Market.ParseMoney(txt)
    if not txt then return nil end
    txt = txt:lower():gsub(",", ".")
    local total, found = 0, false
    for n, u in txt:gmatch("([%d%.]+)%s*([gsc])") do
        local v = tonumber(n)
        if v then
            found = true
            total = total + (u == "g" and v * 10000 or u == "s" and v * 100 or v)
        end
    end
    if not found then
        local v = tonumber(txt:match("^%s*([%d%.]+)%s*$"))
        if v then total, found = v * 10000, true end -- plain number = gold
    end
    return found and math.floor(total + 0.5) or nil
end

function Market.Age(t)
    if not t then return "never" end
    local d = now() - t
    if d < 90 then return "just now" end
    if d < 3600 then return math.floor(d / 60) .. "m ago" end
    if d < 86400 then return math.floor(d / 3600) .. "h ago" end
    return math.floor(d / 86400) .. "d ago"
end

---------------------------------------------------------------------------
-- Price database: DB.prices[itemID] = { p = lowest unit buyout, t = time, n = name }
---------------------------------------------------------------------------
local nameIndex = {}

function Market.Record(itemID, unitPrice, name)
    if not DB or not itemID or not unitPrice or unitPrice <= 0 then return end
    local e = DB.prices[itemID]
    if not e then e = {}; DB.prices[itemID] = e end
    e.p = unitPrice
    e.t = now()
    if name and name ~= "" then e.n = name; nameIndex[name:lower()] = itemID end
end

function Market.Price(itemID)
    local e = DB and DB.prices[itemID]
    if e then return e.p, e.t end
end

function Market.PriceByName(name)
    if not name then return end
    local id = nameIndex[name:lower()]
    if id then return Market.Price(id), id end
end

function Market.Find(text)
    local out = {}
    text = (text or ""):lower()
    if text == "" then return out end
    for id, e in pairs(DB.prices) do
        if e.n and e.n:lower():find(text, 1, true) then table.insert(out, { id = id, n = e.n, p = e.p, t = e.t }) end
    end
    table.sort(out, function(a, b) return a.n < b.n end)
    return out
end

function Market.Count()
    local n = 0
    for _ in pairs(DB.prices) do n = n + 1 end
    return n
end

---------------------------------------------------------------------------
-- Full scan (the game allows one every 15 minutes)
---------------------------------------------------------------------------
Market.scanning = false

function Market.CanScan()
    return AuctionHouseFrame and AuctionHouseFrame:IsShown() and C_AuctionHouse and C_AuctionHouse.ReplicateItems ~= nil
end

function Market.StartScan()
    if not Market.CanScan() then return false, "Open the Auction House first." end
    if DB.lastScan and now() - DB.lastScan < 15 * 60 then
        return false, "The game allows one full scan every 15 minutes. Next one in " .. math.ceil((15 * 60 - (now() - DB.lastScan)) / 60) .. " min."
    end
    Market.scanning = true
    Market.scanProgress = 0
    local ok = pcall(C_AuctionHouse.ReplicateItems)
    if not ok then Market.scanning = false; return false, "The Auction House didn't accept the scan. Try again in a moment." end
    if Market.OnScanChanged then Market.OnScanChanged() end
    return true
end

-- Read the scan gently: work for ~3 ms
-- per frame, then let the frame draw. (The old version did a fixed 1500 per
-- step with a safety wrapper around every single auction, and could run
-- several times at once if the game sent the "scan ready" signal twice.)
local function processScan()
    if Market.processing then return end
    Market.processing = true
    local total = C_AuctionHouse.GetNumReplicateItems() or 0
    local get = C_AuctionHouse.GetReplicateItemInfo
    local best = {}
    local i = 0
    local lastUI = 0
    local function chunk()
        local t0 = debugprofilestop()
        while i < total and debugprofilestop() - t0 < 3 do
            local stop = math.min(total, i + 40)
            for idx = i, stop - 1 do
                local name, _, count, _, _, _, _, _, _, buyout, _, _, _, _, _, _, itemID = get(idx)
                if itemID and buyout and buyout > 0 and count and count > 0 then
                    local unit = buyout / count
                    local b = best[itemID]
                    if not b then best[itemID] = { p = unit, n = name }
                    elseif unit < b.p then b.p = unit; b.n = b.n or name end
                end
            end
            i = stop
        end
    end
    local function step()
        local ok = pcall(chunk)
        if not ok then i = i + 1 end -- skip a bad entry instead of stopping
        Market.scanProgress = total > 0 and i / total or 1
        local t = GetTime()
        if t - lastUI > 0.25 and Market.OnScanChanged then lastUI = t; Market.OnScanChanged() end
        if i < total then
            C_Timer.After(0, step)
        else
            local n = 0
            for id, b in pairs(best) do Market.Record(id, math.floor(b.p + 0.5), b.n); n = n + 1 end
            DB.lastScan = now()
            Market.scanning = false
            Market.processing = false
            if Market.OnScanChanged then Market.OnScanChanged() end
            if ns.Alert then ns.Alert("Scan done: " .. n .. " items priced", "Prices now show on item tooltips.") end
        end
    end
    step()
end

---------------------------------------------------------------------------
-- Vendor + disenchant value, and the "best thing to do" with an item
---------------------------------------------------------------------------
function Market.ItemInfo(item)
    local name, link, quality, ilvl, _, _, _, stack, equipLoc, _, vendor, classID = safe((C_Item and C_Item.GetItemInfo) or GetItemInfo, item)
    return { name = name, link = link, quality = quality, ilvl = ilvl, stack = stack, equipLoc = equipLoc, vendor = vendor or 0, classID = classID }
end

-- Best way to turn an item into gold. Returns kind, value (copper per item)
function Market.BestAction(itemID, link)
    local info = Market.ItemInfo(link or itemID)
    local ah = Market.Price(itemID)
    local ahNet = ah and math.floor(ah * 0.95) or nil -- the auction house keeps 5%
    local de = ns.Disenchant and ns.Disenchant.Value(link or itemID)
    local best, val = "Vendor", info.vendor or 0
    if ahNet and ahNet > val then best, val = "Auction", ahNet end
    if de and de > val then best, val = "Disenchant", de end
    if val <= 0 then return nil end
    return best, val, ah, info.vendor, de
end

---------------------------------------------------------------------------
-- Tooltip lines
---------------------------------------------------------------------------
local function hookTooltip()
    if not (TooltipDataProcessor and Enum and Enum.TooltipDataType and Enum.TooltipDataType.Item) then return end
    local tipCache = setmetatable({}, { __mode = "k" })
    C_Timer.NewTicker(60, function() wipe(tipCache) end)
    TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Item, function(tt, data)
        if not DB or not DB.marketTips or InCombatLockdown() then return end
        if ns.ConflictFor and ns.ConflictFor("marketTips") then return end
        pcall(function()
            local id = data and data.id
            if not id or (issecretvalue and issecretvalue(id)) then return end
            local _, link = tt:GetItem()
            local count = 1
            local owner = tt:GetOwner()
            if owner and owner.count then count = owner.count end
            local key = link or id
            local c = tipCache[key]
            local now = GetTime()
            if not c or now - c.t > 5 then
                local p0, t0 = Market.Price(id)
                local b, v = Market.BestAction(id, link)
                c = { t = now, p = p0, age = t0, info = Market.ItemInfo(key), de = ns.Disenchant and ns.Disenchant.Value(key), best = b, val = v }
                tipCache[key] = c
            end
            local p, t, info, de = c.p, c.age, c.info, c.de
            if not p and not de then return end
            tt:AddLine(" ")
            if p then
                local line = Market.Money(p)
                if count > 1 then line = line .. "  |cff8d8f96(x" .. count .. " = |r" .. Market.Money(p * count) .. "|cff8d8f96)|r" end
                tt:AddDoubleLine("|cfff58cbaAuction|r", line, 1, 1, 1, 1, 1, 1)
                tt:AddDoubleLine(" ", "|cff8d8f96" .. Market.Age(t) .. "|r")
            end
            if de then tt:AddDoubleLine("|cfff58cbaDisenchant|r", "~" .. Market.Money(de), 1, 1, 1, 1, 1, 1) end
            local best, val = c.best, c.val
            if best and (p or de) and info.vendor then
                tt:AddDoubleLine("|cfff58cbaBest|r", "|cff6bdb80" .. best .. "|r  " .. Market.Money(val), 1, 1, 1, 1, 1, 1)
            end
        end)
    end)
end

---------------------------------------------------------------------------
-- Prices window (search your price database anywhere)
---------------------------------------------------------------------------
local pwin
function Market.TogglePrices()
    if not pwin then
        local f = UI.Window("PallyPalPrices", 420, 520, "Prices", "from your Auction House scans")
        local c = f.content
        local s = UI.Search(c, 384, "Search an item you've seen on the Auction House")
        s:SetPoint("TOPLEFT")
        f.info = UI.Text(c, 11, UI.C.muted); f.info:SetPoint("TOPLEFT", s, "BOTTOMLEFT", 2, -10)
        local sf = UI.Scroll(c); sf:SetPoint("TOPLEFT", 0, -64); sf:SetPoint("BOTTOMRIGHT")
        f.rows = {}
        local function paint()
            local list = Market.Find(s:GetText())
            f.info:SetText(Market.Count() .. " items priced  ·  last full scan " .. Market.Age(DB.lastScan))
            for i = 1, math.max(#list, #f.rows) do
                local r = f.rows[i]
                if not r and list[i] then
                    r = CreateFrame("Frame", nil, sf.child); r:SetHeight(30)
                    r:SetPoint("TOPLEFT", 0, -(i - 1) * 32); r:SetPoint("RIGHT")
                    UI.Flat(r, { 1, 1, 1, (i % 2 == 1) and 0.03 or 0 }, { 1, 1, 1, 0 }, "small")
                    r.icon = UI.Icon(r, 20); r.icon:SetPoint("LEFT", 6, 0)
                    r.name = UI.Text(r, 12); r.name:SetPoint("LEFT", r.icon, "RIGHT", 10, 0); r.name:SetWidth(200); r.name:SetWordWrap(false)
                    r.price = UI.Text(r, 12); r.price:SetPoint("RIGHT", -8, 4); r.price:SetJustifyH("RIGHT")
                    r.age = UI.Text(r, 10, UI.C.muted); r.age:SetPoint("TOPRIGHT", r.price, "BOTTOMRIGHT", 0, -1); r.age:SetJustifyH("RIGHT")
                    f.rows[i] = r
                end
                if r then
                    local e = list[i]
                    if e then
                        r.icon:SetIcon(safe(C_Item.GetItemIconByID, e.id) or 134400)
                        r.name:SetText(e.n); r.price:SetText(Market.Money(e.p)); r.age:SetText(Market.Age(e.t)); r:Show()
                    else r:Hide() end
                end
            end
            sf.child:SetHeight(#list * 32 + 4)
        end
        s:HookScript("OnTextChanged", paint)
        f:HookScript("OnShow", paint)
        pwin = f
    end
    pwin:SetShown(not pwin:IsShown())
end

---------------------------------------------------------------------------
-- Passive price capture: every search you (or the game) run updates prices
---------------------------------------------------------------------------
local ev = CreateFrame("Frame")
ev:SetScript("OnEvent", function(_, event, a1, a2)
    if event == "REPLICATE_ITEM_LIST_UPDATE" then
        if Market.scanning then processScan() end
    elseif event == "AUCTION_HOUSE_BROWSE_RESULTS_UPDATED" or event == "AUCTION_HOUSE_BROWSE_RESULTS_ADDED" then
        local results = safe(C_AuctionHouse.GetBrowseResults) or {}
        for _, r in ipairs(results) do
            local id = r.itemKey and r.itemKey.itemID
            if id and r.minPrice and r.minPrice > 0 then
                local info = safe(C_AuctionHouse.GetItemKeyInfo, r.itemKey)
                Market.Record(id, r.minPrice, info and info.itemName)
            end
        end
        if Market.OnBrowse then Market.OnBrowse(results) end
    elseif event == "COMMODITY_SEARCH_RESULTS_UPDATED" then
        local first = safe(C_AuctionHouse.GetCommoditySearchResultInfo, a1, 1)
        if first and first.unitPrice then Market.Record(a1, first.unitPrice, safe(C_Item.GetItemNameByID, a1)) end
        if Market.OnItemSearch then Market.OnItemSearch(a1, true) end
    elseif event == "ITEM_SEARCH_RESULTS_UPDATED" then
        local key = a1
        local first = safe(C_AuctionHouse.GetItemSearchResultInfo, key, 1)
        if key and first and first.buyoutAmount then Market.Record(key.itemID, first.buyoutAmount, safe(C_Item.GetItemNameByID, key.itemID)) end
        if Market.OnItemSearch then Market.OnItemSearch(key and key.itemID, false, key) end
    elseif event == "COMMODITY_PRICE_UPDATED" then
        if Market.OnCommodityPrice then Market.OnCommodityPrice(a1, a2) end
    elseif event == "AUCTION_HOUSE_SHOW" then
        if Market.OnAHShow then Market.OnAHShow() end
    elseif event == "AUCTION_HOUSE_CLOSED" then
        Market.scanning = false
        if Market.OnAHHide then Market.OnAHHide() end
    end
end)

local prevInit = ns.InitLearn
function ns.InitLearn(db)
    if prevInit then prevInit(db) end
    DB = db
    DB.prices = DB.prices or {}
    DB.shop = DB.shop or { "Linen Cloth", "Copper Ore", "Light Leather" }
    if DB.marketTips == nil then DB.marketTips = true end
    if DB.ahPanel == nil then DB.ahPanel = true end
    for id, e in pairs(DB.prices) do if e.n then nameIndex[e.n:lower()] = id end end
    hookTooltip()
    for _, e in ipairs({ "REPLICATE_ITEM_LIST_UPDATE", "AUCTION_HOUSE_BROWSE_RESULTS_UPDATED", "AUCTION_HOUSE_BROWSE_RESULTS_ADDED",
        "COMMODITY_SEARCH_RESULTS_UPDATED", "ITEM_SEARCH_RESULTS_UPDATED", "COMMODITY_PRICE_UPDATED",
        "AUCTION_HOUSE_SHOW", "AUCTION_HOUSE_CLOSED" }) do
        pcall(ev.RegisterEvent, ev, e)
    end
end
