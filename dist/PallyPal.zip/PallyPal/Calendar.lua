-- PallyPal Calendar: copies upcoming world events from the game's own calendar
-- into PallyPal's saved settings, so the PallyPal launcher can show "next world
-- events" outside the game. Read-only: it never changes the calendar.
local ADDON, ns = ...
local DB

local function ret(ok, ...) if ok then return ... end end
local function safe(f, ...)
    if not f then return end
    return ret(pcall(f, ...))
end

local function stamp(t)
    if not t or not t.year then return "" end
    return string.format("%04d-%02d-%02d %02d:%02d", t.year, t.month, t.monthDay, t.hour or 0, t.minute or 0)
end

local function clean(s) return (tostring(s or ""):gsub("[|;\n\r]", " ")) end

local function snapshot()
    if not DB or not (C_Calendar and C_Calendar.GetNumDayEvents) then return end
    local seen, list = {}, {}
    local today = safe(C_DateAndTime and C_DateAndTime.GetCurrentCalendarTime)
    if not today then return end
    for offset = 0, 1 do
        local info = safe(C_Calendar.GetMonthInfo, offset)
        local days = info and info.numDays or 31
        local startDay = offset == 0 and today.monthDay or 1
        for day = startDay, days do
            for i = 1, (safe(C_Calendar.GetNumDayEvents, offset, day) or 0) do
                local e = safe(C_Calendar.GetDayEvent, offset, day, i)
                if e and e.title and (e.calendarType == "HOLIDAY" or e.calendarType == "RAID_RESET" or e.calendarType == "SYSTEM") then
                    local key = e.title .. stamp(e.startTime)
                    if not seen[key] then
                        seen[key] = true
                        table.insert(list, clean(e.title) .. "|" .. stamp(e.startTime) .. "|" .. stamp(e.endTime) .. "|" .. clean(e.calendarType))
                    end
                end
            end
        end
    end
    DB.calendarText = table.concat(list, ";")
    DB.calendarAt = time()
end

local pending
local ev = CreateFrame("Frame")
ev:SetScript("OnEvent", function(_, event)
    if event == "PLAYER_ENTERING_WORLD" then
        C_Timer.After(8, function() safe(C_Calendar and C_Calendar.OpenCalendar) end) -- asks the server for this month
        return
    end
    if pending then return end
    pending = true
    C_Timer.After(2, function() pending = false; if not InCombatLockdown() then snapshot() end end)
end)

local prevInit = ns.InitLearn
function ns.InitLearn(db)
    if prevInit then prevInit(db) end
    DB = db
    for _, e in ipairs({ "PLAYER_ENTERING_WORLD", "CALENDAR_UPDATE_EVENT_LIST" }) do pcall(ev.RegisterEvent, ev, e) end
end
