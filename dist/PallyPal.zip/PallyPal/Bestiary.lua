-- PallyPal Bestiary: builds an index of every mob you loot and what it dropped.
-- Drop rates are YOUR rates: (times an item dropped) / (corpses of that mob you looted).
local ADDON, ns = ...
local PREFIX = "|cfff58cbaPallyPal|r: "
local function say(msg, important) if ns.say then ns.say(msg, important) else print(PREFIX .. msg) end end
local DB
local seenCorpse = {} -- this session only, prevents double counting a corpse

---------------------------------------------------------------------------
-- Helpers
---------------------------------------------------------------------------
local function npcFromGUID(guid)
    if type(guid) ~= "string" then return end
    local kind, _, _, _, _, id = strsplit("-", guid)
    if kind == "Creature" or kind == "Vehicle" then return tonumber(id) end
end

local function mob(id)
    local m = DB.mobs[id]
    if not m then
        m = { name = "Unknown #" .. id, looted = 0, money = 0, items = {} }
        DB.mobs[id] = m
    end
    return m
end

local lastSeen = {}
local function cacheUnit(unit)
    if InCombatLockdown() then return end
    local guid = UnitGUID(unit)
    if not guid or (issecretvalue and issecretvalue(guid)) then return end
    local now = GetTime()
    if lastSeen[guid] and now - lastSeen[guid] < 10 then return end
    lastSeen[guid] = now
    pcall(function()
        if not UnitExists(unit) or UnitIsPlayer(unit) then return end
        local id = npcFromGUID(UnitGUID(unit))
        if not id then return end
        local name = UnitName(unit)
        if not name then return end
        local m = DB.mobs[id]
        if not m then
            -- only remember mobs you could actually fight
            if not UnitCanAttack("player", unit) then return end
            m = mob(id)
        end
        m.name = name
        local lvl = UnitLevel(unit)
        if lvl and lvl > 0 then
            m.minLvl = math.min(m.minLvl or lvl, lvl)
            m.maxLvl = math.max(m.maxLvl or lvl, lvl)
        end
        local zone = GetZoneText()
        if zone and zone ~= "" then m.zone = zone end
        local c = UnitClassification(unit)
        if c == "elite" or c == "rareelite" or c == "rare" or c == "worldboss" then m.class = c end
        local ct = UnitCreatureType and UnitCreatureType(unit)
        if ct and not (issecretvalue and issecretvalue(ct)) then m.ctype = ct end
        -- does it use mana? then it casts spells
        local pmax = UnitPowerMax(unit, 0)
        if pmax and not (issecretvalue and issecretvalue(pmax)) and pmax > 0 and UnitPowerType(unit) == 0 then m.caster = true end
        -- which of your quests the game says this mob is part of (from its tooltip)
        if C_TooltipInfo and C_TooltipInfo.GetUnit then
            local data = C_TooltipInfo.GetUnit(unit)
            local T = Enum.TooltipDataLineType or {}
            for _, line in ipairs(data and data.lines or {}) do
                local txt = line.leftText
                if txt and not (issecretvalue and issecretvalue(txt)) and (line.type == T.QuestTitle or line.type == T.QuestObjective) then
                    m.quests = m.quests or {}
                    if line.type == T.QuestTitle then m.quests[txt] = true end
                end
            end
        end
    end)
end

-- Mobs that matter for one of your quests, described in plain words.
-- Matches: the mob's tooltip named this quest, a "X slain" objective, or the mob dropped an item the quest wants.
function ns.MobsForQuest(title, objectives)
    if not DB or not DB.mobs then return {} end
    local wantKill, wantItem = {}, {}
    for _, o in ipairs(objectives or {}) do
        local t = o.text or ""
        local k = t:match("^(.-) slain") or t:match("^Kill (.-):") or (o.type == "monster" and t:match("^(.-):"))
        if k then wantKill[k] = true end
        local it = t:match("^(.-):%s*%d+/%d+")
        if it and not k then wantItem[it] = true end
    end
    local me = UnitLevel("player")
    local out = {}
    for id, m in pairs(DB.mobs) do
        local why, rate
        if m.quests and m.quests[title] then why = "quest" end
        if wantKill[m.name] then why = "kill" end
        for itemID, it in pairs(m.items or {}) do
            local nm = it.link and it.link:match("%[(.-)%]")
            if nm and wantItem[nm] then why = why or "drop"; rate = (m.looted > 0) and math.floor(it.count / m.looted * 100 + 0.5) or nil end
        end
        if why then
            local parts = { "|cffffffff" .. m.name .. "|r" }
            if m.ctype then table.insert(parts, m.ctype) end
            if m.minLvl then table.insert(parts, "level " .. (m.minLvl == m.maxLvl and m.minLvl or (m.minLvl .. "-" .. m.maxLvl))) end
            if m.zone then table.insert(parts, m.zone) end
            local line = table.concat(parts, "  \194\183  ")
            local notes = {}
            if rate then table.insert(notes, "drops it about " .. rate .. "% of the time") end
            local diff = m.maxLvl and (m.maxLvl - me) or 0
            if m.class == "elite" or m.class == "rareelite" or m.class == "worldboss" then table.insert(notes, "|cffffd36belite, bring a group|r")
            elseif diff >= 3 then table.insert(notes, "|cffff8a8ahigher level than you, pull one at a time|r")
            elseif diff <= -4 then table.insert(notes, "|cff8fd89feasy for you|r") end
            if m.caster then table.insert(notes, "casts spells: fight it up close so it can't cast freely") end
            if m.ctype == "Undead" then table.insert(notes, "Undead: Exorcism and Holy damage hit it hard") end
            if m.ctype == "Beast" and not m.caster then table.insert(notes, "melee only, easy to tank") end
            table.insert(out, { line = line, notes = table.concat(notes, ", "), why = why })
        end
    end
    table.sort(out, function(a, b) return a.line < b.line end)
    return out
end

local function pct(n, d)
    if d == 0 then return 0 end
    return math.floor(n / d * 1000 + 0.5) / 10
end

local function lvlText(m)
    if not m.minLvl then return "?" end
    if m.minLvl == m.maxLvl then return tostring(m.minLvl) end
    return m.minLvl .. "-" .. m.maxLvl
end

local function sortedDrops(m)
    local list = {}
    for itemID, it in pairs(m.items) do
        table.insert(list, { id = itemID, count = it.count, qty = it.qty, link = it.link })
    end
    table.sort(list, function(a, b) return a.count > b.count end)
    return list
end

---------------------------------------------------------------------------
-- Loot recording
---------------------------------------------------------------------------
local function onLootOpened()
    pcall(cacheUnit, "target")
    local newCorpses = {}
    for slot = 1, GetNumLootItems() do
        local sources = { GetLootSourceInfo(slot) }
        local slotType = GetLootSlotType(slot)
        local link = GetLootSlotLink(slot)
        local _, _, slotQty = GetLootSlotInfo(slot)
        for i = 1, #sources, 2 do
            local guid, qty = sources[i], sources[i + 1]
            local id = npcFromGUID(guid)
            if id and not seenCorpse[guid] then
                newCorpses[guid] = id
                local m = mob(id)
                if slotType == Enum.LootSlotType.Money then
                    m.money = m.money + (qty or 0)
                elseif link then
                    local itemID = C_Item.GetItemInfoInstant(link)
                    if itemID then
                        local it = m.items[itemID] or { count = 0, qty = 0 }
                        it.count = it.count + 1
                        it.qty = it.qty + (qty or slotQty or 1)
                        it.link = link:match("|H(item:[^|]+)|h") and link or it.link
                        m.items[itemID] = it
                    end
                end
            end
        end
    end
    for guid, id in pairs(newCorpses) do
        seenCorpse[guid] = true
        local m = mob(id)
        m.looted = m.looted + 1
        m.last = time()
        if not m.zone then m.zone = GetZoneText() end
    end
    if ns.RefreshIndex then ns.RefreshIndex() end
end

---------------------------------------------------------------------------
-- Mob tooltip: your stats for that mob
---------------------------------------------------------------------------
local function hookUnitTooltip()
    if not (TooltipDataProcessor and Enum and Enum.TooltipDataType) then return end
    TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Unit, function(tooltip, data)
        if not DB or not DB.bestiaryTips then return end
        pcall(function()
            local id = npcFromGUID(data and data.guid)
            local m = id and DB.mobs[id]
            if not m or m.looted == 0 then return end
            tooltip:AddLine(" ")
            tooltip:AddLine("|cfff58cbaPallyPal|r  looted " .. m.looted .. "x", 1, 1, 1)
            local drops = sortedDrops(m)
            for i = 1, math.min(3, #drops) do
                local d = drops[i]
                tooltip:AddDoubleLine(d.link or ("item:" .. d.id), pct(d.count, m.looted) .. "%", 1, 1, 1, 0.55, 1, 0.55)
            end
        end)
    end)
end

---------------------------------------------------------------------------
-- Index window (/pal index)
---------------------------------------------------------------------------
local win, listButtons, selected = nil, {}, nil
local ROW_H, ROWS = 18, 20

local function matches(m, q)
    if q == "" then return true end
    if m.name:lower():find(q, 1, true) then return true end
    if m.zone and m.zone:lower():find(q, 1, true) then return true end
    for _, it in pairs(m.items) do
        local name = it.link and it.link:match("%[(.-)%]")
        if name and name:lower():find(q, 1, true) then return true end
    end
end

local function filtered()
    local q = (win.search:GetText() or ""):lower()
    local out = {}
    for id, m in pairs(DB.mobs) do
        if m.looted > 0 and matches(m, q) then table.insert(out, id) end
    end
    local sortBy = DB.indexSort or "name"
    table.sort(out, function(a, b)
        local A, B = DB.mobs[a], DB.mobs[b]
        if sortBy == "looted" then return A.looted > B.looted end
        if sortBy == "level" then return (A.minLvl or 0) < (B.minLvl or 0) end
        return A.name < B.name
    end)
    return out
end

local dropRows = {}
local function linkScripts(fr)
    pcall(fr.SetHyperlinksEnabled, fr, true)
    fr:SetScript("OnHyperlinkEnter", function(self, link)
        GameTooltip:SetOwner(self, "ANCHOR_CURSOR")
        pcall(GameTooltip.SetHyperlink, GameTooltip, link)
        GameTooltip:Show()
    end)
    fr:SetScript("OnHyperlinkLeave", function() GameTooltip:Hide() end)
    fr:SetScript("OnHyperlinkClick", function(_, link, text)
        if IsModifiedClick("CHATLINK") then ChatEdit_InsertLink(text) end
    end)
end

local function getDropRow(i)
    local r = dropRows[i]
    if r then return r end
    r = CreateFrame("Frame", nil, win.detailChild)
    r:SetSize(360, 20)
    local bg = r:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetColorTexture(1, 1, 1, (i % 2 == 0) and 0.015 or 0.035)
    r.bar = r:CreateTexture(nil, "BORDER")
    r.bar:SetPoint("TOPLEFT", 0, 0)
    r.bar:SetPoint("BOTTOMLEFT", 0, 0)
    r.bar:SetColorTexture(0.96, 0.55, 0.73, 0.18)
    r.pct = ns.UI.Text(r, 11)
    r.pct:SetPoint("LEFT", 4, 0)
    r.pct:SetWidth(46)
    r.pct:SetJustifyH("RIGHT")
    r.item = ns.UI.Text(r, 11)
    r.item:SetPoint("LEFT", r.pct, "RIGHT", 10, 0)
    r.item:SetPoint("RIGHT", -6, 0)
    r.item:SetJustifyH("LEFT")
    r.item:SetWordWrap(false)
    linkScripts(r)
    dropRows[i] = r
    return r
end

local function showDetail(id)
    selected = id
    for _, r in ipairs(dropRows) do r:Hide() end
    local m = DB.mobs[id]
    if not m then win.detail:SetText("Pick a mob on the left.") return end
    local lines = {}
    local tag = m.class and (" |cffffaa00" .. m.class:upper() .. "|r") or ""
    table.insert(lines, "|cffffd100" .. m.name .. "|r" .. tag)
    table.insert(lines, "|cffaaaaaaLevel|r " .. lvlText(m) .. "    |cffaaaaaaZone|r " .. (m.zone or "Unknown"))
    local goldTxt = m.money > 0 and ("    |cffaaaaaaAvg gold|r " .. ((ns.Market and ns.Market.Money) and ns.Market.Money(math.floor(m.money / m.looted)) or (math.floor(m.money / m.looted) .. "c"))) or ""
    table.insert(lines, "|cffaaaaaaLooted|r " .. m.looted .. "x" .. goldTxt)
    table.insert(lines, " ")
    table.insert(lines, "|cfff58cbaDROPS|r  |cff888888your drop rate|r")
    win.detail:SetText(table.concat(lines, "\n"))

    local y = win.detail:GetStringHeight() + 12
    local drops = sortedDrops(m)
    for i, d in ipairs(drops) do
        local r = getDropRow(i)
        local p = pct(d.count, m.looted)
        r:ClearAllPoints()
        r:SetPoint("TOPLEFT", 4, -y)
        r.bar:SetWidth(math.max(1, 360 * math.min(p, 100) / 100))
        r.pct:SetText("|cff55ff55" .. string.format("%.1f%%", p) .. "|r")
        local avg = d.qty > d.count and ("  |cff888888x" .. string.format("%.1f", d.qty / d.count) .. "|r") or ""
        r.item:SetText((d.link or ("item:" .. d.id)) .. avg)
        r:Show()
        y = y + 21
    end
    win.note:ClearAllPoints()
    win.note:SetPoint("TOPLEFT", 6, -(y + 8))
    if #drops == 0 then
        win.note:SetText("|cff888888No items yet.|r")
    elseif m.looted < 10 then
        win.note:SetText("|cff888888Small sample. Rates get accurate after ~20+ kills.|r")
    else
        win.note:SetText("")
    end
    win.detailChild:SetHeight(y + 40)
end

local function refreshList()
    if not win or not win:IsShown() then return end
    local ids = filtered()
    win.ids = ids
    local offset = win.offset or 0
    local maxOffset = math.max(0, #ids - ROWS)
    if offset > maxOffset then offset = maxOffset; win.offset = offset end
    for i = 1, ROWS do
        local b = listButtons[i]
        local id = ids[i + offset]
        if id then
            local m = DB.mobs[id]
            b.id = id
            b.text:SetText((id == selected and "|cfff58cba|||r " or "") .. "|cffffd100" .. lvlText(m) .. "|r  " .. m.name ..
                "  |cff8d8f96" .. m.looted .. "x|r")
            b:Show()
        else
            b:Hide()
        end
    end
    win.count:SetText(#ids .. " mobs")
    if selected then showDetail(selected) end
end
ns.RefreshIndex = refreshList

local function toggleIndex()
    if not win then
        local UI = ns.UI
        local f = UI.Window("PallyPalIndex", 680, 480, "Bestiary", "mobs you've looted")
        local c = f.content

        -- left column
        local s = UI.Search(c, 250, "Search mob, zone or item")
        s:SetPoint("TOPLEFT", 0, 0)
        s:HookScript("OnTextChanged", function() f.offset = 0; refreshList() end)
        f.search = s

        f.count = UI.Text(c, 11, UI.C.muted)
        f.count:SetPoint("TOPLEFT", s, "BOTTOMLEFT", 2, -8)

        local sort = UI.Button(c, 84, 20, "Sort: Name")
        sort.label:SetFont(STANDARD_TEXT_FONT, 11, "")
        sort:SetPoint("TOPRIGHT", s, "BOTTOMRIGHT", 0, -4)
        sort:SetScript("OnClick", function(self)
            local order = { name = "looted", looted = "level", level = "name" }
            DB.indexSort = order[DB.indexSort or "name"]
            local label = { name = "Name", looted = "Looted", level = "Level" }
            self:SetText("Sort: " .. label[DB.indexSort])
            refreshList()
        end)

        local list = CreateFrame("Frame", nil, c)
        list:SetPoint("TOPLEFT", 0, -58)
        list:SetSize(250, ROW_H * ROWS)
        list:EnableMouseWheel(true)
        list:SetScript("OnMouseWheel", function(_, delta)
            f.offset = math.max(0, (f.offset or 0) - delta * 3)
            refreshList()
        end)
        for i = 1, ROWS do
            local b = CreateFrame("Button", nil, list)
            b:SetSize(250, ROW_H)
            b:SetPoint("TOPLEFT", 0, -(i - 1) * ROW_H)
            local rbg = b:CreateTexture(nil, "BACKGROUND")
            rbg:SetAllPoints()
            rbg:SetColorTexture(1, 1, 1, (i % 2 == 0) and 0.0 or 0.025)
            local hl = b:CreateTexture(nil, "HIGHLIGHT")
            hl:SetAllPoints(); hl:SetColorTexture(0.96, 0.55, 0.73, 0.10)
            b.text = UI.Text(b, 11)
            b.text:SetPoint("LEFT", 8, 0)
            b.text:SetPoint("RIGHT", -6, 0)
            b.text:SetWordWrap(false)
            b:SetScript("OnClick", function(self) showDetail(self.id); refreshList() end)
            listButtons[i] = b
        end

        -- divider between columns
        local vline = c:CreateTexture(nil, "ARTWORK")
        vline:SetColorTexture(unpack(UI.C.line))
        vline:SetPoint("TOPLEFT", 264, 0); vline:SetPoint("BOTTOMLEFT", 264, 0); vline:SetWidth(1)

        -- detail pane (scroll with mouse wheel, item links hoverable)
        local sf = UI.Scroll(c)
        sf:SetPoint("TOPLEFT", 280, 0)
        sf:SetPoint("BOTTOMRIGHT", 0, 0)
        local child = sf.child
        child:SetSize(370, 400)
        local note = UI.Text(child, 11, UI.C.muted)
        note:SetWidth(360)
        f.note = note
        local d = UI.Text(child, 12)
        d:SetPoint("TOPLEFT", 2, -2)
        d:SetWidth(360)
        d:SetSpacing(4)
        d:SetText("Pick a mob on the left.\n\n|cff8d8f96Nothing here yet? Kill and loot some mobs. Every corpse you loot gets recorded.|r")
        f.detail, f.detailChild = d, child

        f:HookScript("OnShow", refreshList)
        win = f
    end
    win:SetShown(not win:IsShown())
end
ns.ToggleIndex = function() toggleIndex() end

---------------------------------------------------------------------------
-- Slash commands + init
---------------------------------------------------------------------------
local prevSlash = ns.HandleSlash
function ns.HandleSlash(msg)
    if msg == "index" or msg == "bestiary" or msg == "drops" then
        toggleIndex(); return true
    elseif msg == "mobtips" then
        DB.bestiaryTips = not DB.bestiaryTips
        say("Mob tooltip drops " .. (DB.bestiaryTips and "|cff55ff55on|r" or "|cffff5555off|r")); return true
    elseif msg == "resetindex" then
        DB.mobs = {}; wipe(seenCorpse); selected = nil; refreshList(); say("Bestiary wiped."); return true
    end
    return prevSlash and prevSlash(msg) or false
end

local ev = CreateFrame("Frame")
ev:SetScript("OnEvent", function(_, event, unit)
    if event == "LOOT_OPENED" then
        onLootOpened()
    elseif event == "PLAYER_TARGET_CHANGED" then
        cacheUnit("target")
    elseif event == "UPDATE_MOUSEOVER_UNIT" then
        cacheUnit("mouseover")
    elseif event == "NAME_PLATE_UNIT_ADDED" then
        cacheUnit(unit)
    end
end)

local prevInit = ns.InitLearn
function ns.InitLearn(db)
    if prevInit then prevInit(db) end
    DB = db
    DB.mobs = DB.mobs or {}
    if DB.bestiaryTips == nil then DB.bestiaryTips = true end
    hookUnitTooltip()
    for _, e in ipairs({ "LOOT_OPENED", "PLAYER_TARGET_CHANGED", "UPDATE_MOUSEOVER_UNIT", "NAME_PLATE_UNIT_ADDED" }) do
        pcall(ev.RegisterEvent, ev, e)
    end
end
