-- PallyPal To-do: a small panel (top left by default) with the most important
-- things to do right now. Click a line to open the matching PallyPal page.
-- It hides itself during combat and when there's nothing to do.
local ADDON, ns = ...
local UI = ns.UI
local DB

local MAX = 5
local panel, rows = nil, {}

local function ret(ok, ...) if ok then return ... end end
local function safe(f, ...)
    if not f then return end
    return ret(pcall(f, ...))
end

local function knows(name) local i = safe(C_Spell.GetSpellInfo, name) return i ~= nil end

local function lowestDurability()
    local lowest = 1
    for slot = 1, 18 do
        local cur, max = GetInventoryItemDurability(slot)
        if cur and max and max > 0 then lowest = math.min(lowest, cur / max) end
    end
    return lowest
end

local function freeBagSlots()
    if not (C_Container and C_Container.GetContainerNumFreeSlots) then return nil end
    local free, total = 0, 0
    for bag = 0, (NUM_BAG_SLOTS or 4) do
        free = free + (safe(C_Container.GetContainerNumFreeSlots, bag) or 0)
        total = total + (safe(C_Container.GetContainerNumSlots, bag) or 0)
    end
    if total == 0 then return nil end
    return free
end

local function hasShield()
    local id = GetInventoryItemID("player", 17)
    if not id then return false end
    local _, _, _, _, _, classID, subID = safe(C_Item.GetItemInfoInstant, id)
    return classID == 4 and subID == 6
end

-- Build the list, most important first. Each item: icon, text, sub, onClick
local function collect()
    local items = {}
    local level = UnitLevel("player")
    local function add(icon, text, sub, onClick) table.insert(items, { icon = icon, text = text, sub = sub, click = onClick }) end

    -- 1. Quests ready to turn in (free XP)
    local ranked = ns.RankQuests and ns.RankQuests() or {}
    local ready = {}
    for _, q in ipairs(ranked) do if q.why == "Ready to turn in" then table.insert(ready, q) end end
    if #ready > 0 then
        add("Interface\\GossipFrame\\ActiveQuestIcon", "Turn in " .. #ready .. (#ready == 1 and " quest" or " quests"),
            ready[1].title, ns.ToggleQuests)
    end

    -- 2. Unspent talent points
    local pts = safe(UnitCharacterPoints, "player")
    if pts and pts > 0 then
        add("Interface\\Icons\\INV_Misc_Book_11", "Spend " .. pts .. " talent point" .. (pts > 1 and "s" or ""),
            DB.goal == "tank" and "Press N. Retribution first, then Protection." or "Press N", ns.ToggleTank)
    end

    -- 3. Tank setup at level 10+
    if DB.goal == "tank" and level >= 10 then
        if not knows("Seal of Fury") or not knows("Righteous Fury") then
            add(UI.SpellIcon("Seal of Fury", "Spell_Holy_SealOfFury"), "Train your tank spells", "Seal of Fury + Righteous Fury at the trainer", ns.ToggleTank)
        elseif not hasShield() then
            add("Interface\\Icons\\INV_Shield_06", "Equip a shield", "Tanks need a one-hander + shield", ns.ToggleTank)
        end
    end

    -- 4. New spells at the trainer
    if level % 2 == 0 and (DB.trainerLevel or 0) < level and level > 1 then
        add("Interface\\Icons\\INV_Misc_Book_09", "Visit your class trainer", "New spells and ranks at level " .. level, nil)
    end

    -- 5. Repairs
    local dura = lowestDurability()
    if dura < 0.5 then
        add("Interface\\Icons\\Trade_BlackSmithing", "Repair your gear", math.floor(dura * 100) .. "% durability left", nil)
    end

    -- 6. Bags
    local free = freeBagSlots()
    if free and free <= 3 then
        add("Interface\\Icons\\INV_Misc_Bag_08", "Bags almost full", free .. " free. Sell greys at a vendor.", nil)
    end

    -- 6b. Things to disenchant (enchanters only)
    if ns.Disenchant and ns.Disenchant.CanDisenchant() then
        local n = #ns.Disenchant.List()
        if n > 0 then add("Interface\\Icons\\INV_Enchant_Disenchant", "Disenchant " .. n .. (n == 1 and " item" or " items"), "One click each", ns.ToggleDisenchant) end
    end

    -- 6c. Professions: pick them, train the next rank
    for _, p in ipairs(ns.ProfessionTodo and ns.ProfessionTodo() or {}) do
        add("Interface\\Icons\\Trade_BlackSmithing", p.text, p.sub, ns.ToggleProfessions)
    end

    -- 7. Top quest you're working on
    for _, q in ipairs(ranked) do
        if q.why ~= "Ready to turn in" and q.why ~= "Too hard for now" and q.why ~= "Needs a group" and q.why ~= "Low XP now" then
            add("Interface\\GossipFrame\\AvailableQuestIcon", q.title, q.why ~= "Not started" and q.why or "Next quest", ns.ToggleQuests)
            break
        end
    end

    -- 8. Next lesson
    if DB.coach and ns.NextLesson then
        local n = ns.NextLesson()
        if n then add("Interface\\Icons\\INV_Misc_Book_08", n.text, "Lesson", ns.ToggleLessons) end
    end
    return items
end

---------------------------------------------------------------------------
-- Panel
---------------------------------------------------------------------------
local function makeRow(i)
    local r = CreateFrame("Button", nil, panel)
    r:SetHeight(36)
    r:SetPoint("TOPLEFT", 8, -34 - (i - 1) * 38)
    r:SetPoint("RIGHT", -8, 0)
    local hl = r:CreateTexture(nil, "BACKGROUND")
    hl:SetAllPoints()
    hl:SetTexture(UI.MEDIA .. "r6_fill")
    if hl.SetTextureSliceMargins then hl:SetTextureSliceMargins(8, 8, 8, 8) end
    hl:SetVertexColor(1, 1, 1, 0)
    r:SetScript("OnEnter", function() hl:SetVertexColor(1, 1, 1, 0.05) end)
    r:SetScript("OnLeave", function() hl:SetVertexColor(1, 1, 1, 0) end)
    r.icon = UI.Icon(r, 24)
    r.icon:SetPoint("LEFT", 6, 0)
    r.text = UI.Title(r, 12)
    r.text:SetPoint("TOPLEFT", r.icon, "TOPRIGHT", 10, 1)
    r.text:SetPoint("RIGHT", -6, 0)
    r.text:SetWordWrap(false)
    r.sub = UI.Text(r, 10, UI.C.muted)
    r.sub:SetPoint("TOPLEFT", r.text, "BOTTOMLEFT", 0, -2)
    r.sub:SetPoint("RIGHT", -6, 0)
    r.sub:SetWordWrap(false)
    rows[i] = r
    return r
end

local function refresh()
    if not panel or not DB then return end
    if not DB.todo or InCombatLockdown() then
        if not UI.IsEditing() then panel:Hide() end
        return
    end
    local items = collect()
    local n = math.min(#items, MAX)
    for i = 1, MAX do
        local r = rows[i] or makeRow(i)
        local it = items[i]
        if it and not DB.todoCollapsed then
            r.icon:SetIcon(it.icon)
            r.text:SetText(it.text)
            r.sub:SetText(it.sub or "")
            r:SetScript("OnClick", function() if it.click then it.click() end end)
            r:Show()
        else
            r:Hide()
        end
    end
    panel.count:SetText(#items > 0 and tostring(#items) or "")
    panel.countBg:SetShown(#items > 0)
    panel.chev:SetText(DB.todoCollapsed and "+" or "–")
    if DB.todoCollapsed or n == 0 then
        panel:SetHeight(36)
    else
        panel:SetHeight(40 + n * 38)
    end
    panel:SetShown(n > 0 or UI.IsEditing())
    if n == 0 and not UI.IsEditing() then panel:Hide() end
end
ns.RefreshTodo = refresh
ns.TodoItems = function() return collect() end

local function build()
    panel = CreateFrame("Frame", "PallyPalTodo", UIParent)
    panel:SetSize(250, 36)
    panel:SetFrameStrata("LOW")
    UI.Flat(panel, { 0.063, 0.067, 0.082, 0.86 }, UI.C.line2, "panel")
    UI.Shadow(panel, 18, 0.55)
    local g = panel:CreateTexture(nil, "ARTWORK")
    g:SetTexture(UI.MEDIA .. "ghost")
    g:SetSize(16, 16)
    g:SetPoint("TOPLEFT", 12, -10)
    local t = UI.Title(panel, 12)
    t:SetPoint("LEFT", g, "RIGHT", 7, 0)
    t:SetText("To do")
    panel.countBg = panel:CreateTexture(nil, "ARTWORK")
    panel.countBg:SetTexture(UI.MEDIA .. "pill_fill")
    panel.countBg:SetVertexColor(0.96, 0.55, 0.73, 0.18)
    panel.countBg:SetSize(22, 16)
    panel.countBg:SetPoint("LEFT", t, "RIGHT", 7, 0)
    panel.count = UI.Title(panel, 10, UI.C.head)
    panel.count:SetPoint("CENTER", panel.countBg, "CENTER", 0, 0)
    local col = CreateFrame("Button", nil, panel)
    col:SetSize(22, 22)
    col:SetPoint("TOPRIGHT", -8, -7)
    panel.chev = UI.Title(col, 13, UI.C.muted)
    panel.chev:SetPoint("CENTER")
    col:SetScript("OnClick", function() DB.todoCollapsed = not DB.todoCollapsed; refresh() end)
    col:SetScript("OnEnter", function() panel.chev:SetTextColor(1, 1, 1) end)
    col:SetScript("OnLeave", function() panel.chev:SetTextColor(unpack(UI.C.muted)) end)
    panel:Hide()
    UI.RegisterMover(panel, "todo", "To do", { "TOPLEFT", "TOPLEFT", 20, -20 }, function(on)
        if on then panel:Show() else refresh() end
    end)
end

---------------------------------------------------------------------------
-- Events: refresh when things change, plus a slow tick for distance etc.
---------------------------------------------------------------------------
local pending = false
local function soon()
    if pending then return end
    pending = true
    C_Timer.After(1.5, function() pending = false; refresh() end)
end

local ev = CreateFrame("Frame")
ev:SetScript("OnEvent", function(_, event)
    if event == "PLAYER_REGEN_DISABLED" then
        if panel and not UI.IsEditing() then panel:Hide() end
    elseif event == "TRAINER_SHOW" then
        DB.trainerLevel = UnitLevel("player")
        soon()
    else
        soon()
    end
end)

local prevInit = ns.InitLearn
function ns.InitLearn(db)
    if prevInit then prevInit(db) end
    DB = db
    if DB.todo == nil then DB.todo = true end
    build()
    if ns.DB then UI.RestorePos(panel, "todo", { "TOPLEFT", "TOPLEFT", 20, -20 }) end
    for _, e in ipairs({ "PLAYER_ENTERING_WORLD", "PLAYER_REGEN_DISABLED", "PLAYER_REGEN_ENABLED", "QUEST_LOG_UPDATE",
        "QUEST_ACCEPTED", "QUEST_TURNED_IN", "PLAYER_LEVEL_UP", "UPDATE_INVENTORY_DURABILITY", "BAG_UPDATE_DELAYED",
        "CHARACTER_POINTS_CHANGED", "PLAYER_TALENT_UPDATE", "TRAINER_SHOW", "SPELLS_CHANGED", "PLAYER_EQUIPMENT_CHANGED" }) do
        pcall(ev.RegisterEvent, ev, e)
    end
    C_Timer.NewTicker(15, function() if not InCombatLockdown() then refresh() end end)
    C_Timer.After(4, refresh)
end
