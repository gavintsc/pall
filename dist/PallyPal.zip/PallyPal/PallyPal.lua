-- PallyPal: beginner QoL helper for Undead Paladins in WoW Forever
-- Everything that reads auras/health runs OUT of combat only, because
-- Forever hides those values from addons during combat.

local ADDON, ns = ...
local PREFIX = "|cfff58cbaPallyPal|r: "

local DEFAULTS = {
    sellGrey   = true,  -- auto-sell grey items at vendors
    repair     = true,  -- auto-repair at vendors
    guildRepair = false,-- use guild bank funds first
    buffs      = true,  -- missing Aura / Blessing reminder box
    tips       = true,  -- after-combat tips (low HP / low mana)
    durability = true,  -- low durability warning
    trainer    = true,  -- level-up trainer reminder
    locked     = true,  -- reminder box locked in place
    coach      = true,  -- explain new spells + lessons
    tooltips   = true,  -- beginner notes on spell tooltips
    quiet      = false, -- fewer chat messages (use toasts instead)
    hideResting = false,-- hide the buff reminder in towns/inns
}

-- Other addons that already do a job. If one is loaded, PallyPal steps aside
-- for that job so the two never fight (e.g. both trying to sell the same item).
local CONFLICTS = {
    sellGrey = { "Leatrix_Plus", "Scrap", "AutoSellJunk", "Vendorer", "ForeverPlus" },
    repair   = { "Leatrix_Plus", "AutoRepair", "ForeverPlus" },
    mapQuests = { "Questie" },
    sortQuests = { "Questie" }, -- Questie runs its own quest tracker; don't reorder it -- Questie already marks quest givers and turn-ins
    buffs    = { "PallyPower", "PPForever", "PP_Forever", "NyteLytesPaladinToolkit" },
    -- other auction addons already put prices on tooltips
    marketTips = { "Auctionator", "TradeSkillMaster", "Hammerprice", "AHledger", "auxForever", "aux-addon", "Auctioneer" },
}
local function loaded(name)
    local f = (C_AddOns and C_AddOns.IsAddOnLoaded) or IsAddOnLoaded
    local ok, r = pcall(f, name)
    return ok and r
end
function ns.ConflictFor(key)
    for _, n in ipairs(CONFLICTS[key] or {}) do
        if loaded(n) then return n end
    end
end

local function db() return PallyPalDB end
local function say(msg, important)
    if db() and db().quiet and not important then return end
    print(PREFIX .. msg)
end
ns.say = say

-- Important one-off alerts: a small PallyPal toast (never the raid warning area)
local function bigAlert(msg, sub)
    if ns.UI then ns.UI.Toast(msg, sub) end
    say(msg .. (sub and (" " .. sub) or ""))
end
ns.Alert = bigAlert

local function money(c)
    if GetCoinTextureString then return GetCoinTextureString(c) end
    return tostring(c) .. "c"
end

---------------------------------------------------------------------------
-- Spell knowledge helpers (name based, so it works with any spell rank)
---------------------------------------------------------------------------
local function knows(name)
    local ok, info = pcall(C_Spell.GetSpellInfo, name)
    return ok and info ~= nil
end

local AURAS = { "Devotion Aura", "Retribution Aura", "Concentration Aura",
    "Shadow Resistance Aura", "Frost Resistance Aura", "Fire Resistance Aura" }
local BLESSINGS = { "Blessing of Kings", "Blessing of Might", "Blessing of Wisdom", "Blessing of Light" }

local function knowsAny(list)
    for _, n in ipairs(list) do
        if knows(n) then return n end
    end
end

-- Returns hasAura, hasBlessing (or nil if auras can't be read right now)
local function scanBuffs()
    local hasAura, hasBless = false, false
    local names = {}
    local ok = pcall(function()
        for i = 1, 40 do
            local a = C_UnitAuras.GetAuraDataByIndex("player", i, "HELPFUL")
            if not a then break end
            local n = a.name
            if n then
                names[n] = true
                if n:find(" Aura$") then hasAura = true end
                if n:find("^Blessing of") or n:find("^Greater Blessing of") then hasBless = true end
            end
        end
    end)
    if not ok then return nil end
    return hasAura, hasBless, names
end

---------------------------------------------------------------------------
-- Missing buff reminder: small clickable pills. Click one to cast that buff.
-- They are secure buttons, hidden by the game itself during combat, so they
-- never get in your way or cause "action blocked" errors.
---------------------------------------------------------------------------
local UI = ns.UI
local anchor = CreateFrame("Frame", "PallyPalReminderAnchor", UIParent)
anchor:SetSize(300, 64)
anchor:SetPoint("TOP", UIParent, "TOP", 0, -110)
UI.RegisterMover(anchor, "buffs", "Buff buttons", { "TOP", "TOP", 0, -110 })

local pills = {}
-- secure parent: the game hides it (and every pill) in combat or when dead
local pillHeader = CreateFrame("Frame", "PallyPalPillHeader", UIParent, "SecureHandlerStateTemplate")
pillHeader:SetAllPoints(UIParent)
RegisterStateDriver(pillHeader, "visibility", "[combat][dead] hide; show")

local function makePill(i)
    local b = CreateFrame("Button", "PallyPalBuffPill" .. i, pillHeader, "SecureActionButtonTemplate, BackdropTemplate")
    b:SetSize(300, 30)
    b:SetPoint("TOP", anchor, "TOP", 0, -(i - 1) * 34)
    b:RegisterForClicks("AnyUp", "AnyDown")
    b:SetAttribute("type", "spell")
    UI.Flat(b, UI.C.bg, { 0.96, 0.55, 0.73, 0.45 }, "pill")
    UI.Shadow(b, 14, 0.6)
    b.icon = UI.Icon(b, 22)
    b.icon:SetPoint("LEFT", 5, 0)
    b.tag = UI.Title(b, 11, UI.C.pink)
    b.tag:SetPoint("LEFT", b.icon, "RIGHT", 9, 0)
    b.text = UI.Text(b, 11, { 0.85, 0.84, 0.81, 1 })
    b.text:SetPoint("LEFT", b.tag, "RIGHT", 8, 0)
    b.text:SetPoint("RIGHT", -12, 0)
    b.text:SetWordWrap(false)
    b:SetScript("OnEnter", function(self) self:SetBackdropBorderColor(unpack(UI.C.pink)); self:SetBackdropColor(unpack(UI.C.panel2)) end)
    b:SetScript("OnLeave", function(self) self:SetBackdropBorderColor(0.96, 0.55, 0.73, 0.45); self:SetBackdropColor(unpack(UI.C.bg)) end)
    -- only ever shown/hidden by us out of combat; the secure parent handles combat
    b:Hide()
    pills[i] = b
    return b
end

local function hidePills()
    if InCombatLockdown() then return end
    for _, p in ipairs(pills) do p:Hide() end
end

local function applyLock() end -- positions are handled by Edit layout now

local function updateReminder()
    if InCombatLockdown() then return end
    if not db().buffs or ns.ConflictFor("buffs")
        or UnitIsDeadOrGhost("player") or UnitOnTaxi("player")
        or (db().hideResting and IsResting()) then
        hidePills(); return
    end
    local hasAura, hasBless, buffNames = scanBuffs()
    if hasAura == nil then hidePills() return end

    local want = {}
    local aura = knows("Devotion Aura") and "Devotion Aura" or knowsAny(AURAS)
    local bless = knows("Blessing of Kings") and "Blessing of Kings"
        or knows("Blessing of Might") and "Blessing of Might" or knowsAny(BLESSINGS)
    if aura and not hasAura then table.insert(want, { aura, "No Aura" }) end
    if bless and not hasBless then table.insert(want, { bless, "No Blessing" }) end
    -- tank goal: Righteous Fury + Seal of Fury reminders inside dungeons (Tank.lua)
    if ns.TankWants then ns.TankWants(want, buffNames, knows) end

    for i = 1, 3 do
        local p = pills[i] or makePill(i)
        local w = want[i]
        if w then
            p:SetAttribute("spell", w[1])
            p:SetAttribute("unit", "player")
            local ok, tex = pcall(C_Spell.GetSpellTexture, w[1])
            p.icon:SetIcon(ok and tex or 134400)
            p.tag:SetText(w[2])
            p.text:SetText("Click to cast " .. w[1])
            p:Show()
        else
            p:Hide()
        end
    end
end

ns.RefreshReminder = function() updateReminder() end

---------------------------------------------------------------------------
-- After-combat tips
---------------------------------------------------------------------------
local lastTip = {}
local function tip(key, msg)
    local now = GetTime()
    if lastTip[key] and now - lastTip[key] < 25 then return end
    lastTip[key] = now
    say(msg)
end

local function afterCombat()
    if not db().tips or UnitIsDeadOrGhost("player") then return end
    pcall(function()
        local hp, maxHp = UnitHealth("player"), UnitHealthMax("player")
        if maxHp > 0 and hp / maxHp < 0.45 then
            local fix = knows("Holy Light") and "cast |cffffd100Holy Light|r on yourself" or "eat some food"
            if knows("Cannibalize") then
                fix = fix .. ", or use |cffffd100Cannibalize|r on a nearby Humanoid/Undead corpse (heals health and mana)"
            end
            tip("hp", "Low health. Before the next pull, " .. fix .. ".")
        end
    end)
    pcall(function()
        local mp, maxMp = UnitPower("player", 0), UnitPowerMax("player", 0)
        if maxMp > 0 and mp / maxMp < 0.30 then
            tip("mana", "Low mana. Sit and drink before the next pull. If this keeps happening, try |cffffd100Blessing of Wisdom|r or |cffffd100Seal of Wisdom|r.")
        end
    end)
end

---------------------------------------------------------------------------
-- Vendor: sell greys + repair
---------------------------------------------------------------------------
local function onMerchant()
    if db().sellGrey and not ns.ConflictFor("sellGrey") then
        local total, queue = 0, {}
        for bag = 0, (NUM_BAG_SLOTS or 4) do
            for slot = 1, C_Container.GetContainerNumSlots(bag) do
                local info = C_Container.GetContainerItemInfo(bag, slot)
                if info and info.quality == 0 and not info.hasNoValue and not info.isLocked then
                    local price = select(11, C_Item.GetItemInfo(info.itemID)) or 0
                    total = total + price * (info.stackCount or 1)
                    table.insert(queue, { bag, slot })
                end
            end
        end
        -- sell a few at a time so the vendor never throttles or misses items
        for i, q in ipairs(queue) do
            C_Timer.After(0.15 * (i - 1), function()
                if MerchantFrame and MerchantFrame:IsShown() then C_Container.UseContainerItem(q[1], q[2]) end
            end)
        end
        if #queue > 0 then say("Sold " .. #queue .. " junk item(s) for " .. money(total) .. ".") end
    end

    if db().repair and not ns.ConflictFor("repair") and CanMerchantRepair() then
        local cost, canRepair = GetRepairAllCost()
        if canRepair and cost > 0 then
            if db().guildRepair and IsInGuild() and CanGuildBankRepair and CanGuildBankRepair() then
                RepairAllItems(true)
                say("Repaired with guild funds: " .. money(cost) .. ".")
            elseif GetMoney() >= cost then
                RepairAllItems()
                say("Repaired everything for " .. money(cost) .. ".")
            else
                say("|cffff5555Not enough gold to repair everything|r (" .. money(cost) .. ").", true)
            end
        end
    end
end

---------------------------------------------------------------------------
-- Durability warning
---------------------------------------------------------------------------
local warnedDura = false
local function checkDurability()
    if not db().durability then return end
    local lowest = 1
    for slot = 1, 18 do
        local cur, max = GetInventoryItemDurability(slot)
        if cur and max and max > 0 then lowest = math.min(lowest, cur / max) end
    end
    if lowest < 0.25 and not warnedDura then
        warnedDura = true
        bigAlert("Gear at " .. math.floor(lowest * 100) .. "% durability.", "Repair at any vendor soon.")
    elseif lowest >= 0.5 then
        warnedDura = false
    end
end

---------------------------------------------------------------------------
-- Level up
---------------------------------------------------------------------------
-- Milestones from Icy Veins' WoW Forever Paladin leveling guides
local MILESTONES = {
    [6]  = "New ability: |cffffd100Holy Strike|r. Use it on cooldown.",
    [10] = "Talents unlocked (press |cffffd100N|r). New at the trainer: |cffffd100Seal of Fury|r and |cffffd100Righteous Fury|r (tanking), |cffffd100Lay on Hands|r, |cffffd100Blessing of Protection|r.",
    [12] = "The |cffffd100Redemption|r quest is available. Ask your trainer.",
    [20] = "|cffffd100Consecration|r, |cffffd100Exorcism|r and |cffffd100Blessing of Kings|r are here. The Horde weapon quest for |cffffd100Wolfsbane|r starts now.",
    [22] = "Grab |cffffd100Pursuit of Justice|r in Retribution talents: faster running.",
    [30] = "|cffffd100Repentance|r is available as a Retribution talent.",
    [34] = "|cffffd100Divine Shield|r is available.",
    [43] = "|cffffd100Reckoning|r is available as a Protection talent.",
    [40] = "Your Paladin |cffffd100mount quest|r is available!",
    [44] = "|cffffd100Hammer of Wrath|r: finish off mobs under 20% health.",
    [50] = "|cffffd100Holy Wrath|r: area damage vs Undead and Demons.",
    [60] = "Max level! Your |cffffd100epic mount quest|r is available.",
}

local function onLevelUp(level)
    if not db().trainer then return end
    if level % 2 == 0 then
        bigAlert("Level " .. level .. "!", MILESTONES[level] and MILESTONES[level] or "Visit your class trainer for new spells.")
    elseif MILESTONES[level] then
        bigAlert("Level " .. level .. "!", MILESTONES[level])
    end
end

---------------------------------------------------------------------------
-- Beginner guide window
---------------------------------------------------------------------------
local GUIDE = [[
|cff888888New to WoW? Click the Pal button on your minimap and pick "Tour" first.
Info checked against Icy Veins' WoW Forever Paladin guides.|r

|cfff58cbaYOUR CORE TOOLKIT|r
|cffffd100Aura|r - Always keep one on. Devotion = safer, Retribution = faster kills.
|cffffd100Blessing|r - 1 hour buff. Might until level 20, then Kings.
|cffffd100Seal|r - 30 sec weapon buff. Seal of Righteousness for damage.
|cffffd100Judgement|r - Unleashes your Seal. Your Seal stays on. Use on cooldown.
|cffffd100Holy Strike|r - Level 6. Instant hit. Use on cooldown.
|cffffd100Holy Light|r - Big heal. Spend leftover mana on it after fights.
|cffffd100Hammer of Justice|r - Stun. Stun a mob, then heal safely.
|cffffd100Divine Protection|r - Immune to damage. Panic button.
|cffffd100Lay on Hands|r - Full heal, costs all mana. Last resort.

|cfff58cbaBASIC LEVELING LOOP|r
1. Aura + Blessing on (PallyPal nags you if they drop).
2. Seal on. Keep it up (it lasts 30 sec).
3. Judgement + Holy Strike whenever they're ready.
4. Lots of mana? Add Consecration (level 20).
5. After: Holy Light or Cannibalize. Drink if low.

|cfff58cbaBECOMING A TANK|r (open "Tank path" in Pal for the full plan)
Level 10: train |cffffd100Seal of Fury|r + |cffffd100Righteous Fury|r. Use a shield.
Seal of Fury makes Judgement |cffffd100taunt|r (4 sec). Righteous Fury = more threat.
Tanking: Righteous Fury on, Seal of Fury, Consecration, Judgement, Holy Strike.
Talents: Retribution first for Pursuit of Justice, then Protection.

|cfff58cbaUNDEAD PERKS|r
|cffffd100Will of the Forsaken|r - Breaks fear, charm, sleep. 2 min cooldown.
|cffffd100Cannibalize|r - Corpse snack: up to 35% health AND mana. Don't move.
|cffffd100Touch of the Grave|r - Your hits sometimes drain health. Automatic.
|cffffd100Underwater Breathing|r - Hold your breath 300% longer.

|cfff58cbaHABITS|r
Talents (level 10+): Retribution. Get Pursuit of Justice early.
Log out in an Inn for rested XP. Carry food, water, potions.
Mana pauses for 5 sec after each cast. Space out spells.

|cfff58cbaLEARNING|r
/pal learn - lessons.  /pal tip - a tip.  /pal what <spell> - explain a spell.
Hover any spell: a pink "PallyPal" note says when to use it.

|cfff58cbaBESTIARY|r
/pal index - mobs you've looted and your drop rates.

|cfff58cbaCOMMANDS|r (optional, the Pal button does all of this)
/pal  /pal tour  /pal settings  /pal unlock  /pal status
]]

local guide
local toggleGuide
function toggleGuide()
    if not guide then
        guide = ns.UI.Window("PallyPalGuide", 480, 540, "Paladin Basics", "scroll for more")
        local sf = ns.UI.Scroll(guide.content)
        sf:SetAllPoints()
        local body = ns.UI.Text(sf.child, 12)
        body:SetPoint("TOPLEFT", 2, -2)
        body:SetWidth(440)
        body:SetJustifyV("TOP")
        body:SetSpacing(3)
        body:SetText(GUIDE)
        sf.child:SetHeight(body:GetStringHeight() + 20)
    end
    guide:SetShown(not guide:IsShown())
end

ns.ToggleGuide = function() toggleGuide() end

---------------------------------------------------------------------------
-- Slash commands
---------------------------------------------------------------------------
local TOGGLES = { sell = "sellGrey", repair = "repair", guild = "guildRepair",
    buffs = "buffs", tips = "tips", durability = "durability", trainer = "trainer",
    coach = "coach", tooltips = "tooltips" }

-- /pp is used by PallyPower, so we use /pal to avoid clashing
SLASH_PALLYPAL1, SLASH_PALLYPAL2 = "/pal", "/pallypal"
SlashCmdList.PALLYPAL = function(msg)
    msg = (msg or ""):lower():match("^%s*(.-)%s*$")
    if msg == "" then
        if ns.ToggleHome then ns.ToggleHome() else toggleGuide() end
    elseif msg == "guide" or msg == "basics" then
        toggleGuide()
    elseif msg == "unlock" or msg == "edit" or msg == "layout" then
        UI.SetEditMode(true)
    elseif msg == "lock" then
        UI.SetEditMode(false); updateReminder()
    elseif msg == "reset" then
        db().layout = {}; UI.ApplyLayout(); say("Layout reset.", true)
    elseif msg == "status" then
        for cmd, key in pairs(TOGGLES) do
            say(cmd .. ": " .. (db()[key] and "|cff55ff55on|r" or "|cffff5555off|r"))
        end
    elseif TOGGLES[msg] then
        local key = TOGGLES[msg]
        db()[key] = not db()[key]
        say(msg .. " is now " .. (db()[key] and "|cff55ff55on|r" or "|cffff5555off|r"))
        updateReminder()
    elseif ns.HandleSlash and ns.HandleSlash(msg) then
        -- handled by Learn.lua
    else
        say("Commands: /pal (home), guide, tour, settings, learn, index, tip, what <spell>, mobtips, coach, tooltips, unlock, lock, reset, status, sell, repair, guild, buffs, tips, durability, trainer")
    end
end

---------------------------------------------------------------------------
-- Events
---------------------------------------------------------------------------
local ev = CreateFrame("Frame")
ev:RegisterEvent("ADDON_LOADED")
ev:SetScript("OnEvent", function(self, event, arg1)
    if event == "ADDON_LOADED" then
        if arg1 ~= ADDON then return end
        PallyPalDB = PallyPalDB or {}
        for k, v in pairs(DEFAULTS) do
            if PallyPalDB[k] == nil then PallyPalDB[k] = v end
        end
        local _, class = UnitClass("player")
        if class ~= "PALADIN" then return end -- stays dormant on other classes

        -- old saved spot for the buff buttons moves over to the new layout system
        if db().pos and not (db().layout and db().layout.buffs) then
            db().layout = db().layout or {}
            db().layout.buffs = db().pos
            db().pos = nil
        end
        UI.Init(db())
        for _, e in ipairs({ "PLAYER_ENTERING_WORLD", "PLAYER_REGEN_DISABLED", "PLAYER_REGEN_ENABLED",
            "SPELLS_CHANGED", "PLAYER_UNGHOST", "PLAYER_ALIVE", "MERCHANT_SHOW",
            "UPDATE_INVENTORY_DURABILITY", "PLAYER_LEVEL_UP", "PLAYER_UPDATE_RESTING" }) do
            self:RegisterEvent(e)
        end
        self:RegisterUnitEvent("UNIT_AURA", "player") -- ignore every other unit's buffs
        self:UnregisterEvent("ADDON_LOADED")
        if ns.InitLearn then ns.InitLearn(PallyPalDB) end

    elseif event == "PLAYER_ENTERING_WORLD" then
        applyLock()
        C_Timer.After(2, updateReminder)
        if db().toured then
            C_Timer.After(4, function()
                say("Type |cffffd100/pal|r anytime you need help.")
            end)
        end
    elseif event == "PLAYER_REGEN_DISABLED" then
        -- pills hide themselves in combat (state driver)
    elseif event == "PLAYER_REGEN_ENABLED" then
        C_Timer.After(0.5, function()
            updateReminder()
            afterCombat()
        end)
    elseif event == "UNIT_AURA" then
        if arg1 == "player" and not InCombatLockdown() and not ns._auraPending then
            ns._auraPending = true
            C_Timer.After(0.25, function() ns._auraPending = nil; if not InCombatLockdown() then updateReminder() end end)
        end
    elseif event == "SPELLS_CHANGED" or event == "PLAYER_UNGHOST" or event == "PLAYER_ALIVE" or event == "PLAYER_UPDATE_RESTING" then
        C_Timer.After(1, updateReminder)
    elseif event == "MERCHANT_SHOW" then
        onMerchant()
    elseif event == "UPDATE_INVENTORY_DURABILITY" then
        checkDurability()
    elseif event == "PLAYER_LEVEL_UP" then
        onLevelUp(arg1)
    end
end)
