-- PallyPal Bars: one-click action bar setup for a leveling Paladin.
-- Only runs out of combat. "Fill empty slots" never removes anything.
-- "Use full layout" saves your old bars first so you can Undo.
local ADDON, ns = ...
local UI = ns.UI
local DB

local KEYS = { "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "-", "=" }

-- Main bar (action slots 1-12): the stuff you press in fights, closest keys first.
-- Action Bar 2 (slots 61-72): out-of-combat buffs + spells you learn later.
local LAYOUTS = {
    damage = {
        main = {
            { "Judgement" }, { "Holy Strike" }, { "Seal of Righteousness" }, { "Seal of the Crusader" },
            { "Hammer of Justice" }, { "Holy Light" }, { "Purify", "Cleanse" }, { "Cannibalize" },
            { "Will of the Forsaken" }, { "Divine Protection" }, { "Blessing of Protection" }, { "Lay on Hands" },
        },
        bar2 = {
            { "Devotion Aura" }, { "Retribution Aura" }, { "Blessing of Kings", "Blessing of Might" },
            { "Blessing of Wisdom" }, { item = 6948, name = "Hearthstone" }, { "Redemption" },
            { "Consecration" }, { "Exorcism" }, { "Flash of Light" }, { "Divine Shield" },
            { "Hammer of Wrath" }, { "Repentance" },
        },
    },
    -- Tank layout, from Icy Veins' WoW Forever Protection guide:
    -- Righteous Fury on, Seal of Fury, Consecration, Judgement (taunt), Holy Shield, Holy Strike.
    tank = {
        main = {
            { "Judgement" }, { "Holy Strike" }, { "Consecration" }, { "Seal of Fury", "Seal of Righteousness" },
            { "Hammer of Justice" }, { "Holy Light" }, { "Holy Shield" }, { "Exorcism" },
            { "Templar's Bulwark", "Divine Protection" }, { "Will of the Forsaken" }, { "Blessing of Protection" }, { "Lay on Hands" },
        },
        bar2 = {
            { "Righteous Fury" }, { "Devotion Aura" }, { "Retribution Aura" }, { "Blessing of Kings", "Blessing of Might" },
            { "Seal of Righteousness" }, { item = 6948, name = "Hearthstone" }, { "Cannibalize" }, { "Purify", "Cleanse" },
            { "Flash of Light" }, { "Divine Shield" }, { "Hammer of Wrath" }, { "Redemption" },
        },
    },
}

local PLAN = {}
local function buildPlan()
    wipe(PLAN)
    local L = LAYOUTS[(DB and DB.goal == "tank") and "tank" or "damage"]
    for i, e in ipairs(L.main) do table.insert(PLAN, { slot = i, key = KEYS[i], e = e, bar = 1 }) end
    for i, e in ipairs(L.bar2) do table.insert(PLAN, { slot = 60 + i, key = "Bar 2 · " .. i, e = e, bar = 2 }) end
end
buildPlan()

---------------------------------------------------------------------------
-- Helpers
---------------------------------------------------------------------------
local function spellInfo(name)
    local ok, info = pcall(C_Spell.GetSpellInfo, name)
    if ok and info then return info end
end
local function pickupSpell(id)
    if C_Spell and C_Spell.PickupSpell then C_Spell.PickupSpell(id) else PickupSpell(id) end
end
local function pickupItem(id)
    if C_Item and C_Item.PickupItem then C_Item.PickupItem(id) else PickupItem(id) end
end
local function itemCount(id)
    local f = (C_Item and C_Item.GetItemCount) or GetItemCount
    local ok, n = pcall(f, id)
    return ok and n or 0
end

-- What should go in this plan entry right now? (first known option wins)
local function resolve(e)
    if e.item then
        if itemCount(e.item) > 0 then return { kind = "item", id = e.item, name = e.name } end
        return nil, e.name
    end
    for _, name in ipairs(e) do
        local info = spellInfo(name)
        if info then return { kind = "spell", id = info.spellID, name = name } end
    end
    return nil, e[1]
end

local function slotHas(slot, res)
    local t, id = GetActionInfo(slot)
    if not t or not res then return false end
    if res.kind == "item" then return t == "item" and id == res.id end
    if t ~= "spell" then return false end
    local ok, n = pcall(C_Spell.GetSpellName, id)
    return ok and n == res.name
end

local function findOnBars(res)
    for s = 1, 180 do
        if slotHas(s, res) then return s end
    end
end

local function put(slot, res)
    ClearCursor()
    if res.kind == "item" then pickupItem(res.id) else pickupSpell(res.id) end
    PlaceAction(slot)
    ClearCursor()
end

local function snapshot()
    local snap = {}
    for _, p in ipairs(PLAN) do
        local t, id = GetActionInfo(p.slot)
        snap[p.slot] = { t = t, id = id }
    end
    return snap
end

local function restore(snap)
    for slot, a in pairs(snap) do
        ClearCursor()
        if a.t == "spell" then pickupSpell(a.id)
        elseif a.t == "item" then pickupItem(a.id)
        elseif a.t == "macro" then PickupMacro(a.id) end
        if GetCursorInfo() then
            PlaceAction(slot)
        elseif not a.t then
            PickupAction(slot) -- slot was empty before: clear it
        end
        ClearCursor()
    end
end

local function bar2Visible()
    return MultiBarBottomLeft and MultiBarBottomLeft:IsShown()
end

local function showBar2()
    if bar2Visible() then return true end
    -- turn on Action Bar 2 the same way the Options menu does (only if the game allows it)
    pcall(function() Settings.SetValue("PROXY_SHOW_ACTIONBAR_2", true) end)
    return bar2Visible()
end

---------------------------------------------------------------------------
-- Apply
---------------------------------------------------------------------------
local refreshWindow

-- mode: "fill" = only empty slots, nothing removed. "full" = recommended layout (undo saved).
local function apply(mode)
    if InCombatLockdown() then
        if ns.Alert then ns.Alert("Can't change bars in combat.", "Try again after the fight.") end
        return
    end
    if mode == "full" then DB.barUndo = snapshot() end
    local placed, later = 0, 0
    for _, p in ipairs(PLAN) do
        local res = resolve(p.e)
        if not res then
            later = later + 1
        elseif slotHas(p.slot, res) then
            -- already right where it belongs
        elseif mode == "fill" then
            if not HasAction(p.slot) and not findOnBars(res) then
                put(p.slot, res); placed = placed + 1
            end
        else
            local from = findOnBars(res)
            if from then
                -- move it instead of making a copy
                ClearCursor(); PickupAction(from); PlaceAction(p.slot); ClearCursor()
            else
                put(p.slot, res)
            end
            placed = placed + 1
        end
    end
    local bar2 = showBar2()
    if ns.Alert then
        ns.Alert("Bars set up: " .. placed .. " spell(s) placed.",
            bar2 and (later > 0 and (later .. " more will be added as you learn them.") or "You're all set.")
            or "Turn on Action Bar 2: Esc > Options > Action Bars.")
    end
    if refreshWindow then refreshWindow() end
end

local function undo()
    if InCombatLockdown() then return end
    if not DB.barUndo then
        if ns.Alert then ns.Alert("Nothing to undo.") end
        return
    end
    restore(DB.barUndo)
    DB.barUndo = nil
    if ns.Alert then ns.Alert("Bars restored.", "Everything is back the way it was.") end
    if refreshWindow then refreshWindow() end
end

---------------------------------------------------------------------------
-- Auto-place newly learned spells (empty slots only)
---------------------------------------------------------------------------
local pending = {}

local function autoPlace(name)
    if not DB.autoBars then return end
    if InCombatLockdown() then pending[name] = true return end
    for _, p in ipairs(PLAN) do
        for i, opt in ipairs(p.e) do
            if opt == name then
                local res = resolve(p.e)
                if not res or res.name ~= name or findOnBars(res) then return end
                -- e.g. Blessing of Kings may take over the slot where Blessing of Might was
                local fallback = p.e[i + 1] and resolve({ p.e[i + 1] })
                local target = p.slot
                if HasAction(target) and not (fallback and slotHas(target, fallback)) then
                    target = nil
                    for s = 61, 72 do if not HasAction(s) then target = s break end end
                    if not target then for s = 1, 12 do if not HasAction(s) then target = s break end end end
                end
                if target then
                    put(target, res)
                    if ns.Alert then
                        ns.Alert(name .. " added to your bars.",
                            target <= 12 and ("Key " .. KEYS[target]) or ("Action Bar 2, button " .. (target - 60)))
                    end
                    if refreshWindow then refreshWindow() end
                end
                return
            end
        end
    end
end

---------------------------------------------------------------------------
-- Window
---------------------------------------------------------------------------
local win
local rows = {}

-- one pass over your bars (was 180 lookups per row, which made the window stutter)
local function barIndex()
    local spells, items = {}, {}
    for s = 1, 180 do
        local t, id = GetActionInfo(s)
        if t == "spell" and id then
            local ok, n = pcall(C_Spell.GetSpellName, id)
            if ok and n then spells[n] = spells[n] or s end
        elseif t == "item" and id then items[id] = items[id] or s end
    end
    return spells, items
end

local pendingRefresh
refreshWindow = function()
    if not win or not win:IsShown() then return end
    if pendingRefresh then return end
    pendingRefresh = true
    C_Timer.After(0.05, function()
        pendingRefresh = false
        if not win:IsShown() then return end
        local spells, items = barIndex()
        for i, p in ipairs(PLAN) do
            local r = rows[i]
            local res, label = resolve(p.e)
            r.name:SetText(res and res.name or label)
            r.icon:SetIcon(res and (res.kind == "item" and (C_Item.GetItemIconByID and C_Item.GetItemIconByID(res.id)) or UI.SpellIcon(res.name)) or UI.SpellIcon(label))
            local where = res and (res.kind == "item" and items[res.id] or spells[res.name])
            if not res then
                r.name:SetTextColor(0.45, 0.45, 0.5); r.icon:SetAlpha(0.3); r.state:SetText("|cff6e6e78Later|r")
            elseif where == p.slot then
                r.name:SetTextColor(0.95, 0.95, 0.95); r.icon:SetAlpha(1); r.state:SetText("|cff7fd88f\226\156\147|r")
            elseif where then
                r.name:SetTextColor(0.95, 0.95, 0.95); r.icon:SetAlpha(1); r.state:SetText("|cff9a9aa4Elsewhere|r")
            else
                r.name:SetTextColor(0.95, 0.95, 0.95); r.icon:SetAlpha(1); r.state:SetText("|cfff58cbaReady|r")
            end
        end
        win.undo:SetEnabled(DB.barUndo ~= nil)
        win.layoutLabel:SetText(DB.goal == "tank" and "Tank layout" or "Damage layout")
        win.auto:Refresh()
    end)
end

local function makeColumn(c, title, x, first, last)
    local h = UI.Title(c, 10, UI.C.head)
    h:SetPoint("TOPLEFT", x + 2, 0)
    h:SetText(title)
    for i = first, last do
        local p = PLAN[i]
        local r = CreateFrame("Frame", nil, c)
        r:SetSize(250, 26)
        r:SetPoint("TOPLEFT", x, -22 - (i - first) * 27)
        local kt = UI.Text(r, 11, { 0.5, 0.5, 0.55, 1 }, "", UI.FONT_SB); kt:SetPoint("LEFT", 0, 0); kt:SetWidth(20); kt:SetJustifyH("CENTER")
        kt:SetText(p.bar == 1 and p.key or tostring(p.slot - 60))
        r.icon = UI.Icon(r, 20); r.icon:SetPoint("LEFT", 24, 0)
        r.name = UI.Text(r, 12)
        r.name:SetPoint("LEFT", r.icon, "RIGHT", 9, 0)
        r.name:SetPoint("RIGHT", -60, 0)
        r.name:SetWordWrap(false)
        r.state = UI.Text(r, 10)
        r.state:SetPoint("RIGHT", -6, 0)
        r.state:SetJustifyH("RIGHT")
        rows[i] = r
    end
end

local function toggleBars()
    buildPlan()
    if not win then
        local f = UI.Window("PallyPalBars", 560, 560, "Set up my bars", "out of combat only")
        local c = f.content
        f.layoutLabel = UI.Text(f, 11, { 0.75, 0.75, 0.8, 1 }, "", UI.FONT_SB)
        f.layoutLabel:SetPoint("LEFT", f.sub or f.title, "RIGHT", 10, 0)
        makeColumn(c, "MAIN BAR  \194\183  KEYS 1 TO =", 0, 1, 12)
        makeColumn(c, "ACTION BAR 2  \194\183  OUT OF COMBAT", 268, 13, 24)
        local note = UI.Text(c, 11, UI.C.muted)
        note:SetPoint("TOPLEFT", 0, -356)
        note:SetPoint("RIGHT", 0, 0)
        note:SetText("|cffeeeeeeFill empty slots|r only uses empty buttons and never removes anything. "
            .. "|cffeeeeeeUse full layout|r puts everything in the spots above and saves your old bars so you can Undo.")
        f.auto = UI.Toggle(c, "Add new spells to empty slots when I learn them",
            function() return DB.autoBars and true or false end, function(v) DB.autoBars = v end)
        f.auto:SetPoint("TOPLEFT", 0, -396)
        f.auto:SetPoint("RIGHT", 0, 0)

        local fill = UI.Button(f, 160, 32, "Fill empty slots", "primary")
        fill:SetPoint("BOTTOMLEFT", 18, 18)
        fill:SetScript("OnClick", function() apply("fill") end)
        local full = UI.Button(f, 160, 32, "Use full layout")
        full:SetPoint("LEFT", fill, "RIGHT", 8, 0)
        full:SetScript("OnClick", function() apply("full") end)
        f.undo = UI.Button(f, 100, 32, "Undo", "ghost")
        f.undo:SetPoint("BOTTOMRIGHT", -18, 18)
        f.undo:SetScript("OnClick", undo)
        f:HookScript("OnShow", refreshWindow)
        win = f
    end
    win:SetShown(not win:IsShown())
end
ns.ToggleBars = function() toggleBars() end
ns.RebuildBarPlan = function() buildPlan(); if refreshWindow then refreshWindow() end end

---------------------------------------------------------------------------
-- Slash + init
---------------------------------------------------------------------------
local prevSlash = ns.HandleSlash
function ns.HandleSlash(msg)
    if msg == "bars" or msg == "setup" then toggleBars(); return true end
    return prevSlash and prevSlash(msg) or false
end

local ev = CreateFrame("Frame")
ev:SetScript("OnEvent", function(_, event, a1)
    if event == "LEARNED_SPELL_IN_SKILL_LINE" or event == "LEARNED_SPELL_IN_TAB" then
        local ok, name = pcall(C_Spell.GetSpellName, a1)
        if ok and name then C_Timer.After(0.5, function() autoPlace(name) end) end
    elseif event == "PLAYER_REGEN_ENABLED" then
        for name in pairs(pending) do pending[name] = nil; autoPlace(name) end
    elseif event == "ACTIONBAR_SLOT_CHANGED" then
        if refreshWindow then refreshWindow() end
    end
end)

local prevInit = ns.InitLearn
function ns.InitLearn(db)
    if prevInit then prevInit(db) end
    DB = db
    -- off by default: PallyPal never touches your bars unless you press a button
    if not DB.barsMigrated then DB.autoBars = false; DB.barsMigrated = true end
    buildPlan()
    for _, e in ipairs({ "LEARNED_SPELL_IN_SKILL_LINE", "LEARNED_SPELL_IN_TAB", "PLAYER_REGEN_ENABLED", "ACTIONBAR_SLOT_CHANGED" }) do
        pcall(ev.RegisterEvent, ev, e)
    end
end
