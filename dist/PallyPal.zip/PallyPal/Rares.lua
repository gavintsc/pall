-- PallyPal Rares: every rare mob by zone, where it spawns, and which of its
-- drops are worth it for a Protection Paladin. Data: RareData.lua.
local ADDON, ns = ...
local UI = ns.UI
local C = UI.C
local DB

local function ret(ok, ...) if ok then return ... end end
local function safe(f, ...) if f then return ret(pcall(f, ...)) end end

---------------------------------------------------------------------------
-- Zone name -> map ID (asked from the game once, then remembered)
---------------------------------------------------------------------------
local zoneIDs
local function zoneMap(name)
    if not zoneIDs then
        zoneIDs = {}
        if C_Map and C_Map.GetMapChildrenInfo then
            local tops = {}
            local here = safe(C_Map.GetBestMapForUnit, "player")
            local m, guard = here, 0
            while m and guard < 10 do
                local mi = safe(C_Map.GetMapInfo, m)
                if not mi or not mi.parentMapID or mi.parentMapID == 0 then break end
                m = mi.parentMapID; guard = guard + 1
            end
            if m then tops[#tops + 1] = m end
            for _, id in ipairs({ 947, 12, 13, 1414, 1415 }) do tops[#tops + 1] = id end
            for _, top in ipairs(tops) do
                for _, z in ipairs(safe(C_Map.GetMapChildrenInfo, top, nil, true) or {}) do
                    if z.name and not zoneIDs[z.name] and (z.mapType == 3 or z.mapType == nil) then zoneIDs[z.name] = z.mapID end
                end
            end
        end
    end
    return zoneIDs[name]
end

ns.ZoneMapID = zoneMap

function ns.RareWaypoint(r)
    if not r or not r[5] then return end
    local mapID = zoneMap(r[1])
    if mapID and UiMapPoint and C_Map.SetUserWaypoint then
        local pt = safe(UiMapPoint.CreateFromCoordinates, mapID, r[5], r[6])
        if pt then
            safe(C_Map.SetUserWaypoint, pt)
            if C_SuperTrack then safe(C_SuperTrack.SetSuperTrackedUserWaypoint, true) end
            if ns.say then ns.say("Waypoint set: " .. r[2] .. " in " .. r[1] .. string.format(" (%.0f, %.0f)", r[5] * 100, r[6] * 100)) end
            return
        end
    end
    if ns.say then ns.say(r[2] .. " is in " .. r[1] .. string.format(" at %.0f, %.0f.", r[5] * 100, r[6] * 100)) end
end

---------------------------------------------------------------------------
-- Helpers
---------------------------------------------------------------------------
local function killed(name)
    for _, m in pairs(DB and DB.mobs or {}) do
        if m.name == name and (m.looted or 0) > 0 then return m end
    end
end

-- "good for you" = a tank item you can use that beats what you wear
local function goodDrops(r)
    local good, any = 0, 0
    for _, id in ipairs(r[7] or {}) do
        local j = ns.GearJudge and ns.GearJudge(id)
        if j and j.slot then any = any + 1; if j.upgrade then good = good + 1 end end
    end
    return good, any
end

local function zonesSorted()
    local zones, info = {}, {}
    for _, r in ipairs(ns.RARES or {}) do
        local z = info[r[1]]
        if not z then z = { name = r[1], lo = r[3], hi = r[3], n = 0 }; info[r[1]] = z; table.insert(zones, z) end
        z.lo = math.min(z.lo, r[3]); z.hi = math.max(z.hi, r[3]); z.n = z.n + 1
    end
    local here = GetRealZoneText and GetRealZoneText() or ""
    table.sort(zones, function(a, b)
        if (a.name == here) ~= (b.name == here) then return a.name == here end
        if a.lo ~= b.lo then return a.lo < b.lo end
        return a.name < b.name
    end)
    return zones, here
end

---------------------------------------------------------------------------
-- Window
---------------------------------------------------------------------------
local win, refresh
local ZROWS, RROWS = 16, 9

local function showRare(r)
    local d = win.detail
    win.sel = r
    for _, row in ipairs(win.rrows) do row.selTex:SetShown(row.r == r) end
    if not r then d:Hide(); return end
    d:Show()
    d.name:SetText(r[2])
    local lvl = UnitLevel("player")
    local diff = r[3] - lvl
    local col = diff >= 5 and "|cffff7878" or diff >= 3 and "|cffffa040" or diff >= -2 and "|cffffd36b" or diff >= -8 and "|cff6bdb80" or "|cff8d8f96"
    d.sub:SetText(col .. "Level " .. r[3] .. "|r" .. (r[4] and "  ·  |cffffa040Rare elite|r, bring a friend or two" or "  ·  Rare") .. "  ·  " .. r[1])
    if r[5] then d.where:SetText(string.format("Spawns around %.0f, %.0f. Rares have a long respawn, so it may already be dead.", r[5] * 100, r[6] * 100))
    else d.where:SetText("Spawn spot not mapped yet.") end
    d.mapBtn:SetShown(r[5] ~= nil)
    local k = killed(r[2])
    d.killed:SetText(k and ("|cff6bdb80You've looted it " .. k.looted .. "x.|r") or "")
    d.note:SetText(r[8] or "")

    for _, row in ipairs(d.drops) do row:Hide() end
    local y = 0
    local ids = r[7] or {}
    if #ids == 0 then
        d.none:Show(); d.none:SetText("No known gear drops. It still gives good XP and money.")
    else d.none:Hide() end
    for i, id in ipairs(ids) do
        local row = d.drops[i]
        if not row then break end
        local j = ns.GearJudge and ns.GearJudge(id) or { id = id }
        row.it = j
        row.icon:SetIcon(j.icon)
        row.name:SetText(j.name or ("Loading item " .. id .. "..."))
        local c = ITEM_QUALITY_COLORS and ITEM_QUALITY_COLORS[j.quality or 1]
        if c then row.name:SetTextColor(c.r, c.g, c.b) end
        local tag
        if not j.slot then tag = "|cff8d8f96Not for a Paladin tank|r"
        elseif j.upgrade then tag = "|cff6bdb80Upgrade for you|r"
        elseif j.stats then tag = "|cffffd36bTank gear, but you have better|r"
        else tag = "|cff8d8f96Loading...|r" end
        if j.minLevel and j.minLevel > lvl then tag = tag .. "  |cff8d8f96(level " .. j.minLevel .. ")|r" end
        row.tag:SetText(tag)
        row:SetAlpha(j.slot and 1 or 0.55)
        row:ClearAllPoints(); row:SetPoint("TOPLEFT", d.dropAnchor, "BOTTOMLEFT", 0, -6 - y); row:SetPoint("RIGHT", d, "RIGHT", -12, 0)
        row:Show()
        y = y + 40
    end
end

refresh = function()
    if not win or not win:IsShown() then return end
    local zones, here = zonesSorted()
    win.zones = zones
    if not win.zone then win.zone = (zones[1] and zones[1].name) end
    local off = win.zoff or 0
    off = math.max(0, math.min(off, #zones - ZROWS)); win.zoff = off
    for i, b in ipairs(win.zrows) do
        local z = zones[i + off]
        b.z = z
        if z then
            b:Show()
            b.t:SetText((z.name == here and "|cfff58cba" or "") .. z.name .. (z.name == here and "|r" or ""))
            b.lv:SetText(z.lo == z.hi and z.lo or (z.lo .. "-" .. z.hi))
            b.bg:SetVertexColor(1, 1, 1, z.name == win.zone and 0.10 or 0)
        else b:Hide() end
    end

    local list = {}
    for _, r in ipairs(ns.RARES or {}) do if r[1] == win.zone then table.insert(list, r) end end
    table.sort(list, function(a, b) return a[3] < b[3] end)
    win.rlist = list
    win.zoneHead:SetText((win.zone or ""):upper() .. "  ·  " .. #list .. " RARES")
    local roff = win.roff or 0
    roff = math.max(0, math.min(roff, #list - RROWS)); win.roff = roff
    local keep
    for i, row in ipairs(win.rrows) do
        local r = list[i + roff]
        row.r = r
        if r then
            row:Show()
            row.name:SetText(r[2] .. (r[4] and "  |cffffa040elite|r" or ""))
            local good = goodDrops(r)
            local k = killed(r[2])
            row.sub:SetText("Level " .. r[3] .. (k and "  ·  |cff6bdb80looted|r" or "") .. (#(r[7] or {}) == 0 and "  ·  no gear drops" or ""))
            row.badge:SetText(good > 0 and ("|cff6bdb80" .. good .. " upgrade" .. (good > 1 and "s" or "") .. "|r") or "")
            row.selTex:SetShown(win.sel == r)
            if win.sel == r then keep = r end
        else row:Hide() end
    end
    showRare(keep or list[1])
end

local function build()
    local f = UI.Window("PallyPalRares", 760, 560, "Rare mobs", "every zone, what they drop for you")
    win = f
    local c = f.content

    -- zones
    local zc = CreateFrame("Frame", nil, c); zc:SetPoint("TOPLEFT"); zc:SetPoint("BOTTOMLEFT"); zc:SetWidth(170)
    local zh = UI.Title(zc, 10, C.head); zh:SetPoint("TOPLEFT", 2, 0); zh:SetText("ZONES  ·  YOURS FIRST")
    f.zrows = {}
    for i = 1, ZROWS do
        local b = CreateFrame("Button", nil, zc); b:SetHeight(26); b:SetPoint("TOPLEFT", 0, -16 - (i - 1) * 27); b:SetPoint("RIGHT")
        b.bg = b:CreateTexture(nil, "BACKGROUND"); b.bg:SetAllPoints(); b.bg:SetColorTexture(1, 1, 1, 1); b.bg:SetVertexColor(1, 1, 1, 0)
        b.t = UI.Text(b, 12); b.t:SetPoint("LEFT", 10, 0); b.t:SetPoint("RIGHT", -44, 0); b.t:SetWordWrap(false)
        b.lv = UI.Text(b, 10, C.muted); b.lv:SetPoint("RIGHT", -8, 0)
        b:SetScript("OnClick", function(self) if self.z then win.zone = self.z.name; win.sel = nil; win.roff = 0; refresh() end end)
        f.zrows[i] = b
    end
    zc:EnableMouseWheel(true)
    zc:SetScript("OnMouseWheel", function(_, d) win.zoff = (win.zoff or 0) - d * 3; refresh() end)

    -- rares in the zone
    local rc = CreateFrame("Frame", nil, c); rc:SetPoint("TOPLEFT", 182, 0); rc:SetPoint("BOTTOM"); rc:SetWidth(260)
    f.zoneHead = UI.Title(rc, 10, C.head); f.zoneHead:SetPoint("TOPLEFT", 2, 0)
    f.rrows = {}
    for i = 1, RROWS do
        local row = CreateFrame("Button", nil, rc); row:SetHeight(46); row:SetPoint("TOPLEFT", 0, -16 - (i - 1) * 49); row:SetPoint("RIGHT")
        UI.Flat(row, { 1, 1, 1, 0.025 }, { 1, 1, 1, 0.05 }, "small")
        row.selTex = row:CreateTexture(nil, "BORDER"); row.selTex:SetAllPoints(); row.selTex:SetColorTexture(0.96, 0.55, 0.73, 0.10); row.selTex:Hide()
        row.name = UI.Title(row, 12); row.name:SetPoint("TOPLEFT", 12, -9); row.name:SetPoint("RIGHT", -76, 0); row.name:SetWordWrap(false)
        row.sub = UI.Text(row, 10, C.muted); row.sub:SetPoint("TOPLEFT", row.name, "BOTTOMLEFT", 0, -4); row.sub:SetPoint("RIGHT", -8, 0); row.sub:SetWordWrap(false)
        row.badge = UI.Text(row, 10); row.badge:SetPoint("TOPRIGHT", -10, -10)
        row:SetScript("OnClick", function(self) if self.r then showRare(self.r) end end)
        f.rrows[i] = row
    end
    rc:EnableMouseWheel(true)
    rc:SetScript("OnMouseWheel", function(_, d) win.roff = (win.roff or 0) - d; refresh() end)

    -- detail
    local d = CreateFrame("Frame", nil, c); d:SetPoint("TOPLEFT", 454, -16); d:SetPoint("BOTTOMRIGHT")
    UI.Flat(d, { 1, 1, 1, 0.03 }, { 1, 1, 1, 0.06 }, "small")
    f.detail = d
    d.name = UI.Title(d, 15); d.name:SetPoint("TOPLEFT", 12, -12); d.name:SetPoint("RIGHT", -12, 0); d.name:SetJustifyH("LEFT")
    d.sub = UI.Text(d, 11, C.muted); d.sub:SetPoint("TOPLEFT", d.name, "BOTTOMLEFT", 0, -5); d.sub:SetPoint("RIGHT", -12, 0); d.sub:SetJustifyH("LEFT")
    d.where = UI.Text(d, 11); d.where:SetPoint("TOPLEFT", d.sub, "BOTTOMLEFT", 0, -10); d.where:SetPoint("RIGHT", -12, 0); d.where:SetJustifyH("LEFT")
    d.mapBtn = UI.Button(d, 130, 24, "Show on map", "primary"); d.mapBtn:SetPoint("TOPLEFT", d.where, "BOTTOMLEFT", 0, -8)
    d.mapBtn:SetScript("OnClick", function() ns.RareWaypoint(win.sel) end)
    d.killed = UI.Text(d, 11); d.killed:SetPoint("LEFT", d.mapBtn, "RIGHT", 10, 0)
    d.note = UI.Text(d, 11, { 1, 0.82, 0.42, 1 }); d.note:SetPoint("TOPLEFT", d.mapBtn, "BOTTOMLEFT", 0, -10); d.note:SetPoint("RIGHT", -12, 0); d.note:SetJustifyH("LEFT")
    d.dropAnchor = UI.Title(d, 10, C.head); d.dropAnchor:SetPoint("TOPLEFT", d.note, "BOTTOMLEFT", 0, -12); d.dropAnchor:SetText("DROPS")
    d.none = UI.Text(d, 11, C.muted); d.none:SetPoint("TOPLEFT", d.dropAnchor, "BOTTOMLEFT", 0, -8); d.none:SetPoint("RIGHT", -12, 0); d.none:SetJustifyH("LEFT")
    d.drops = {}
    for i = 1, 6 do
        local row = CreateFrame("Button", nil, d); row:SetHeight(36)
        row.icon = UI.Icon(row, 28); row.icon:SetPoint("LEFT", 0, 0)
        row.name = UI.Title(row, 12); row.name:SetPoint("TOPLEFT", 36, -2); row.name:SetPoint("RIGHT"); row.name:SetWordWrap(false); row.name:SetJustifyH("LEFT")
        row.tag = UI.Text(row, 10); row.tag:SetPoint("TOPLEFT", row.name, "BOTTOMLEFT", 0, -3); row.tag:SetPoint("RIGHT"); row.tag:SetJustifyH("LEFT")
        row:SetScript("OnEnter", function(self)
            if not self.it then return end
            GameTooltip:SetOwner(self, "ANCHOR_LEFT")
            if self.it.link then GameTooltip:SetHyperlink(self.it.link) else GameTooltip:SetItemByID(self.it.id) end
            GameTooltip:Show()
        end)
        row:SetScript("OnLeave", function() GameTooltip:Hide() end)
        -- click: open it in the Gear finder to compare
        row:SetScript("OnClick", function(self)
            if not self.it then return end
            if IsModifiedClick and IsModifiedClick("CHATLINK") and self.it.link and ChatEdit_InsertLink then ChatEdit_InsertLink(self.it.link); return end
            if self.it.slot and ns.OpenGearAt then ns.OpenGearAt(self.it.slot, math.max(self.it.minLevel or 1, UnitLevel("player"))) end
        end)
        d.drops[i] = row
    end
    local foot = UI.Text(d, 10, C.muted); foot:SetPoint("BOTTOMLEFT", 12, 10); foot:SetPoint("RIGHT", -12, 0); foot:SetJustifyH("LEFT")
    foot:SetText("Click a drop to compare it in the Gear finder. Shift-click links it.")

    f:HookScript("OnShow", function() win.zone = nil; win.sel = nil; win.zoff = 0; win.roff = 0; C_Timer.After(0, refresh) end)
end

function ns.ToggleRares()
    if not win then build() end
    win:SetShown(not win:IsShown())
end

local ev = CreateFrame("Frame")
local again
ev:SetScript("OnEvent", function()
    if again or not win or not win:IsShown() then return end
    again = true
    C_Timer.After(0.4, function() again = false; refresh() end)
end)

local prevSlash = ns.HandleSlash
function ns.HandleSlash(msg)
    if msg == "rares" or msg == "rare" then ns.ToggleRares(); return true end
    return prevSlash and prevSlash(msg) or false
end

local prevInit = ns.InitLearn
function ns.InitLearn(db)
    if prevInit then prevInit(db) end
    DB = db
    for _, e in ipairs({ "GET_ITEM_INFO_RECEIVED", "PLAYER_EQUIPMENT_CHANGED", "ZONE_CHANGED_NEW_AREA" }) do pcall(ev.RegisterEvent, ev, e) end
end
