-- PallyPal learning module: spell explanations, tooltips, lessons, tips
local ADDON, ns = ...
local PREFIX = "|cfff58cbaPallyPal|r: "
local function say(msg, important) if ns.say then ns.say(msg, important) else print(PREFIX .. msg) end end
local DB

---------------------------------------------------------------------------
-- Spell notes: what it does + when to use it (plain English)
---------------------------------------------------------------------------
local SPELLS = {
    -- Seals (30 sec buffs. In Forever, Judgement does NOT use up your Seal)
    ["Seal of Righteousness"] = { "30 sec buff: your hits deal extra Holy damage. Judging it deals a burst of Holy damage.", "Your default damage Seal. Best with fast weapons or lots of Spell Power." },
    ["Seal of the Crusader"]  = { "30 sec buff. Judging it puts a debuff on the target.", "Judge it first on a new target, then switch to your damage Seal." },
    ["Seal of Command"]       = { "Retribution talent. Your hits sometimes deal a big extra strike.", "Good with slow weapons and early gear. Stun with Hammer of Justice first for a bigger Judgement." },
    ["Seal of Light"]         = { "Your hits heal you. Judging it makes attacks on the target heal the attacker.", "Long fights, or when you want less downtime." },
    ["Seal of Wisdom"]        = { "Your hits sometimes restore mana. Judging it lets attacks on the target restore mana.", "When you keep running out of mana." },
    ["Seal of Justice"]       = { "Hits can stun for 2 sec. Judging it stops the target from fleeing.", "Judge it on mobs that run away at low health." },
    ["Seal of Fury"]          = { "Tank Seal (level 10): extra Holy damage, an absorb shield when you use a shield, and Judgement TAUNTS for 4 sec.", "Keep it on whenever you tank. Swap to Righteousness solo if you want more damage." },
    ["Holy Shield"]           = { "Protection talent: blocks more and hits back when you block.", "Keep it up while tanking." },
    ["Templar's Bulwark"]     = { "Protection cooldown: an absorb shield equal to 100% of your health for 8 sec.", "Big hits incoming, or the healer is in trouble." },
    ["Swift Judgement"]       = { "Protection talent: a second taunt.", "When Judgement is on cooldown and a mob runs at your healer." },
    ["Reckoning"]             = { "Protection talent (level 43).", "Passive. Nothing to press." },
    ["Judgement"]             = { "Unleashes your active Seal on the target. Does not use up the Seal.", "Use it on cooldown. Only one of your Judgements can be on a target." },
    ["Holy Strike"]           = { "Instant Holy strike based on your weapon damage. Learned at level 6.", "Use it on cooldown." },
    -- Auras (affect your whole group)
    ["Devotion Aura"]         = { "More armor. Less damage taken.", "Safe default aura." },
    ["Retribution Aura"]      = { "Damages enemies that hit you or your group.", "Faster kills while questing or fighting several mobs." },
    ["Concentration Aura"]    = { "Chance to not get interrupted by damage while casting.", "Healing in groups." },
    ["Shadow Resistance Aura"]= { "More Shadow resistance.", "Vs. shadow casters." },
    ["Frost Resistance Aura"] = { "More Frost resistance.", "Vs. frost mobs." },
    ["Fire Resistance Aura"]  = { "More Fire resistance.", "Vs. fire mobs." },
    -- Blessings (1 hour in Forever)
    ["Blessing of Might"]     = { "1 hour buff: more attack power.", "Your blessing until you learn Kings at level 20." },
    ["Blessing of Kings"]     = { "1 hour buff: more stats. Learned at level 20.", "Best all-round blessing for you." },
    ["Blessing of Wisdom"]    = { "1 hour buff: restores mana.", "If you keep running out of mana." },
    ["Blessing of Light"]     = { "Target gets more healing from Holy Light and Flash of Light.", "On a tank or anyone you heal a lot." },
    ["Blessing of Protection"]= { "Immune to physical damage. Learned at level 10.", "Save a friend (or yourself) from melee. Recast your Blessing after." },
    ["Blessing of Freedom"]   = { "Immune to slows and roots. Removes them if already slowed.", "When you're stuck or snared. Recast your Blessing after." },
    ["Salvation"]             = { "Target makes less threat. No longer a Blessing in Forever.", "On group damage dealers and healers, never the tank." },
    -- Heals / defensives
    ["Holy Light"]            = { "Big, slow, expensive heal.", "Between fights, or after a stun. Spend leftover mana on it instead of eating." },
    ["Flash of Light"]        = { "Small, fast, efficient heal.", "Topping up. Your most mana-efficient heal." },
    ["Lay on Hands"]          = { "Heals to full, costs all your mana. 20 min cooldown. Level 10.", "Only when you're about to die." },
    ["Divine Protection"]     = { "You become immune to all damage for a short time.", "Panic button: bubble, then heal." },
    ["Divine Shield"]         = { "Full immunity bubble. Learned at level 34.", "Panic button: bubble, then heal or escape." },
    ["Hammer of Justice"]     = { "Stuns the target for a few seconds.", "Stun, then heal with Holy Light safely. Also interrupts." },
    ["Repentance"]            = { "Retribution talent (level 30). Incapacitates a humanoid for 6 sec.", "Take an extra mob out of a fight, or heal up." },
    ["Purify"]                = { "Removes poison and disease.", "When you or a friend has a poison or disease." },
    ["Cleanse"]               = { "Removes poison, disease and magic.", "Clean nasty debuffs off yourself or your group." },
    ["Redemption"]            = { "Resurrects a dead player. Quest unlocks at level 12.", "Out of combat after a group member dies." },
    ["Righteous Fury"]        = { "Tank buff (level 10): 33% more threat, plus extra threat from Holy damage.", "Always on while tanking a group. Optional when solo." },
    ["Divine Intervention"]   = { "Sacrifice yourself to save a group member.", "Saves your group from running back after a wipe." },
    -- Damage vs Undead/Demons, AoE, execute
    ["Exorcism"]              = { "Big Holy damage vs Undead and Demons. Level 20.", "Use on cooldown vs Undead or Demons." },
    ["Holy Wrath"]            = { "Area damage vs Undead and Demons. Level 50.", "Use on cooldown vs groups of Undead or Demons." },
    ["Consecration"]          = { "Holy damage on the ground around you. Level 20.", "Several mobs at once, when you have spare mana." },
    ["Hammer of Wrath"]       = { "Ranged finisher on targets under 20% health. Level 44.", "Finish off mobs, especially ones running away." },
    ["Holy Shock"]            = { "Holy talent (level 41). Instant heal or damage.", "Quick heal or damage on the move." },
    ["Turn Undead"]           = { "Makes an Undead enemy flee.", "Get rid of an extra Undead mob for a bit." },
    ["Sense Undead"]          = { "Shows Undead on your minimap.", "Finding Undead quest targets." },
    -- Undead racials (Forever versions)
    ["Will of the Forsaken"]  = { "Breaks Charm, Fear and Sleep. 2 min cooldown. No immunity after.", "Save it for when you're feared, charmed or slept." },
    ["Cannibalize"]           = { "Eat a nearby Humanoid or Undead corpse: up to 35% health AND mana over 10 sec. 2 min cooldown.", "After a fight. Moving, acting or taking damage cancels it." },
}

local function lookup(name)
    if not name then return end
    if SPELLS[name] then return name, SPELLS[name] end
    local lname = name:lower()
    for k, v in pairs(SPELLS) do
        if k:lower() == lname then return k, v end
    end
    for k, v in pairs(SPELLS) do
        if k:lower():find(lname, 1, true) then return k, v end
    end
end

local function explain(name, header)
    local key, n = lookup(name)
    if not key then return false end
    say((header or "") .. "|cffffd100" .. key .. "|r: " .. n[1] .. " |cff88ff88When:|r " .. n[2])
    return true
end

---------------------------------------------------------------------------
-- Tooltips: add a beginner note to any Paladin spell tooltip
---------------------------------------------------------------------------
local function hookTooltips()
    if not (TooltipDataProcessor and Enum and Enum.TooltipDataType) then return end
    TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Spell, function(tooltip, data)
        if not DB or not DB.tooltips then return end
        pcall(function()
            local name = data and data.id and C_Spell.GetSpellName(data.id)
            local n = name and SPELLS[name]
            if n then
                tooltip:AddLine(" ")
                tooltip:AddLine("|cfff58cbaPallyPal|r", 1, 1, 1)
                tooltip:AddLine(n[1], 0.9, 0.9, 0.9, true)
                tooltip:AddLine("When: " .. n[2], 0.55, 1, 0.55, true)
            end
        end)
    end)
end

---------------------------------------------------------------------------
-- Lessons: a checklist that ticks off as you actually do things
---------------------------------------------------------------------------
local LESSONS = {
    { id = "aura",    text = "Turn on an Aura",                 hint = "Open your spellbook (P) and cast Devotion Aura." },
    { id = "bless",   text = "Cast a Blessing on yourself",     hint = "Cast Blessing of Might. It lasts 1 hour." },
    { id = "seal",    text = "Cast a Seal",                     hint = "Cast Seal of Righteousness. It lasts 30 seconds, so keep it up." },
    { id = "judge",   text = "Use Judgement",                   hint = "In a fight with a Seal up, press Judgement. Your Seal stays on." },
    { id = "strike",  text = "Use Holy Strike",                 hint = "Learned at level 6. Use it on cooldown in fights." },
    { id = "heal",    text = "Heal yourself after a fight",     hint = "Cast Holy Light on yourself. Leftover mana = free health." },
    { id = "cannibal",text = "Use Cannibalize",                 hint = "Stand by a Humanoid or Undead corpse and use it. Heals health AND mana. Don't move." },
    { id = "trainer", text = "Visit your class trainer",        hint = "Find the Paladin trainer in your starting area or capital." },
    { id = "hoj",     text = "Stun something (Hammer of Justice)", hint = "Stun a mob, then heal safely." },
    { id = "repair",  text = "Sell junk / repair at a vendor",  hint = "Open any vendor. PallyPal sells greys and repairs automatically." },
    { id = "talent",  text = "Spend a talent point",            hint = "From level 10. Press N. Icy Veins' leveling build goes Retribution." },
    { id = "wotf",    text = "Break a fear with Will of the Forsaken", hint = "Next time you get feared, charmed or slept, press it." },
    { id = "bubble",  text = "Use your bubble",                 hint = "Divine Protection when about to die, then heal." },
}

local CAST_TO_LESSON = {
    ["Blessing of Might"] = "bless", ["Blessing of Wisdom"] = "bless", ["Blessing of Kings"] = "bless",
    ["Judgement"] = "judge", ["Holy Strike"] = "strike", ["Holy Light"] = "heal", ["Flash of Light"] = "heal",
    ["Cannibalize"] = "cannibal", ["Hammer of Justice"] = "hoj", ["Will of the Forsaken"] = "wotf",
    ["Divine Protection"] = "bubble", ["Divine Shield"] = "bubble",
}

local lessonFrame -- forward
local function refreshLessons() end

local LESSON_ICONS = {
    aura = { "Devotion Aura", "Spell_Holy_DevotionAura" }, bless = { "Blessing of Might", "Spell_Holy_FistOfJustice" },
    seal = { "Seal of Righteousness", "Ability_ThunderBolt" }, judge = { "Judgement", "Spell_Holy_RighteousFury" },
    strike = { "Holy Strike", "Spell_Holy_HolyBolt" }, heal = { "Holy Light", "Spell_Holy_HolyBolt" },
    cannibal = { "Cannibalize", "Ability_Racial_Cannibalize" }, trainer = { nil, "INV_Misc_Book_09" },
    hoj = { "Hammer of Justice", "Spell_Holy_SealOfMight" }, repair = { nil, "Trade_BlackSmithing" },
    talent = { nil, "INV_Misc_Book_11" }, wotf = { "Will of the Forsaken", "Spell_Shadow_RaiseDead" },
    bubble = { "Divine Protection", "Spell_Holy_Restoration" }, t_fury = { "Seal of Fury", "Spell_Holy_SealOfFury" },
    t_shield = { nil, "INV_Shield_06" }, t_taunt = { "Judgement", "Spell_Holy_RighteousFury" },
    t_rf = { "Righteous Fury", "Spell_Holy_SealOfFury" }, t_dungeon = { nil, "INV_Misc_Key_03" },
}
local function lessonIcon(id)
    local e = LESSON_ICONS[id]
    if not e then return 134400 end
    if e[1] then return ns.UI.SpellIcon(e[1], e[2]) end
    return "Interface\\Icons\\" .. e[2]
end

local function nextLesson()
    for _, l in ipairs(LESSONS) do
        if not DB.lessons[l.id] then return l end
    end
end

ns.NextLesson = function() return DB and nextLesson() end

function ns.AddLesson(l, castNames)
    for _, x in ipairs(LESSONS) do if x.id == l.id then return end end
    table.insert(LESSONS, l)
    for _, n in ipairs(castNames or {}) do CAST_TO_LESSON[n] = l.id end
end

local function complete(id)
    if not DB or DB.lessons[id] then return end
    DB.lessons[id] = true
    local done = 0
    for _, l in ipairs(LESSONS) do if DB.lessons[l.id] then done = done + 1 end end
    if DB.coach then
        local text
        for _, l in ipairs(LESSONS) do if l.id == id then text = l.text end end
        pcall(PlaySound, SOUNDKIT and SOUNDKIT.IG_QUEST_LIST_COMPLETE or 878)
        local n = nextLesson()
        if ns.UI then
            ns.UI.Toast("Lesson done: " .. (text or id) .. "  (" .. done .. "/" .. #LESSONS .. ")",
                n and ("Next: " .. n.text) or "All lessons complete!")
        end
    end
    refreshLessons()
    if ns.RefreshTodo then ns.RefreshTodo() end
end
ns.CompleteLesson = function(id) complete(id) end

local function onCast(spellID)
    if issecretvalue and issecretvalue(spellID) then return end
    pcall(function()
        local name = C_Spell.GetSpellName(spellID)
        if not name then return end
        if name:find(" Aura$") then complete("aura")
        elseif name:find("^Seal of") then complete("seal")
        elseif CAST_TO_LESSON[name] then complete(CAST_TO_LESSON[name]) end
    end)
end

-- Forever hides spell casts from addons during combat, so most lessons are
-- also checked by looking at your buffs and cooldowns once a fight ends.
local function buffNames()
    local names = {}
    pcall(function()
        for i = 1, 40 do
            local a = C_UnitAuras.GetAuraDataByIndex("player", i, "HELPFUL")
            if not a then break end
            if a.name and not (issecretvalue and issecretvalue(a.name)) then names[a.name] = true end
        end
    end)
    return names
end

local function onCooldown(name)
    local ok, used = pcall(function()
        local cd = C_Spell.GetSpellCooldown(name)
        return cd and cd.startTime and cd.startTime > 0 and cd.duration and cd.duration > 1.6
    end)
    return ok and used
end

local function checkByState()
    if not DB or InCombatLockdown() then return end
    local b = buffNames()
    for n in pairs(b) do
        if n:find(" Aura$") then complete("aura") end
        if n:find("^Blessing of") or n:find("^Greater Blessing of") then complete("bless") end
        if n:find("^Seal of") then complete("seal") end
    end
    if onCooldown("Judgement") then
        complete("judge")
        if b["Seal of Fury"] then complete("t_taunt") end
    end
    if onCooldown("Holy Strike") then complete("strike") end
    if onCooldown("Hammer of Justice") then complete("hoj") end
    if onCooldown("Cannibalize") then complete("cannibal") end
    if onCooldown("Will of the Forsaken") then complete("wotf") end
    if onCooldown("Divine Protection") or onCooldown("Divine Shield") then complete("bubble") end
    if b["Righteous Fury"] then complete("t_rf") end
end
ns.CheckLessonsByState = checkByState

---------------------------------------------------------------------------
-- Lessons window (/pal learn)
---------------------------------------------------------------------------
local rows = {}
refreshLessons = function()
    if not lessonFrame or not lessonFrame:IsShown() then return end
    local done = 0
    local n = nextLesson()
    for i, l in ipairs(LESSONS) do
        local ok = DB.lessons[l.id]
        if ok then done = done + 1 end
        local r = rows[i]
        if r then
            r.icon:SetIcon(lessonIcon(l.id))
            r.icon:SetAlpha(ok and 0.45 or 1)
            r.text:SetText((l.text:gsub("^Tank: ", "")))
            r.text:SetTextColor(ok and 0.56 or 0.95, ok and 0.57 or 0.94, ok and 0.62 or 0.9)
            r.tank:SetShown(l.id:find("^t_") ~= nil)
            r.check:SetShown(ok and true or false)
            r.ring:SetShown(not ok)
            local isNext = (n and n.id == l.id) and true or false
            r:SetBackdropColor(isNext and 0.96 or 1, isNext and 0.55 or 1, isNext and 0.73 or 1, isNext and 0.10 or 0)
            r:SetBackdropBorderColor(0.96, 0.55, 0.73, isNext and 0.4 or 0)
        end
    end
    lessonFrame.progress:SetText(done .. " / " .. #LESSONS)
    lessonFrame.fill:SetWidth(math.max(6, lessonFrame.track:GetWidth() * done / #LESSONS))
    lessonFrame.next:SetText(n and n.hint or "All done. Nice work, Paladin!")
    lessonFrame.nextTitle:SetText(n and ("Next up: " .. (n.text:gsub("^Tank: ", ""))) or "Every lesson complete")
end

local function toggleLessons()
    if not lessonFrame then
        local UI = ns.UI
        local f = UI.Window("PallyPalLessons", 380, 196 + #LESSONS * 30, "Lessons", "tick off by playing")
        UI.DefaultPos(f, "CENTER", 260, 0)
        local c = f.content
        local lbl = UI.Text(c, 11, UI.C.muted); lbl:SetPoint("TOPLEFT", 0, 0); lbl:SetText("Progress")
        f.progress = UI.Title(c, 11); f.progress:SetPoint("TOPRIGHT", 0, 0)
        local track = CreateFrame("Frame", nil, c)
        track:SetPoint("TOPLEFT", 0, -20); track:SetPoint("TOPRIGHT", 0, -20); track:SetHeight(6)
        UI.Flat(track, { 1, 1, 1, 0.06 }, { 1, 1, 1, 0 }, "pill")
        f.track = track
        local fill = CreateFrame("Frame", nil, track)
        fill:SetPoint("TOPLEFT"); fill:SetPoint("BOTTOMLEFT"); fill:SetWidth(6)
        UI.Flat(fill, UI.C.pink, { 1, 1, 1, 0 }, "pill")
        f.fill = fill
        for i = 1, #LESSONS do
            local r = CreateFrame("Frame", nil, c)
            r:SetHeight(28)
            r:SetPoint("TOPLEFT", 0, -38 - (i - 1) * 30)
            r:SetPoint("RIGHT", 0, 0)
            UI.Flat(r, { 1, 1, 1, 0 }, { 1, 1, 1, 0 }, "small")
            r.icon = UI.Icon(r, 20)
            r.icon:SetPoint("LEFT", 6, 0)
            r.ring = r:CreateTexture(nil, "ARTWORK")
            r.ring:SetTexture(UI.MEDIA .. "pill_edge"); r.ring:SetSize(16, 16); r.ring:SetPoint("RIGHT", -8, 0)
            r.ring:SetVertexColor(1, 1, 1, 0.25)
            r.check = r:CreateTexture(nil, "ARTWORK")
            r.check:SetTexture("Interface\\RaidFrame\\ReadyCheck-Ready"); r.check:SetSize(16, 16); r.check:SetPoint("RIGHT", -8, 0)
            r.tank = UI.Title(r, 9, UI.C.pink); r.tank:SetText("TANK")
            r.tank:SetPoint("RIGHT", r.ring, "LEFT", -8, 0)
            r.text = UI.Text(r, 12)
            r.text:SetPoint("LEFT", r.icon, "RIGHT", 10, 0); r.text:SetPoint("RIGHT", r.tank, "LEFT", -8, 0)
            r.text:SetWordWrap(false)
            rows[i] = r
        end
        local box = CreateFrame("Frame", nil, c)
        UI.Flat(box, UI.C.panel, UI.C.line, "small")
        box:SetPoint("BOTTOMLEFT", 0, 0); box:SetPoint("BOTTOMRIGHT", 0, 0); box:SetHeight(58)
        f.nextTitle = UI.Title(box, 12, UI.C.gold)
        f.nextTitle:SetPoint("TOPLEFT", 12, -10); f.nextTitle:SetPoint("RIGHT", -12, 0); f.nextTitle:SetWordWrap(false)
        f.next = UI.Text(box, 11, UI.C.muted)
        f.next:SetPoint("TOPLEFT", f.nextTitle, "BOTTOMLEFT", 0, -4); f.next:SetPoint("RIGHT", -12, 0)
        f:HookScript("OnShow", refreshLessons)
        lessonFrame = f
    end
    lessonFrame:SetShown(not lessonFrame:IsShown())
end
ns.ToggleLessons = function() toggleLessons() end

---------------------------------------------------------------------------
-- Tips
---------------------------------------------------------------------------
local TIPS = {
    "Keep a Seal up (30 sec) and use Judgement and Holy Strike on cooldown. That's your whole basic rotation.",
    "In Forever, Judgement does not use up your Seal. No need to recast it after judging.",
    "Got mana left when a mob dies? Spend it on Holy Light instead of eating.",
    "Blessings last 1 hour in Forever. Might until level 20, then Blessing of Kings.",
    "Devotion Aura is safest. Retribution Aura kills faster while questing.",
    "Hammer of Justice the mob, then cast Holy Light while it's stunned.",
    "Cannibalize heals 35% health AND mana. Don't move or it cancels.",
    "Fighting Undead or Demons? Exorcism (level 20) hits them very hard.",
    "Mana stops regenerating for 5 seconds after you cast. Space out spells to regen faster.",
    "Log out in an Inn to build rested XP. You level faster when you come back.",
    "Carry food, water and potions. Eating and drinking at once refills both bars.",
    "Get Pursuit of Justice in the Retribution talents (around level 22). Faster running = faster leveling.",
    "At level 20, Horde Paladins can start the quest for the Wolfsbane weapon.",
    "Pick up a gathering profession early. Mining feeds Blacksmithing and Engineering.",
    "Hover any spell for a PallyPal note on when to use it.",
}

local function randomTip() say("|cff88ccffTip:|r " .. TIPS[math.random(#TIPS)]) end

---------------------------------------------------------------------------
-- Slash handler (called from PallyPal.lua)
---------------------------------------------------------------------------
function ns.HandleSlash(msg)
    if msg == "learn" or msg == "lessons" then
        toggleLessons(); return true
    elseif msg == "tip" then
        randomTip(); return true
    elseif msg == "resetlessons" then
        DB.lessons = {}; refreshLessons(); say("Lessons reset."); return true
    end
    local q = msg:match("^what%s+(.+)$") or msg:match("^explain%s+(.+)$")
    if q then
        if not explain(q) then say("I don't have a note for \"" .. q .. "\" yet.") end
        return true
    end
    return false
end

---------------------------------------------------------------------------
-- Events
---------------------------------------------------------------------------
local ev = CreateFrame("Frame")
ev:SetScript("OnEvent", function(_, event, a1, a2, a3)
    if event == "PLAYER_REGEN_ENABLED" then
        C_Timer.After(0.3, checkByState)
        return
    elseif event == "UNIT_AURA" then
        if a1 == "player" and not InCombatLockdown() and not ev.auraPending then
            ev.auraPending = true
            C_Timer.After(0.5, function() ev.auraPending = nil; if not InCombatLockdown() then checkByState() end end)
        end
        return
    end
    if event == "UNIT_SPELLCAST_SUCCEEDED" then
        if a1 == "player" and not InCombatLockdown() then onCast(a3) end
    elseif event == "LEARNED_SPELL_IN_SKILL_LINE" or event == "LEARNED_SPELL_IN_TAB" then
        if not DB.coach then return end
        pcall(function()
            local name = C_Spell.GetSpellName(a1)
            if name and not DB.seen[name] then
                DB.seen[name] = true
                if explain(name, "|cff55ff55New spell!|r ") then
                    say("Drag it from your spellbook (P) onto your action bar.")
                end
            end
        end)
    elseif event == "TRAINER_SHOW" then
        complete("trainer")
    elseif event == "MERCHANT_SHOW" then
        complete("repair")
    elseif event == "PLAYER_TALENT_UPDATE" or event == "CHARACTER_POINTS_CHANGED" or event == "TRAIT_CONFIG_UPDATED" then
        if UnitLevel("player") >= 10 then
            -- only count it once the player actually has fewer unspent points
            local ok, unspent = pcall(UnitCharacterPoints, "player")
            if not ok or (unspent and unspent < (DB.lastUnspent or 99)) then complete("talent") end
            if ok then DB.lastUnspent = unspent end
        end
    elseif event == "PLAYER_ENTERING_WORLD" then
        C_Timer.After(5, checkByState)
        if DB.coach and a1 then -- a1 = isInitialLogin
            C_Timer.After(6, function()
                randomTip()
                local n = nextLesson()
                if n then say("|cffffd100Current lesson:|r " .. n.text .. " - " .. n.hint .. "  (/pal learn)") end
            end)
        end
    end
end)

function ns.InitLearn(db)
    DB = db
    DB.lessons = DB.lessons or {}
    DB.seen = DB.seen or {}
    -- mark spells you already know as "seen" so you aren't spammed on first load
    for name in pairs(SPELLS) do
        local ok, info = pcall(C_Spell.GetSpellInfo, name)
        if ok and info then DB.seen[name] = true end
    end
    hookTooltips()
    pcall(ev.RegisterUnitEvent, ev, "UNIT_AURA", "player")
    pcall(ev.RegisterUnitEvent, ev, "UNIT_SPELLCAST_SUCCEEDED", "player")
    for _, e in ipairs({ "PLAYER_REGEN_ENABLED", "LEARNED_SPELL_IN_SKILL_LINE", "LEARNED_SPELL_IN_TAB",
        "TRAINER_SHOW", "MERCHANT_SHOW", "PLAYER_TALENT_UPDATE", "CHARACTER_POINTS_CHANGED",
        "TRAIT_CONFIG_UPDATED", "PLAYER_ENTERING_WORLD" }) do
        pcall(ev.RegisterEvent, ev, e) -- some events may not exist on this client
    end
end
