-- PallyPal Quests: ranks your quests by importance every time you pick one up.
-- It only changes the ORDER of quests in the game's quest tracker. It never
-- hides quests. (Map pins live in Map.lua and can be switched off.)
local ADDON, ns = ...
local UI = ns.UI
local DB

-- Paladin-specific quests from Icy Veins' WoW Forever leveling guides (Horde side)
local CLASS_WORDS = { "Redemption", "Wolfsbane", "Old Fire%-Eye", "Paladin" }

-- extra quests that matter for the tank path (shield quest from Icy Veins' Protection guide)
local TANK_WORDS = { "Blackfathom Villainy" }

local function isClassQuest(title)
    for _, w in ipairs(CLASS_WORDS) do
        if title:find(w) then return true end
    end
    if DB and DB.goal == "tank" then
        for _, w in ipairs(TANK_WORDS) do
            if title:find(w) then return true end
        end
    end
end

local function ret(ok, ...) if ok then return ... end end
local function safe(f, ...)
    if not f then return end
    return ret(pcall(f, ...))
end

-- Score one quest. Higher = do it sooner. Returns score + a short reason.
local function score(info)
    local q = info.questID
    local me = UnitLevel("player")
    local lvl = (info.level and info.level > 0) and info.level or me
    local diff = lvl - me
    local s, why = 0, nil

    if safe(C_QuestLog.IsComplete, q) then
        return 10000, "Ready to turn in"
    end
    if isClassQuest(info.title or "") then s = s + 600; why = "Paladin quest" end
    if (info.suggestedGroup or 0) > 1 then s = s - 500; why = why or "Needs a group" end
    if diff >= 5 then s = s - 600; why = why or "Too hard for now"
    elseif diff >= 3 then s = s - 150; why = why or "Tough, be careful"
    elseif diff <= -6 then s = s - 250; why = why or "Low XP now" end

    -- closer quests first (distance only works for quests the game can locate)
    local d2 = safe(C_QuestLog.GetDistanceSqToQuest, q)
    if d2 and d2 > 0 then
        local yards = math.sqrt(d2)
        s = s + math.max(0, 400 - yards / 5)
        if yards < 300 then why = why or "Close by" end
    end
    -- more XP = more important
    local xp = safe(GetQuestLogRewardXP, q)
    if xp and xp > 0 then s = s + math.min(250, xp / 20) end

    if not why then
        local done, total = 0, 0
        for _, o in ipairs(safe(C_QuestLog.GetQuestObjectives, q) or {}) do
            total = total + 1
            if o.finished then done = done + 1 end
        end
        if total > 0 and done > 0 then why = done .. " of " .. total .. " done" end
    end
    return s, why or "Not started"
end

local function rank()
    local out = {}
    local n = safe(C_QuestLog.GetNumQuestLogEntries) or 0
    for i = 1, n do
        local info = safe(C_QuestLog.GetInfo, i)
        if info and not info.isHeader and not info.isHidden and info.questID and info.questID > 0 then
            local s, why = score(info)
            table.insert(out, { id = info.questID, title = info.title or "?", level = info.level, score = s, why = why })
        end
    end
    table.sort(out, function(a, b) return a.score > b.score end)
    return out
end

local cache, cacheT = nil, 0
ns.RankQuests = function()
    local now = GetTime()
    if not cache or now - cacheT > 2 then cache, cacheT = rank(), now end
    return cache
end

---------------------------------------------------------------------------
-- Reorder the game's quest tracker (out of combat only)
---------------------------------------------------------------------------
local busy = false
local function sortTracker()
    if not DB.sortQuests or busy or InCombatLockdown() then return end
    if ns.ConflictFor and ns.ConflictFor("sortQuests") then return end
    local ranked = rank()
    local watched = {}
    local n = safe(C_QuestLog.GetNumQuestWatches) or 0
    for i = 1, n do
        local id = safe(C_QuestLog.GetQuestIDForQuestWatchIndex, i)
        if id then watched[id] = true end
    end
    busy = true
    -- re-adding watches in ranked order makes the tracker list them in that order
    for _, r in ipairs(ranked) do if watched[r.id] then safe(C_QuestLog.RemoveQuestWatch, r.id) end end
    for _, r in ipairs(ranked) do if watched[r.id] then safe(C_QuestLog.AddQuestWatch, r.id) end end
    busy = false
end

---------------------------------------------------------------------------
-- Window: ranked quests. Click a quest to see its objectives + description.
-- The Track button adds/removes it from your quest tracker.
---------------------------------------------------------------------------
local win
local rows = {}
local expanded = {}
local descCache = {}

local function isTracked(id)
    local t = safe(C_QuestLog.GetQuestWatchType, id)
    return t ~= nil
end

local function objectives(id)
    local out = {}
    local list = safe(C_QuestLog.GetQuestObjectives, id) or {}
    for _, o in ipairs(list) do
        if o.text and o.text ~= "" then
            table.insert(out, (o.finished and "|cff5dff6a+ " or "|cffd0cdc6- ") .. o.text .. "|r")
        end
    end
    return out
end

-- quest description (the story text). Reading it needs the quest selected in the
-- log, so we select it, read, and put your old selection back.
local function description(id)
    if descCache[id] then return descCache[id] end
    local text
    pcall(function()
        local prev = C_QuestLog.GetSelectedQuest()
        C_QuestLog.SetSelectedQuest(id)
        local desc, objText = GetQuestLogQuestText()
        text = (objText and objText ~= "" and objText) or desc
        if desc and desc ~= "" then text = desc end
        if prev and prev ~= 0 then C_QuestLog.SetSelectedQuest(prev) end
    end)
    if text then
        text = text:gsub("\r", ""):gsub("\n\n+", "\n\n")
        if #text > 600 then text = text:sub(1, 597) .. "..." end
        descCache[id] = text
    end
    return text or ""
end

local function makeRow(parent, i)
    local r = CreateFrame("Frame", nil, parent)
    r:SetPoint("LEFT", 0, 0); r:SetPoint("RIGHT", 0, 0)
    r.head = CreateFrame("Button", nil, r)
    r.head:SetPoint("TOPLEFT"); r.head:SetPoint("TOPRIGHT"); r.head:SetHeight(28)
    r.bg = r:CreateTexture(nil, "BACKGROUND")
    r.bg:SetAllPoints(); r.bg:SetColorTexture(1, 1, 1, (i % 2 == 1) and 0.03 or 0)
    local hl = r.head:CreateTexture(nil, "HIGHLIGHT")
    hl:SetAllPoints(); hl:SetColorTexture(0.96, 0.55, 0.73, 0.07)
    r.arrow = UI.Text(r.head, 10, UI.C.muted); r.arrow:SetPoint("LEFT", 4, 0); r.arrow:SetWidth(10)
    r.num = UI.Text(r.head, 11, { 1, 0.82, 0, 1 }); r.num:SetPoint("LEFT", r.arrow, "RIGHT", 2, 0); r.num:SetWidth(18)
    r.track = UI.Button(r.head, 66, 20, "Track")
    r.track.label:SetFont(STANDARD_TEXT_FONT, 10, "")
    r.track:SetPoint("RIGHT", -4, 0)
    r.why = UI.Text(r.head, 10); r.why:SetPoint("RIGHT", r.track, "LEFT", -8, 0); r.why:SetJustifyH("RIGHT"); r.why:SetWidth(104)
    r.title = UI.Text(r.head, 12); r.title:SetPoint("LEFT", r.num, "RIGHT", 4, 0)
    r.title:SetPoint("RIGHT", r.why, "LEFT", -8, 0); r.title:SetWordWrap(false)
    r.details = UI.Text(r, 11)
    r.details:SetPoint("TOPLEFT", r.head, "BOTTOMLEFT", 32, -2)
    r.details:SetPoint("RIGHT", -10, 0)
    r.details:SetSpacing(2)
    r.details:SetJustifyV("TOP")
    return r
end

local function refresh()
    if not win or not win:IsShown() then return end
    local ranked = rank()
    local child = win.scroll.child
    local y = 0
    for i = 1, math.max(#ranked, #rows) do
        local q = ranked[i]
        local r = rows[i]
        if q and not r then r = makeRow(child, i); rows[i] = r end
        if r then
            if q then
                local id = q.id
                r:ClearAllPoints()
                r:SetPoint("TOPLEFT", 0, -y); r:SetPoint("RIGHT", 0, 0)
                local c = GetQuestDifficultyColor and GetQuestDifficultyColor(q.level or UnitLevel("player")) or { r = 1, g = 1, b = 1 }
                r.num:SetText(i)
                r.title:SetText((q.level and q.level > 0 and ("|cff8d8f96[" .. q.level .. "]|r ") or "") .. q.title)
                r.title:SetTextColor(c.r, c.g, c.b)
                local col = q.why == "Ready to turn in" and "|cff5dff6a" or (q.why == "Paladin quest" and "|cfff58cba")
                    or ((q.why == "Too hard for now" or q.why == "Needs a group") and "|cffff7a7a") or "|cff8d8f96"
                r.why:SetText(col .. q.why .. "|r")
                local tracked = isTracked(id)
                r.track:SetText(tracked and "Tracked" or "Track")
                r.track:SetBackdropColor(unpack(tracked and UI.C.pinkD or UI.C.panel))
                r.track:SetScript("OnClick", function()
                    if InCombatLockdown() then
                        if ns.Alert then ns.Alert("Can't change tracking in combat.") end
                        return
                    end
                    if isTracked(id) then safe(C_QuestLog.RemoveQuestWatch, id) else safe(C_QuestLog.AddQuestWatch, id) end
                    C_Timer.After(0.1, refresh)
                end)
                r.head:SetScript("OnClick", function() expanded[id] = not expanded[id]; refresh() end)
                local h = 28
                if expanded[id] then
                    local lines = objectives(id)
                    local d = description(id)
                    local txt = (#lines > 0 and ("|cff8a8a94OBJECTIVES|r\n" .. table.concat(lines, "\n")) or "")
                    -- the mobs this quest needs, described
                    local mobs = ns.MobsForQuest and ns.MobsForQuest(q.title, safe(C_QuestLog.GetQuestObjectives, id)) or {}
                    local hasMobObjective = false
                    for _, o in ipairs(safe(C_QuestLog.GetQuestObjectives, id) or {}) do
                        if o.type == "monster" or o.type == "item" then hasMobObjective = true end
                    end
                    if #mobs > 0 then
                        local ml = {}
                        for _, m in ipairs(mobs) do ml[#ml + 1] = m.line .. (m.notes ~= "" and ("\n   |cff9a9aa4" .. m.notes .. "|r") or "") end
                        txt = txt .. (txt ~= "" and "\n\n" or "") .. "|cff8a8a94MOBS|r\n" .. table.concat(ml, "\n")
                    elseif hasMobObjective then
                        txt = txt .. (txt ~= "" and "\n\n" or "") .. "|cff8a8a94MOBS|r\n|cff8d8f96Pal hasn't met these mobs yet. Mouse over or target one and Pal will describe it here.|r"
                    end
                    if d ~= "" then txt = txt .. (txt ~= "" and "\n\n" or "") .. "|cff8a8a94STORY|r\n|cffb8b5ae" .. d .. "|r" end
                    if txt == "" then txt = "|cff8d8f96No details available for this quest.|r" end
                    r.details:SetText(txt)
                    r.details:Show()
                    h = h + r.details:GetStringHeight() + 14
                    r.arrow:SetText("v")
                else
                    r.details:Hide()
                    r.arrow:SetText(">")
                end
                r:SetHeight(h)
                r:Show()
                y = y + h + 1
            else
                r:Hide()
            end
        end
    end
    child:SetHeight(math.max(y, 10))
    win.empty:SetShown(#ranked == 0)
    local tracked = 0
    for _, q in ipairs(ranked) do if isTracked(q.id) then tracked = tracked + 1 end end
    win.count:SetText(#ranked .. " quests  ·  " .. tracked .. " tracked  ·  click a quest for details")
end
ns.RefreshQuests = refresh

local function toggleQuests()
    if not win then
        local f = UI.Window("PallyPalQuests", 460, 520, "Quest priority", "most important first")
        local c = f.content
        f.count = UI.Text(c, 11, UI.C.muted); f.count:SetPoint("TOPLEFT", 0, 0)
        f.scroll = UI.Scroll(c)
        f.scroll:SetPoint("TOPLEFT", 0, -20)
        f.scroll:SetPoint("BOTTOMRIGHT", 0, 34)
        f.scroll.child:SetWidth(432)
        f.empty = UI.Text(c, 12, UI.C.muted)
        f.empty:SetPoint("TOPLEFT", 0, -30)
        f.empty:SetText("No quests yet. Look for a yellow ! above someone's head.")
        local note = UI.Text(c, 10, UI.C.muted)
        note:SetPoint("BOTTOMLEFT", 0, 0); note:SetPoint("RIGHT", 0, 0)
        note:SetText("Ranked by: ready to turn in, Paladin quests, distance, XP, and difficulty. Your tracker follows this order.")
        f:HookScript("OnShow", refresh)
        win = f
    end
    win:SetShown(not win:IsShown())
end
ns.ToggleQuests = function() toggleQuests() end

---------------------------------------------------------------------------
-- Events
---------------------------------------------------------------------------
local ev = CreateFrame("Frame")
local pendingSort = false
ev:SetScript("OnEvent", function(_, event, questID)
    if event == "QUEST_ACCEPTED" then
        C_Timer.After(1, function()
            sortTracker()
            refresh()
            local ranked = rank()
            for i, r in ipairs(ranked) do
                if r.id == questID then
                    if ns.Alert and DB.sortQuests then
                        ns.Alert("New quest: " .. r.title, "Priority " .. i .. " of " .. #ranked .. "  ·  " .. r.why)
                    end
                    break
                end
            end
        end)
    elseif event == "QUEST_TURNED_IN" or event == "QUEST_REMOVED" then
        C_Timer.After(1, function() sortTracker(); refresh(); if ns.RefreshTodo then ns.RefreshTodo() end end)
    elseif event == "QUEST_LOG_UPDATE" then
        -- a quest just finished? move it to the top (throttled)
        if not pendingSort then
            pendingSort = true
            C_Timer.After(3, function() pendingSort = false; refresh() end)
        end
    elseif event == "PLAYER_REGEN_ENABLED" then
        C_Timer.After(1, sortTracker)
    end
end)

local prevSlash = ns.HandleSlash
function ns.HandleSlash(msg)
    if msg == "quests" or msg == "q" then toggleQuests(); return true
    elseif msg == "sortquests" then sortTracker(); refresh(); return true end
    return prevSlash and prevSlash(msg) or false
end

local prevInit = ns.InitLearn
function ns.InitLearn(db)
    if prevInit then prevInit(db) end
    DB = db
    if DB.sortQuests == nil then DB.sortQuests = true end
    for _, e in ipairs({ "QUEST_ACCEPTED", "QUEST_TURNED_IN", "QUEST_REMOVED", "QUEST_LOG_UPDATE", "PLAYER_REGEN_ENABLED" }) do
        pcall(ev.RegisterEvent, ev, e)
    end
end
