-- PallyPal Gear finder: pick a level, see the best tank gear you can wear at
-- that level slot by slot, with several options per slot, where each one comes
-- from, and how it compares to what you have on right now.
-- Item list: GearData.lua. Stats and icons come from your game client.
local ADDON, ns = ...
local UI = ns.UI
local C = UI.C
local DB

local function ret(ok, ...) if ok then return ... end end
local function safe(f, ...) if f then return ret(pcall(f, ...)) end end

local function GetInfo(i) local f = (C_Item and C_Item.GetItemInfo) or GetItemInfo; if f then return f(i) end end
local function GetStats(l) local f = (C_Item and C_Item.GetItemStats) or GetItemStats; if f then return f(l) end end
local function GetInfoInstant(i) local f = (C_Item and C_Item.GetItemInfoInstant) or GetItemInfoInstant; if f then return f(i) end end

local SLOTS = {
    { "HEAD", "Head", { 1 } }, { "NECK", "Neck", { 2 } }, { "SHOULDER", "Shoulders", { 3 } },
    { "BACK", "Back", { 15 } }, { "CHEST", "Chest", { 5 } }, { "WRIST", "Wrists", { 9 } },
    { "HANDS", "Hands", { 10 } }, { "WAIST", "Waist", { 6 } }, { "LEGS", "Legs", { 7 } },
    { "FEET", "Feet", { 8 } }, { "FINGER", "Rings", { 11, 12 } }, { "TRINKET", "Trinkets", { 13, 14 } },
    { "MAIN", "One-hand weapon", { 16 } }, { "SHIELD", "Shield", { 17 } }, { "TWOHAND", "Two-hand weapon", { 16 } },
}
local SLOT_NAME = {}
for _, s in ipairs(SLOTS) do SLOT_NAME[s[1]] = s[2] end

local SRC = {
    Q = { "Quest", { 0.98, 0.82, 0.35 } },
    D = { "Dungeon", { 0.55, 0.72, 1.00 } },
    M = { "Named mob", { 0.80, 0.60, 1.00 } },
    V = { "Vendor", { 0.55, 0.88, 0.62 } },
    C = { "Crafted", { 0.72, 0.72, 0.76 } },
    R = { "Rare mob", { 1.00, 0.62, 0.30 } },
}

-- tank value of each stat (Protection: survive first, then threat)
local WEIGHTS = {
    { "STAMINA", 1.0 }, { "DEFENSE", 1.5 }, { "BLOCK_VALUE", 0.35 }, { "BLOCK_RATING", 1.0 }, { "BLOCK", 1.0 },
    { "PARRY", 1.0 }, { "DODGE", 1.0 }, { "STRENGTH", 0.5 }, { "AGILITY", 0.4 }, { "HIT", 0.6 },
    { "SPELL_POWER", 0.3 }, { "SPELL_DAMAGE", 0.3 }, { "INTELLECT", 0.25 }, { "CRIT", 0.3 },
    { "ATTACK_POWER", 0.12 }, { "SPIRIT", 0.05 }, { "DAMAGE_PER_SECOND", 0.8 }, { "RESISTANCE0", 0.02 },
}
local NICE = {
    STAMINA = "Stamina", STRENGTH = "Strength", AGILITY = "Agility", INTELLECT = "Intellect", SPIRIT = "Spirit",
    DEFENSE = "Defense", BLOCK_VALUE = "Block value", BLOCK = "Block", PARRY = "Parry", DODGE = "Dodge",
    HIT = "Hit", CRIT = "Crit", ATTACK_POWER = "Attack power", SPELL_POWER = "Spell power", SPELL_DAMAGE = "Spell power",
    DAMAGE_PER_SECOND = "Weapon DPS", RESISTANCE0 = "Armor",
}

local function statKey(k)
    k = tostring(k):upper()
    if k:find("RESISTANCE0") then return "RESISTANCE0" end
    for _, w in ipairs(WEIGHTS) do
        if w[1] ~= "RESISTANCE0" and k:find(w[1], 1, true) then
            if w[1] == "BLOCK" and k:find("BLOCK_VALUE", 1, true) then return "BLOCK_VALUE" end
            return w[1]
        end
    end
end

-- {STAMINA = 8, ...} for an item link, or nil if the game hasn't sent it yet
local statCache = {}
local function statsOf(link)
    if not link then return end
    if statCache[link] then return statCache[link] end
    local raw = safe(GetStats, link)
    if not raw then return end
    local out = {}
    for k, v in pairs(raw) do
        local key = statKey(k)
        if key and type(v) == "number" then out[key] = (out[key] or 0) + v end
    end
    statCache[link] = out
    return out
end

local WEIGHT = {}
for _, w in ipairs(WEIGHTS) do WEIGHT[w[1]] = w[2] end
local function score(stats)
    if not stats then return 0 end
    local s = 0
    for k, v in pairs(stats) do s = s + v * (WEIGHT[k] or 0) end
    return s
end

---------------------------------------------------------------------------
-- Item info (asks the game for anything it hasn't cached yet)
---------------------------------------------------------------------------
local pending, waitFrame = {}, CreateFrame("Frame")
local infoCache = {}
local function info(id)
    if infoCache[id] then return infoCache[id] end
    local name, link, quality, _, minLevel, _, subType, _, _, icon = safe(GetInfo, id)
    if not name then
        if not pending[id] then
            pending[id] = true
            if C_Item and C_Item.RequestLoadItemDataByID then safe(C_Item.RequestLoadItemDataByID, id) end
        end
        local _, _, _, _, iconI = safe(GetInfoInstant, id)
        return { id = id, loading = true, icon = iconI }
    end
    local it = { id = id, name = name, link = link, quality = quality or 1, minLevel = minLevel, sub = subType, icon = icon }
    infoCache[id] = it
    return it
end

---------------------------------------------------------------------------
-- Picking the options for a level
---------------------------------------------------------------------------
local function myFaction()
    local f = UnitFactionGroup and UnitFactionGroup("player")
    return f == "Alliance" and "A" or "H"
end

local function equipped(slotKey)
    local s
    for _, x in ipairs(SLOTS) do if x[1] == slotKey then s = x end end
    if not s then return end
    -- for rings and trinkets compare against the weaker one you wear
    local best
    for _, inv in ipairs(s[3]) do
        local link = GetInventoryItemLink("player", inv)
        local st = link and statsOf(link)
        local sc = st and score(st) or 0
        if not best or sc < best.score then best = { link = link, stats = st or {}, score = sc } end
    end
    -- a shield slot with nothing in it, or a two-hander in your main hand
    return best
end

-- rare mob drops a Paladin tank can use, sorted into slots (from RareData.lua)
local EQUIP = {
    INVTYPE_HEAD = "HEAD", INVTYPE_NECK = "NECK", INVTYPE_SHOULDER = "SHOULDER", INVTYPE_CLOAK = "BACK",
    INVTYPE_CHEST = "CHEST", INVTYPE_ROBE = "CHEST", INVTYPE_WRIST = "WRIST", INVTYPE_HAND = "HANDS",
    INVTYPE_WAIST = "WAIST", INVTYPE_LEGS = "LEGS", INVTYPE_FEET = "FEET", INVTYPE_FINGER = "FINGER",
    INVTYPE_TRINKET = "TRINKET", INVTYPE_WEAPON = "MAIN", INVTYPE_WEAPONMAINHAND = "MAIN",
    INVTYPE_SHIELD = "SHIELD", INVTYPE_2HWEAPON = "TWOHAND",
}
local OK_WEAPON = { [0] = true, [1] = true, [4] = true, [5] = true, [6] = true, [7] = true, [8] = true }
-- slot key for an item a Paladin tank could use, or nil
local function tankSlot(id)
    local _, _, _, equipLoc, _, classID, subID = safe(GetInfoInstant, id)
    local slot = equipLoc and EQUIP[equipLoc]
    if not slot then return end
    if classID == 2 and not OK_WEAPON[subID or -1] then return end         -- daggers, staves, fists...
    if classID == 4 and slot ~= "BACK" and (subID == 1 or subID == 2) then return end -- cloth and leather
    return slot
end
ns.GearTankSlot = tankSlot

local rareGear, rareMissing = {}, true
local function buildRareGear()
    if not rareMissing then return end
    rareMissing = false
    local have = {}
    for _, g in ipairs(rareGear) do have[g[1]] = true end
    for _, r in ipairs(ns.RARES or {}) do
        for _, id in ipairs(r[7] or {}) do
            if not have[id] then
                local _, _, _, equipLoc = safe(GetInfoInstant, id)
                if not equipLoc then rareMissing = true
                else
                    have[id] = true
                    local slot = tankSlot(id)
                    if slot then
                        table.insert(rareGear, { id, slot, math.max(1, r[3] - 3), "R", r[2] .. " (" .. (r[4] and "rare elite, " or "rare, ") .. r[1] .. ")", nil, nil, r })
                    end
                end
            end
        end
    end
end

local function options(slotKey, level)
    local fac = myFaction()
    local list = {}
    buildRareGear()
    local all = {}
    for _, g in ipairs(ns.GEAR or {}) do table.insert(all, g) end
    for _, g in ipairs(rareGear) do table.insert(all, g) end
    for _, g in ipairs(all) do
        if g[2] == slotKey and (not g[6] or g[6] == fac or DB.gearOtherFaction) and not (DB.gearHideCrafted and g[4] == "C") then
            local it = info(g[1])
            local req = it.minLevel or g[3]
            if req <= level then
                it.req = req; it.src = g[4]; it.where = g[5]; it.fac = g[6]; it.chance = g[7]; it.rare = g[8]
                it.stats = it.link and statsOf(it.link)
                it.score = score(it.stats)
                table.insert(list, it)
            end
        end
    end
    -- best first; among equals, the closer to your level the better
    -- (items the game is still sending sort by level until their stats arrive)
    for _, it in ipairs(list) do it.rank = it.stats and it.score or (it.req * 0.7) end
    table.sort(list, function(a, b)
        if a.rank ~= b.rank then return a.rank > b.rank end
        if a.req ~= b.req then return a.req > b.req end
        return a.id < b.id
    end)
    -- keep it to things that still matter at this level, topped up with older picks if a slot is thin
    local out, older = {}, {}
    for _, it in ipairs(list) do
        if it.req >= level - 14 then
            if #out < 8 then table.insert(out, it) end
        else table.insert(older, it) end
    end
    for _, it in ipairs(older) do if #out < 3 then table.insert(out, it) end end
    return out
end

-- your own drop rate from the Bestiary, if you've looted it
local function myRate(id)
    local best
    for _, m in pairs(DB and DB.mobs or {}) do
        local it = m.items and m.items[id]
        if it and m.looted and m.looted > 0 then
            if not best or m.looted > best.looted then best = { looted = m.looted, count = it.count, name = m.name } end
        end
    end
    return best
end

---------------------------------------------------------------------------
-- Window
---------------------------------------------------------------------------
local win, refresh
local QCOL = ITEM_QUALITY_COLORS

local function qcolor(q)
    local c = QCOL and QCOL[q or 1]
    if c then return c.r, c.g, c.b end
    return 1, 1, 1
end

local function setLevel(l, auto)
    DB.gearLevel = math.max(1, math.min(60, l))
    DB.gearLevelAuto = auto or nil
    refresh()
end

local function showTip(owner, link, id)
    GameTooltip:SetOwner(owner, "ANCHOR_RIGHT")
    if link then GameTooltip:SetHyperlink(link) else GameTooltip:SetItemByID(id) end
    GameTooltip:Show()
end

local function detail(it)
    local d = win.detail
    win.sel = it and it.id
    for _, r in ipairs(win.rows) do r.sel:SetShown(r.it and it and r.it.id == it.id) end
    if not it then d:Hide(); win.hint:Show(); return end
    win.hint:Hide(); d:Show()
    d.icon:SetIcon(it.icon)
    d.name:SetText(it.name or "Loading...")
    d.name:SetTextColor(qcolor(it.quality))
    d.sub:SetText("Requires level " .. (it.req or "?") .. "  ·  " .. (SLOT_NAME[win.slot] or "") .. (it.sub and ("  ·  " .. it.sub) or ""))
    local src = SRC[it.src] or SRC.D
    d.tag:SetText(src[1]); d.tag:SetTextColor(unpack(src[2]))
    d.tagBg:SetVertexColor(src[2][1], src[2][2], src[2][3], 0.14)
    d.tagBox:SetWidth((d.tag:GetStringWidth() or 40) + 16)
    local where = it.where or ""
    local how
    if it.src == "Q" then how = "Quest reward: " .. where
    elseif it.src == "C" then how = "Made with " .. where .. ". Buy it on the Auction House or ask a crafter."
    elseif it.src == "V" then how = "Sold by " .. where
    elseif it.src == "R" then how = "Rare spawn: " .. where .. ". Rares respawn slowly, check back if it's not up."
    else how = "Drops from " .. where end
    if it.fac then how = how .. (it.fac == "A" and "  |cff8d8f96(Alliance only)|r" or "  |cff8d8f96(Horde only)|r") end
    d.where:SetText(how)

    -- drop chance
    local lines = {}
    if it.src == "D" or it.src == "M" or it.src == "R" then
        if it.chance then
            table.insert(lines, "|cff8d8f96Drop chance|r  " .. it.chance)
        else
            table.insert(lines, "|cff8d8f96Drop chance|r  not published for Forever yet")
        end
        local mine = myRate(it.id)
        if mine then
            table.insert(lines, string.format("|cff8d8f96Your luck|r  %d of %d %s kills (%.0f%%)", mine.count, mine.looted, mine.name, 100 * mine.count / mine.looted))
        end
    elseif it.src == "Q" then
        table.insert(lines, "|cff8d8f96Drop chance|r  guaranteed, it's a quest reward")
    elseif it.src == "V" then
        table.insert(lines, "|cff8d8f96Drop chance|r  always for sale")
    end
    d.chance:SetText(table.concat(lines, "\n"))

    -- stats vs what you wear
    local now = equipped(win.slot)
    local mine = (now and now.stats) or {}
    local new = it.stats or {}
    local keys, seen = {}, {}
    for _, w in ipairs(WEIGHTS) do
        local k = w[1]
        if (new[k] or mine[k]) and not seen[NICE[k]] then seen[NICE[k]] = true; table.insert(keys, k) end
    end
    local out = {}
    if not it.stats then
        table.insert(out, "|cff8d8f96Stats are still loading. Click again in a second.|r")
    else
        for _, k in ipairs(keys) do
            local a, b = new[k] or 0, mine[k] or 0
            local diff = a - b
            local dtxt = diff > 0 and ("|cff6bdb80+" .. diff .. "|r") or (diff < 0 and ("|cffff7878" .. diff .. "|r") or "|cff8d8f96=|r")
            if k == "DAMAGE_PER_SECOND" then
                dtxt = diff > 0 and ("|cff6bdb80+" .. string.format("%.1f", diff) .. "|r") or (diff < 0 and ("|cffff7878" .. string.format("%.1f", diff) .. "|r") or "|cff8d8f96=|r")
                a = string.format("%.1f", a); b = string.format("%.1f", b)
            end
            table.insert(out, string.format("%s  |cffffffff%s|r  |cff8d8f96vs %s|r   %s", NICE[k], tostring(a), tostring(b), dtxt))
            if #out >= 9 then break end
        end
        if #out == 0 then table.insert(out, "|cff8d8f96No tank stats on this one.|r") end
    end
    d.stats:SetText(table.concat(out, "\n"))
    local nowLabel = now and now.link or "|cff8d8f96nothing|r"
    d.vsNow:SetText("Compared to " .. nowLabel)
    local verdict
    if not it.stats then verdict = ""
    elseif not now or not now.link then verdict = "|cff6bdb80Fills an empty slot.|r"
    elseif it.score > now.score + 0.5 then verdict = "|cff6bdb80Upgrade for tanking.|r"
    elseif it.score < now.score - 0.5 then verdict = "|cffff7878What you have is better for tanking.|r"
    else verdict = "|cff8d8f96About the same as what you have.|r" end
    if (it.req or 0) > UnitLevel("player") then verdict = verdict .. "  |cffffd36bYou can wear it at " .. it.req .. ".|r" end
    d.verdict:SetText(verdict)
    if win.slot == "TWOHAND" then
        d.note:SetText("A two-hander means no shield. Good for questing as Retribution, not for tanking dungeons.")
    else d.note:SetText("") end
    d.link = it.link; d.id = it.id
    d.mapBtn:SetShown(it.rare ~= nil and it.rare[5] ~= nil and ns.RareWaypoint ~= nil)
    d.rare = it.rare
end

refresh = function()
    if not win or not win:IsShown() then return end
    local level = DB.gearLevel or UnitLevel("player")
    win.lvl:SetText(level)
    win.me:SetText(level == UnitLevel("player") and "your level" or ("you are " .. UnitLevel("player")))
    win.crafted:SetChecked(DB.gearHideCrafted)
    win.other:SetChecked(DB.gearOtherFaction)

    -- slot list with how many options each has
    for _, b in ipairs(win.slotBtns) do
        local n = #options(b.key, level)
        b.count:SetText(n > 0 and n or "")
        b:SetAlpha(n > 0 and 1 or 0.45)
        b.bg:SetVertexColor(1, 1, 1, b.key == win.slot and 0.10 or 0)
    end

    local list = options(win.slot, level)
    local now = equipped(win.slot)
    win.listHead:SetText((SLOT_NAME[win.slot] or ""):upper() .. "  ·  LEVEL " .. level)
    local y = 0
    for i, r in ipairs(win.rows) do
        local it = list[i]
        r.it = it
        if it then
            r:Show()
            r.icon:SetIcon(it.icon)
            r.name:SetText(it.name or ("Loading item " .. it.id .. "..."))
            r.name:SetTextColor(qcolor(it.quality))
            local src = SRC[it.src] or SRC.D
            local hex = string.format("|cff%02x%02x%02x", math.floor(src[2][1] * 255), math.floor(src[2][2] * 255), math.floor(src[2][3] * 255))
            r.sub:SetText(hex .. src[1] .. "|r  |cff8d8f96·  level " .. it.req .. "  ·  " .. (it.where or "") .. "|r")
            local badge = ""
            if i == 1 and it.stats then badge = "|cfff58cbaBest|r" end
            if now and now.link and it.link and now.link:match("item:(%d+)") == tostring(it.id) then badge = "|cff6bdb80Wearing|r"
            elseif it.stats and now and it.score > now.score + 0.5 and badge == "" then badge = "|cff6bdb80Upgrade|r" end
            r.badge:SetText(badge)
            r.sel:SetShown(win.sel == it.id)
        else
            r:Hide()
        end
    end
    win.empty:SetShown(#list == 0)
    win.empty:SetText("Nothing for this slot by level " .. level .. " yet. Try a higher level.")
    -- keep the detail panel in sync (or pick the best one)
    local keep
    for _, it in ipairs(list) do if it.id == win.sel then keep = it end end
    detail(keep or list[1])
end

local function build()
    local f = UI.Window("PallyPalGear", 760, 560, "Gear finder", "tank gear by level")
    win = f
    win.slot = "CHEST"
    local c = f.content

    -- level picker
    local top = CreateFrame("Frame", nil, c); top:SetPoint("TOPLEFT"); top:SetPoint("TOPRIGHT"); top:SetHeight(64)
    UI.Flat(top, { 1, 1, 1, 0.03 }, { 1, 1, 1, 0.06 }, "small")
    local cap = UI.Title(top, 10, C.head); cap:SetPoint("TOPLEFT", 14, -10); cap:SetText("LEVEL")
    local minus = UI.Button(top, 26, 26, "<"); minus:SetPoint("TOPLEFT", 12, -26)
    f.lvl = UI.Title(top, 24); f.lvl:SetPoint("LEFT", minus, "RIGHT", 10, 0); f.lvl:SetWidth(36); f.lvl:SetJustifyH("CENTER")
    local plus = UI.Button(top, 26, 26, ">"); plus:SetPoint("LEFT", f.lvl, "RIGHT", 10, 0)
    f.me = UI.Text(top, 10, C.muted); f.me:SetPoint("LEFT", plus, "RIGHT", 10, 0)
    minus:SetScript("OnClick", function() setLevel((DB.gearLevel or UnitLevel("player")) - 1) end)
    plus:SetScript("OnClick", function() setLevel((DB.gearLevel or UnitLevel("player")) + 1) end)
    local chips = { { "Me", function() return UnitLevel("player") end, true } }
    for l = 10, 60, 10 do table.insert(chips, { tostring(l), function() return l end }) end
    local prev
    for i = #chips, 1, -1 do
        local ch = chips[i]
        local b = UI.Button(top, i == 1 and 40 or 34, 24, ch[1], i == 1 and "primary" or nil)
        if prev then b:SetPoint("RIGHT", prev, "LEFT", -6, 0) else b:SetPoint("TOPRIGHT", -12, -26) end
        b:SetScript("OnClick", function() setLevel(ch[2](), ch[3]) end)
        prev = b
    end
    -- scroll wheel on the level box changes the level
    top:EnableMouseWheel(true)
    top:SetScript("OnMouseWheel", function(_, d) setLevel((DB.gearLevel or UnitLevel("player")) + d) end)

    -- filters
    local function check(label, key, x)
        local cb = CreateFrame("CheckButton", nil, c, "UICheckButtonTemplate")
        cb:SetSize(22, 22); cb:SetPoint("TOPLEFT", x, -70)
        local t = UI.Text(c, 11, C.muted); t:SetPoint("LEFT", cb, "RIGHT", 2, 0); t:SetText(label)
        cb:SetScript("OnClick", function(self) DB[key] = self:GetChecked() and true or nil; refresh() end)
        return cb, t
    end
    f.crafted = check("Hide crafted gear", "gearHideCrafted", 0)
    f.other = check("Show other faction's quests and vendors", "gearOtherFaction", 150)

    -- slot column
    local slotCol = CreateFrame("Frame", nil, c); slotCol:SetPoint("TOPLEFT", 0, -98); slotCol:SetPoint("BOTTOMLEFT"); slotCol:SetWidth(150)
    f.slotBtns = {}
    for i, s in ipairs(SLOTS) do
        local b = CreateFrame("Button", nil, slotCol); b:SetHeight(26); b:SetPoint("TOPLEFT", 0, -(i - 1) * 27); b:SetPoint("RIGHT")
        b.bg = b:CreateTexture(nil, "BACKGROUND"); b.bg:SetAllPoints(); b.bg:SetColorTexture(1, 1, 1, 1); b.bg:SetVertexColor(1, 1, 1, 0)
        b.t = UI.Text(b, 12); b.t:SetPoint("LEFT", 10, 0); b.t:SetText(s[2])
        b.count = UI.Text(b, 10, C.muted); b.count:SetPoint("RIGHT", -8, 0)
        b.key = s[1]
        b:SetScript("OnClick", function() win.slot = s[1]; win.sel = nil; refresh() end)
        b:SetScript("OnEnter", function(self) if self.key ~= win.slot then self.bg:SetVertexColor(1, 1, 1, 0.05) end end)
        b:SetScript("OnLeave", function(self) self.bg:SetVertexColor(1, 1, 1, self.key == win.slot and 0.10 or 0) end)
        f.slotBtns[i] = b
    end

    -- options list
    local list = CreateFrame("Frame", nil, c); list:SetPoint("TOPLEFT", 162, -98); list:SetPoint("BOTTOM"); list:SetWidth(300)
    f.listHead = UI.Title(list, 10, C.head); f.listHead:SetPoint("TOPLEFT", 2, 0)
    f.rows = {}
    for i = 1, 8 do
        local r = CreateFrame("Button", nil, list); r:SetHeight(48); r:SetPoint("TOPLEFT", 0, -16 - (i - 1) * 51); r:SetPoint("RIGHT")
        UI.Flat(r, { 1, 1, 1, 0.025 }, { 1, 1, 1, 0.05 }, "small")
        r.sel = r:CreateTexture(nil, "BORDER"); r.sel:SetAllPoints(); r.sel:SetColorTexture(0.96, 0.55, 0.73, 0.10); r.sel:Hide()
        r.icon = UI.Icon(r, 32); r.icon:SetPoint("LEFT", 8, 0)
        r.name = UI.Title(r, 12); r.name:SetPoint("TOPLEFT", 48, -9); r.name:SetPoint("RIGHT", -58, 0); r.name:SetJustifyH("LEFT"); r.name:SetWordWrap(false)
        r.sub = UI.Text(r, 10, C.muted); r.sub:SetPoint("TOPLEFT", r.name, "BOTTOMLEFT", 0, -4); r.sub:SetPoint("RIGHT", -8, 0); r.sub:SetJustifyH("LEFT"); r.sub:SetWordWrap(false)
        r.badge = UI.Text(r, 10); r.badge:SetPoint("TOPRIGHT", -8, -9)
        r:SetScript("OnClick", function(self)
            if not self.it then return end
            if IsModifiedClick and IsModifiedClick("CHATLINK") and self.it.link then
                if ChatEdit_InsertLink then ChatEdit_InsertLink(self.it.link) end
                return
            end
            detail(self.it)
        end)
        r:SetScript("OnEnter", function(self) if self.it then showTip(self, self.it.link, self.it.id) end end)
        r:SetScript("OnLeave", function() GameTooltip:Hide() end)
        f.rows[i] = r
    end
    f.empty = UI.Text(list, 12, C.muted); f.empty:SetPoint("TOPLEFT", 4, -24); f.empty:SetPoint("RIGHT"); f.empty:SetJustifyH("LEFT")

    -- detail panel
    local d = CreateFrame("Frame", nil, c); d:SetPoint("TOPLEFT", 474, -98); d:SetPoint("BOTTOMRIGHT")
    UI.Flat(d, { 1, 1, 1, 0.03 }, { 1, 1, 1, 0.06 }, "small")
    f.detail = d
    d.icon = UI.Icon(d, 40); d.icon:SetPoint("TOPLEFT", 12, -12)
    d.icon:EnableMouse(true)
    d.icon:SetScript("OnEnter", function(self) if d.id then showTip(self, d.link, d.id) end end)
    d.icon:SetScript("OnLeave", function() GameTooltip:Hide() end)
    d.name = UI.Title(d, 13); d.name:SetPoint("TOPLEFT", d.icon, "TOPRIGHT", 10, -2); d.name:SetPoint("RIGHT", -10, 0); d.name:SetJustifyH("LEFT")
    d.sub = UI.Text(d, 10, C.muted); d.sub:SetPoint("TOPLEFT", d.name, "BOTTOMLEFT", 0, -4); d.sub:SetPoint("RIGHT", -10, 0); d.sub:SetJustifyH("LEFT")
    d.tagBox = CreateFrame("Frame", nil, d); d.tagBox:SetHeight(18); d.tagBox:SetPoint("TOPLEFT", 12, -62)
    d.tagBg = d.tagBox:CreateTexture(nil, "BACKGROUND"); d.tagBg:SetAllPoints(); d.tagBg:SetColorTexture(1, 1, 1, 1)
    d.tag = UI.Text(d.tagBox, 10, nil, "", UI.FONT_SB); d.tag:SetPoint("CENTER")
    d.where = UI.Text(d, 11); d.where:SetPoint("TOPLEFT", 12, -86); d.where:SetPoint("RIGHT", -12, 0); d.where:SetJustifyH("LEFT"); d.where:SetWordWrap(true)
    d.chance = UI.Text(d, 11); d.chance:SetPoint("TOPLEFT", d.where, "BOTTOMLEFT", 0, -8); d.chance:SetPoint("RIGHT", -12, 0); d.chance:SetJustifyH("LEFT")
    local sh = UI.Title(d, 10, C.head); sh:SetPoint("TOPLEFT", d.chance, "BOTTOMLEFT", 0, -14); sh:SetText("VS WHAT YOU WEAR")
    d.vsNow = UI.Text(d, 10, C.muted); d.vsNow:SetPoint("TOPLEFT", sh, "BOTTOMLEFT", 0, -4); d.vsNow:SetPoint("RIGHT", -12, 0); d.vsNow:SetJustifyH("LEFT"); d.vsNow:SetWordWrap(false)
    d.stats = UI.Text(d, 11); d.stats:SetPoint("TOPLEFT", d.vsNow, "BOTTOMLEFT", 0, -8); d.stats:SetPoint("RIGHT", -12, 0); d.stats:SetJustifyH("LEFT")
    d.stats:SetSpacing(3)
    d.verdict = UI.Text(d, 11); d.verdict:SetPoint("TOPLEFT", d.stats, "BOTTOMLEFT", 0, -10); d.verdict:SetPoint("RIGHT", -12, 0); d.verdict:SetJustifyH("LEFT"); d.verdict:SetWordWrap(true)
    d.note = UI.Text(d, 10, C.muted); d.note:SetPoint("BOTTOMLEFT", 12, 10); d.note:SetPoint("RIGHT", -12, 0); d.note:SetJustifyH("LEFT"); d.note:SetWordWrap(true)
    f.hint = UI.Text(c, 12, C.muted); f.hint:SetPoint("CENTER", d, "CENTER"); f.hint:SetText("Pick an item to compare it.")
    d.mapBtn = UI.Button(d, 120, 24, "Show on map"); d.mapBtn:SetPoint("BOTTOMRIGHT", -12, 34); d.mapBtn:Hide()
    d.mapBtn:SetScript("OnClick", function() if d.rare and ns.RareWaypoint then ns.RareWaypoint(d.rare) end end)

    local foot = UI.Text(c, 10, C.muted); foot:SetPoint("BOTTOMLEFT", list, "BOTTOMLEFT", 2, 0); foot:SetPoint("RIGHT", list, "RIGHT")
    foot:SetJustifyH("LEFT")
    foot:SetText("Shift-click an item to link it in chat. Hover for the full tooltip.")

    f:HookScript("OnShow", function()
        if not DB.gearLevel or DB.gearLevelAuto then DB.gearLevel = UnitLevel("player"); DB.gearLevelAuto = true end
        C_Timer.After(0, refresh)
    end)
end

-- for the Rares page: what this item means for you
function ns.GearJudge(id)
    local it = info(id)
    local slot = tankSlot(id)
    it.slot = slot
    it.stats = it.link and statsOf(it.link)
    it.score = score(it.stats)
    if slot then
        local now = equipped(slot)
        it.upgrade = it.stats and (not now or not now.link or it.score > now.score + 0.5)
    end
    return it
end

function ns.OpenGearAt(slot, level)
    if not win then build() end
    win.slot = slot or win.slot
    if level then DB.gearLevel = level; DB.gearLevelAuto = nil end
    if not win:IsShown() then
        local home = _G.PallyPalHome
        if home and home:IsShown() and home.go then home.go(ns.ToggleGear) else win:Show() end
    end
    refresh()
end

function ns.ToggleGear()
    if not win then build() end
    win:SetShown(not win:IsShown())
end

-- items arrive from the server a moment after we ask: redraw once they're in
local again
waitFrame:SetScript("OnEvent", function(_, ev, id)
    if ev == "GET_ITEM_INFO_RECEIVED" then
        if not pending[id] then return end
        pending[id] = nil
    else
        statCache = {}
    end
    if again or not win or not win:IsShown() then return end
    again = true
    C_Timer.After(0.3, function() again = false; refresh() end)
end)

local prevSlash = ns.HandleSlash
function ns.HandleSlash(msg)
    if msg == "gear" or msg == "loot" then ns.ToggleGear(); return true end
    return prevSlash and prevSlash(msg) or false
end

local prevInit = ns.InitLearn
function ns.InitLearn(db)
    if prevInit then prevInit(db) end
    DB = db
    for _, e in ipairs({ "GET_ITEM_INFO_RECEIVED", "PLAYER_EQUIPMENT_CHANGED" }) do pcall(waitFrame.RegisterEvent, waitFrame, e) end
end
