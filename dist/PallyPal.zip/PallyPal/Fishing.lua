-- PallyPal Fishing: your progress from 1 to 300, where to fish, lures and how
-- to unlock each rank. Route and numbers from wow-professions.com's WoW Forever
-- Fishing guide and timesaver.gg's Forever fishing data (Horde side).
local ADDON, ns = ...
local UI = ns.UI
local DB

local function ret(ok, ...) if ok then return ... end end
local function safe(f, ...)
    if not f then return end
    return ret(pcall(f, ...))
end

-- Fishing skill at which nothing gets away in each zone (skill + pole/lure/gear bonus counts)
local ZONE = {}
for skill, list in pairs({
    [25]  = { "Durotar", "Mulgore", "Tirisfal Glades", "Dun Morogh", "Elwynn Forest", "Teldrassil" },
    [75]  = { "Orgrimmar", "Thunder Bluff", "Undercity", "The Barrens", "Silverpine Forest", "Darkshore", "Loch Modan", "Westfall",
              "Blackfathom Deeps", "The Deadmines", "Wailing Caverns", "Stormwind City", "Ironforge", "Darnassus" },
    [150] = { "Ashenvale", "Duskwood", "Hillsbrad Foothills", "Redridge Mountains", "Stonetalon Mountains", "Wetlands" },
    [225] = { "Alterac Mountains", "Arathi Highlands", "Desolace", "Dustwallow Marsh", "Scarlet Monastery", "Stranglethorn Vale",
              "Swamp of Sorrows", "Thousand Needles" },
    [300] = { "Azshara", "Felwood", "Feralas", "Jaguero Isle", "Maraudon", "Moonglade", "Sunken Temple", "Tanaris",
              "The Hinterlands", "Un'Goro Crater", "Western Plaguelands" },
    [425] = { "Burning Steppes", "Deadwind Pass", "Eastern Plaguelands", "Silithus", "Winterspring", "Stratholme", "Scholomance", "Zul'Gurub" },
}) do for _, z in ipairs(list) do ZONE[z] = skill end end

local TIERS = {
    { from = 1, to = 75, name = "Apprentice",
      where = "Tirisfal Glades, Durotar or Mulgore. Capital cities don't count yet. At 25 skill nothing gets away here.",
      how = "Learn Fishing from any Fishing trainer, then buy a Fishing Pole and Shiny Baubles. In Tirisfal: Martine Tramblay at Death's Watch Waystation. In Undercity: Lizbeth Cromwell, next to the trainer." },
    { from = 75, to = 150, name = "Journeyman",
      where = "Undercity, Orgrimmar, Thunder Bluff, The Barrens or Silverpine Forest. Nothing gets away at 75.",
      how = "Journeyman from any Fishing trainer (Armand Cromwell in Undercity). Needs level 10 and Fishing 50. Nightcrawlers help if fish escape." },
    { from = 150, to = 225, name = "Expert",
      where = "Dustwallow Marsh is best. Also Arathi Highlands, Desolace, Thousand Needles, Stranglethorn Vale or Swamp of Sorrows. Use Bright Baubles.",
      how = "Read the book \"Expert Fishing - The Bass and You\" from Old Man Heming at the bottom of Booty Bay (or the Auction House). Needs level 20 and Fishing 125. Buy Bright Baubles from him too." },
    { from = 225, to = 300, name = "Artisan",
      where = "Feralas, Tanaris, Felwood, The Hinterlands, Un'Goro Crater or Western Plaguelands, with Bright Baubles on.",
      how = "Quest \"Nat Pagle, Angler Extreme\" from Nat Pagle at Tidefury Cove, Dustwallow Marsh. Needs level 35 and Fishing 225. Catch one of each: Feralas Ahi (Feralas), Misty Reed Mahi Mahi (Swamp of Sorrows), Sar'theris Striker (Desolace) and Savage Coast Blue Sailfin (Stranglethorn Vale)." },
    { from = 300, to = 425, name = "Past 300",
      where = "Winterspring, Eastern Plaguelands, Burning Steppes, Silithus and Deadwind Pass need 425, so you need +125 from lures and gear.",
      how = "Stack the best lure you have with fishing gear like the Wide-Brimmed Fishing Hat." },
}

local LURES = {
    { "Shiny Bauble", 25 }, { "\"Secret\" Bait", 25 }, { "Wide-Brimmed Fishing Hat", 25 },
    { "Nightcrawlers", 50 }, { "Aquadynamic Fish Lens", 50 },
    { "Bright Baubles", 75 }, { "Flesh Eating Worm", 75 }, { "Aquadynamic Fish Attractor", 100 },
}

local CAMP = {
    { 20, "Fish Bowl", "A buff to all stats for everyone sitting nearby." },
    { 140, "Fishing Rack", "Uncommon fish for 1 hour, Fishing Skill lures, and the Fish Bowl buff." },
    { 300, "Fishing Hut", "Rare fish for 1 hour, Fishing Skill lures, and the Fish Bowl buff." },
}

---------------------------------------------------------------------------
-- Your fishing
---------------------------------------------------------------------------
local function myFishing()
    if not GetProfessions then return end
    local _, _, _, fishing = safe(GetProfessions)
    if not fishing then return end
    local name, icon, skill, max, _, _, _, mod = safe(GetProfessionInfo, fishing)
    if not name then return end
    return { skill = skill or 0, max = max or 0, bonus = mod or 0 }
end
ns.MyFishing = myFishing

local function tierFor(skill)
    for i, t in ipairs(TIERS) do if skill < t.to then return i, t end end
    return #TIERS, TIERS[#TIERS]
end

-- the next thing to unlock, for Professions + the To do panel
function ns.FishingNext()
    local f = myFishing()
    if not f then return nil end
    local lvl = UnitLevel("player")
    if f.max <= 75 and f.skill >= 50 and lvl >= 10 then return "Train Journeyman Fishing", "Any Fishing trainer" end
    if f.max <= 150 and f.skill >= 125 and lvl >= 20 then return "Get Expert Fishing", "Book from Old Man Heming, Booty Bay" end
    if f.max <= 225 and f.skill >= 225 and lvl >= 35 then return "Unlock Artisan Fishing", "Nat Pagle quest, Dustwallow Marsh" end
end

---------------------------------------------------------------------------
-- Window
---------------------------------------------------------------------------
local win
local function refresh()
    if not win or not win:IsShown() then return end
    local f = myFishing()
    local skill = f and f.skill or 0
    local eff = f and (f.skill + f.bonus) or 0
    local ti = tierFor(skill)

    -- top: skill + progress to the next rank cap
    if not f then
        win.big:SetText("--")
        win.cap:SetText("You haven't learned Fishing yet. Any Fishing trainer teaches it, it's free to keep.")
        win.fill:SetWidth(4)
    else
        win.big:SetText(skill)
        local t = TIERS[ti]
        win.cap:SetText(t.name .. "  ·  " .. skill .. " / " .. f.max .. (f.bonus > 0 and ("   (+" .. f.bonus .. " from lure and gear)") or ""))
        local w = win.track:GetWidth() or 300
        win.fill:SetWidth(math.max(4, w * math.min(1, skill / 300)))
    end

    -- right here
    local zone = GetRealZoneText and GetRealZoneText() or ""
    local need = ZONE[zone]
    if need then
        if eff >= need then win.here:SetText("|cff6bdb80Good spot.|r Nothing gets away in " .. zone .. " at your skill.")
        else win.here:SetText("|cffffd36bFish will get away in " .. zone .. ".|r You need " .. need .. " (you have " .. eff .. "). A lure can close the gap.") end
    else
        win.here:SetText("Pal doesn't have fishing data for " .. (zone ~= "" and zone or "this place") .. ".")
    end

    for i, card in ipairs(win.cards) do
        local t = TIERS[i]
        local done = skill >= t.to
        local now = i == ti and f ~= nil
        card.state:SetText(done and "|cff6bdb80Done|r" or now and "|cfff58cbaYou are here|r" or (t.from .. " - " .. t.to))
        card:SetBackdropBorderColor(now and 0.96 or 1, now and 0.55 or 1, now and 0.73 or 1, now and 0.6 or 0.06)
        card:SetAlpha(done and 0.6 or 1)
    end
    for i, row in ipairs(win.camp) do
        local c = CAMP[i]
        row.t:SetText((skill >= c[1] and "|cff6bdb80" or "|cff8d8f96") .. c[2] .. "|r  |cff8d8f96(" .. c[1] .. ")|r  " .. c[3])
    end
end

local function build()
    local f = UI.Window("PallyPalFishing", 480, 600, "Fishing", "1 to 300")
    local sf = UI.Scroll(f.content); sf:SetPoint("TOPLEFT"); sf:SetPoint("BOTTOMRIGHT")
    if sf.SetClipsChildren then sf:SetClipsChildren(true) end
    local c = sf.child
    c:SetWidth(444)

    -- banner with your skill
    local top = CreateFrame("Frame", nil, c); top:SetPoint("TOPLEFT"); top:SetPoint("RIGHT"); top:SetHeight(110)
    local art = top:CreateTexture(nil, "BACKGROUND"); art:SetAllPoints(); art:SetTexture(UI.MEDIA .. "art4"); art:SetTexCoord(0, 1, 0.45, 0.85)
    local shade = top:CreateTexture(nil, "BORDER"); shade:SetAllPoints(); shade:SetColorTexture(0, 0, 0, 0.35)
    f.big = UI.Title(top, 34); f.big:SetPoint("BOTTOMLEFT", 14, 30)
    f.cap = UI.Text(top, 11, { 0.92, 0.9, 0.88, 1 }); f.cap:SetPoint("LEFT", f.big, "RIGHT", 12, -6); f.cap:SetPoint("RIGHT", -12, 0); f.cap:SetJustifyH("LEFT")
    f.track = CreateFrame("Frame", nil, top); f.track:SetPoint("BOTTOMLEFT", 14, 14); f.track:SetPoint("BOTTOMRIGHT", -14, 14); f.track:SetHeight(6)
    UI.Flat(f.track, { 1, 1, 1, 0.15 }, { 1, 1, 1, 0 }, "pill")
    f.fill = CreateFrame("Frame", nil, f.track); f.fill:SetPoint("TOPLEFT"); f.fill:SetPoint("BOTTOMLEFT"); f.fill:SetWidth(4)
    UI.Flat(f.fill, { 0.96, 0.55, 0.73, 1 }, { 1, 1, 1, 0 }, "pill")

    local y = -122
    f.here = UI.Text(c, 12); f.here:SetPoint("TOPLEFT", 0, y); f.here:SetPoint("RIGHT"); f.here:SetJustifyH("LEFT")
    y = y - 34

    local h = UI.Title(c, 10, UI.C.head); h:SetPoint("TOPLEFT", 0, y); h:SetText("YOUR ROUTE"); y = y - 18
    f.cards = {}
    for i, t in ipairs(TIERS) do
        local card = CreateFrame("Frame", nil, c)
        UI.Flat(card, { 1, 1, 1, 0.03 }, { 1, 1, 1, 0.06 }, "small")
        card:SetPoint("TOPLEFT", 0, y); card:SetPoint("RIGHT")
        local nm = UI.Title(card, 13); nm:SetPoint("TOPLEFT", 12, -10); nm:SetText(t.name)
        card.state = UI.Text(card, 11, UI.C.muted); card.state:SetPoint("TOPRIGHT", -12, -11)
        local w = UI.Text(card, 11); w:SetPoint("TOPLEFT", nm, "BOTTOMLEFT", 0, -6); w:SetWidth(420); w:SetJustifyH("LEFT"); w:SetWordWrap(true)
        w:SetText("|cff8d8f96Where:|r " .. t.where)
        local hw = UI.Text(card, 11); hw:SetPoint("TOPLEFT", w, "BOTTOMLEFT", 0, -6); hw:SetWidth(420); hw:SetJustifyH("LEFT"); hw:SetWordWrap(true)
        hw:SetText("|cff8d8f96How:|r " .. t.how)
        local ch = 10 + 16 + 6 + (w:GetStringHeight() or 30) + 6 + (hw:GetStringHeight() or 30) + 12
        ch = math.max(84, ch)
        card:SetHeight(ch)
        y = y - ch - 8
        f.cards[i] = card
    end

    y = y - 8
    local h2 = UI.Title(c, 10, UI.C.head); h2:SetPoint("TOPLEFT", 0, y); h2:SetText("LURES AND GEAR (ADD TO YOUR SKILL)"); y = y - 18
    for i, l in ipairs(LURES) do
        local col, row = (i - 1) % 2, math.floor((i - 1) / 2)
        local t = UI.Text(c, 11); t:SetPoint("TOPLEFT", col * 222, y - row * 18)
        t:SetText("|cfff58cba+" .. l[2] .. "|r  " .. l[1])
    end
    y = y - math.ceil(#LURES / 2) * 18 - 14

    local h3 = UI.Title(c, 10, UI.C.head); h3:SetPoint("TOPLEFT", 0, y); h3:SetText("CAMP UNLOCKS (NEW IN FOREVER)"); y = y - 18
    f.camp = {}
    for i in ipairs(CAMP) do
        local r = CreateFrame("Frame", nil, c); r:SetPoint("TOPLEFT", 0, y); r:SetPoint("RIGHT"); r:SetHeight(30)
        r.t = UI.Text(r, 11); r.t:SetPoint("TOPLEFT"); r.t:SetPoint("RIGHT"); r.t:SetJustifyH("LEFT")
        f.camp[i] = r
        y = y - 32
    end
    local tip = UI.Text(c, 11, UI.C.muted); tip:SetPoint("TOPLEFT", 0, y - 4); tip:SetPoint("RIGHT"); tip:SetJustifyH("LEFT")
    tip:SetText("Tip: level Cooking at the same time. The fish you catch become food that heals you and gives buffs.")
    c:SetHeight(-y + 40)

    f:HookScript("OnShow", function() C_Timer.After(0, refresh) end)
    win = f
end

function ns.ToggleFishing()
    if not win then build() end
    win:SetShown(not win:IsShown())
end

local ev = CreateFrame("Frame")
ev:SetScript("OnEvent", function() if win and win:IsShown() then C_Timer.After(0.3, refresh) end end)

local prevSlash = ns.HandleSlash
function ns.HandleSlash(msg)
    if msg == "fish" or msg == "fishing" then ns.ToggleFishing(); return true end
    return prevSlash and prevSlash(msg) or false
end

local prevInit = ns.InitLearn
function ns.InitLearn(db)
    if prevInit then prevInit(db) end
    DB = db
    for _, e in ipairs({ "SKILL_LINES_CHANGED", "ZONE_CHANGED_NEW_AREA", "ZONE_CHANGED" }) do pcall(ev.RegisterEvent, ev, e) end
end
