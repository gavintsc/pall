-- PallyPal Disenchant: one click per item (the game requires a real click for every
-- disenchant). Lists what you can disenchant, what it should give, and whether it's
-- worth more disenchanted, on the Auction House, or at a vendor.
local ADDON, ns = ...
local UI = ns.UI
local DB

local DE = {}
ns.Disenchant = DE

local function ret(ok, ...) if ok then return ... end end
local function safe(f, ...) if not f then return end return ret(pcall(f, ...)) end
local GetInfo = function(i) return safe((C_Item and C_Item.GetItemInfo) or GetItemInfo, i) end

---------------------------------------------------------------------------
-- What items break into (Classic rules; Forever may differ, so PallyPal also
-- learns from your own disenchants and shows those results first)
---------------------------------------------------------------------------
local BRACKETS = {
    { 15,  { "Strange Dust", 1, 2 },   { "Lesser Magic Essence", 1, 2 },    nil },
    { 20,  { "Strange Dust", 2, 3 },   { "Greater Magic Essence", 1, 2 },   "Small Glimmering Shard" },
    { 25,  { "Strange Dust", 4, 6 },   { "Lesser Astral Essence", 1, 2 },   "Small Glimmering Shard" },
    { 30,  { "Soul Dust", 1, 2 },      { "Greater Astral Essence", 1, 2 },  "Large Glimmering Shard" },
    { 35,  { "Soul Dust", 2, 5 },      { "Lesser Mystic Essence", 1, 2 },   "Small Glowing Shard" },
    { 40,  { "Vision Dust", 1, 2 },    { "Greater Mystic Essence", 1, 2 },  "Large Glowing Shard" },
    { 45,  { "Vision Dust", 2, 5 },    { "Lesser Nether Essence", 1, 2 },   "Small Radiant Shard" },
    { 50,  { "Dream Dust", 1, 2 },     { "Greater Nether Essence", 1, 2 },  "Large Radiant Shard" },
    { 55,  { "Dream Dust", 2, 5 },     { "Lesser Eternal Essence", 1, 2 },  "Small Brilliant Shard" },
    { 60,  { "Illusion Dust", 1, 2 },  { "Greater Eternal Essence", 1, 2 }, "Large Brilliant Shard" },
    { 999, { "Illusion Dust", 2, 5 },  { "Greater Eternal Essence", 2, 3 }, "Large Brilliant Shard" },
}

local function bracketFor(ilvl)
    for _, b in ipairs(BRACKETS) do if ilvl <= b[1] then return b end end
    return BRACKETS[#BRACKETS]
end

local function isGear(classID) return classID == 2 or classID == 4 end -- weapon or armor

-- Can this item be disenchanted? (green, blue or purple gear)
function DE.Candidate(item)
    local name, link, quality, ilvl, _, _, _, _, equipLoc, _, _, classID = GetInfo(item)
    if not name or not quality or quality < 2 or quality > 4 then return false end
    if not isGear(classID) or not ilvl or ilvl < 1 then return false end
    if equipLoc == "INVTYPE_SHIRT" or equipLoc == "INVTYPE_TABARD" or equipLoc == "" then return false end
    return true, quality, ilvl, classID
end

-- Expected results: list of { name, chance (0-1), min, max }
function DE.Expected(item)
    local ok, quality, ilvl, classID = DE.Candidate(item)
    if not ok then return nil end
    local b = bracketFor(ilvl)
    if quality == 2 then
        local weapon = classID == 2
        local dust, ess = b[2], b[3]
        local out = {}
        local pd, pe, ps = weapon and 0.20 or 0.75, weapon and 0.75 or 0.20, 0.05
        if not b[4] then pd, pe, ps = weapon and 0.20 or 0.80, weapon and 0.80 or 0.20, 0 end
        table.insert(out, { dust[1], pd, dust[2], dust[3] })
        table.insert(out, { ess[1], pe, ess[2], ess[3] })
        if b[4] and ps > 0 then table.insert(out, { b[4], ps, 1, 1 }) end
        return out
    elseif quality == 3 then
        local shard = b[4] or "Small Glimmering Shard"
        if ilvl >= 56 then return { { shard, 0.995, 1, 1 }, { "Nexus Crystal", 0.005, 1, 1 } } end
        return { { shard, 1, 1, 1 } }
    else
        if ilvl >= 56 then return { { "Nexus Crystal", 1, 1, 2 } } end
        return { { b[4] or "Small Glimmering Shard", 1, 2, 4 } }
    end
end

local function bucket(item)
    local ok, quality, ilvl, classID = DE.Candidate(item)
    if not ok then return end
    return quality .. ":" .. (classID == 2 and "w" or "a") .. ":" .. bracketFor(ilvl)[1]
end

-- What YOU actually got from items like this (learned from your disenchants)
function DE.Learned(item)
    local k = bucket(item)
    local s = k and DB and DB.deStats[k]
    if not s or (s.n or 0) == 0 then return nil end
    local out = {}
    for name, got in pairs(s.items) do
        table.insert(out, { name, got.times / s.n, got.qty / math.max(1, got.times) })
    end
    table.sort(out, function(a, b) return a[2] > b[2] end)
    return out, s.n
end

-- Estimated value in copper, using your Auction House prices for the materials
function DE.Value(item)
    if not ns.Market then return nil end
    local learned = DE.Learned(item)
    local total, priced = 0, false
    if learned then
        for _, e in ipairs(learned) do
            local p = ns.Market.PriceByName(e[1])
            if p then total = total + p * e[2] * e[3]; priced = true end
        end
    else
        local exp = DE.Expected(item)
        if not exp then return nil end
        for _, e in ipairs(exp) do
            local p = ns.Market.PriceByName(e[1])
            if p then total = total + p * e[2] * (e[3] + e[4]) / 2; priced = true end
        end
    end
    return priced and math.floor(total + 0.5) or nil
end

local function canDisenchant()
    local ok, info = pcall(C_Spell.GetSpellInfo, "Disenchant")
    return ok and info ~= nil
end
DE.CanDisenchant = canDisenchant

---------------------------------------------------------------------------
-- Bag list
---------------------------------------------------------------------------
local function equippedSetItems()
    local out = {}
    if not C_EquipmentSet then return out end
    for _, setID in ipairs(safe(C_EquipmentSet.GetEquipmentSetIDs) or {}) do
        for _, id in pairs(safe(C_EquipmentSet.GetItemIDs, setID) or {}) do out[id] = true end
    end
    return out
end

function DE.List()
    local out = {}
    local inSets = equippedSetItems()
    for bag = 0, (NUM_BAG_SLOTS or 4) do
        for slot = 1, (safe(C_Container.GetContainerNumSlots, bag) or 0) do
            local info = safe(C_Container.GetContainerItemInfo, bag, slot)
            if info and info.itemID and info.hyperlink then
                local ok, quality = DE.Candidate(info.hyperlink)
                if ok and DB.deQuality[quality] and not DB.deBan[info.itemID] and not inSets[info.itemID] then
                    table.insert(out, { bag = bag, slot = slot, id = info.itemID, link = info.hyperlink, quality = quality,
                        name = info.hyperlink:match("%[(.-)%]") or "?" })
                end
            end
        end
    end
    return out
end

---------------------------------------------------------------------------
-- The secure "Disenchant next" button. It lives on a secure parent that the
-- game hides in combat, so it can never cause an "action blocked" error.
---------------------------------------------------------------------------
local header = CreateFrame("Frame", "PallyPalDEHeader", UIParent, "SecureHandlerStateTemplate")
header:SetAllPoints(UIParent)
RegisterStateDriver(header, "visibility", "[combat] hide; show")

local btn = CreateFrame("Button", "PallyPalDEButton", header, "SecureActionButtonTemplate")
btn:SetSize(336, 44)
btn:RegisterForClicks("AnyUp", "AnyDown")
btn:SetAttribute("type", "macro")
btn:Hide()
UI.Flat(btn, UI.C.pink, { 1, 1, 1, 0 }, "small")
btn.icon = UI.Icon(btn, 28); btn.icon:SetPoint("LEFT", 10, 0)
btn.label = UI.Title(btn, 13, { 0.1, 0.04, 0.07, 1 }); btn.label:SetPoint("TOPLEFT", btn.icon, "TOPRIGHT", 10, -1); btn.label:SetPoint("RIGHT", -10, 0); btn.label:SetWordWrap(false)
btn.sub = UI.Text(btn, 10, { 0.25, 0.1, 0.17, 1 }); btn.sub:SetPoint("TOPLEFT", btn.label, "BOTTOMLEFT", 0, -2); btn.sub:SetPoint("RIGHT", -10, 0); btn.sub:SetWordWrap(false)
btn:SetScript("OnEnter", function(self) self:SetBackdropColor(1, 0.66, 0.81, 1) end)
btn:SetScript("OnLeave", function(self) self:SetBackdropColor(unpack(UI.C.pink)) end)
local lastTarget -- the item we're disenchanting, so we can learn what it gave
btn:SetScript("PreClick", function(self) lastTarget = self.target end)

local win, rows = nil, {}

local function setTarget(e)
    if InCombatLockdown() then return end
    btn.target = e
    if e then
        btn:SetAttribute("macrotext", "/cast Disenchant\n/use " .. e.bag .. " " .. e.slot)
        btn.icon:SetIcon(safe(C_Item.GetItemIconByID, e.id) or 134400)
        btn.label:SetText("Disenchant " .. e.name)
        local exp = DE.Learned(e.link) or DE.Expected(e.link)
        btn.sub:SetText(exp and exp[1] and ("Likely: " .. exp[1][1]) or "Click once per item")
        btn:EnableMouse(true); btn:SetAlpha(1)
    else
        btn:SetAttribute("macrotext", "")
        btn.icon:SetIcon(134400)
        btn.label:SetText(canDisenchant() and "Nothing left to disenchant" or "You need Enchanting to disenchant")
        btn.sub:SetText(canDisenchant() and "Your bags are clean." or "Train it at an Enchanting trainer.")
        btn:EnableMouse(false); btn:SetAlpha(0.5)
    end
end

local function placeButton()
    if InCombatLockdown() or not win then return end
    btn:ClearAllPoints()
    local x, y = win:GetLeft(), win:GetBottom()
    if x and y then
        local s = win:GetEffectiveScale() / UIParent:GetEffectiveScale()
        btn:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", (x + 22) * s, (y + 18) * s)
    end
    btn:SetShown(win:IsShown())
end

local function refresh()
    if not win or not win:IsShown() then return end
    local list = DE.List()
    for i = 1, math.max(#list, #rows) do
        local r = rows[i]
        if not r and list[i] then
            r = CreateFrame("Button", nil, win.scroll.child)
            r:SetHeight(40)
            r:SetPoint("TOPLEFT", 0, -(i - 1) * 42); r:SetPoint("RIGHT")
            r:RegisterForClicks("LeftButtonUp", "RightButtonUp")
            UI.Flat(r, { 1, 1, 1, (i % 2 == 1) and 0.03 or 0 }, { 1, 1, 1, 0 }, "small")
            r.icon = UI.Icon(r, 26); r.icon:SetPoint("LEFT", 6, 0)
            r.name = UI.Title(r, 12); r.name:SetPoint("TOPLEFT", r.icon, "TOPRIGHT", 10, 0); r.name:SetPoint("RIGHT", -96, 0); r.name:SetWordWrap(false)
            r.sub = UI.Text(r, 10, UI.C.muted); r.sub:SetPoint("TOPLEFT", r.name, "BOTTOMLEFT", 0, -2); r.sub:SetPoint("RIGHT", -96, 0); r.sub:SetWordWrap(false)
            r.best = UI.Title(r, 10); r.best:SetPoint("TOPRIGHT", -8, -8); r.best:SetJustifyH("RIGHT")
            r.val = UI.Text(r, 10, UI.C.muted); r.val:SetPoint("TOPRIGHT", r.best, "BOTTOMRIGHT", 0, -2); r.val:SetJustifyH("RIGHT")
            r:SetScript("OnEnter", function(self)
                GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                if self.entry then GameTooltip:SetBagItem(self.entry.bag, self.entry.slot) end
                GameTooltip:AddLine("|cff8d8f96Right-click: never disenchant this|r")
                GameTooltip:Show()
            end)
            r:SetScript("OnLeave", function() GameTooltip:Hide() end)
            rows[i] = r
        end
        if r then
            local e = list[i]
            if e then
                r.entry = e
                r.icon:SetIcon(safe(C_Item.GetItemIconByID, e.id) or 134400)
                local c = ITEM_QUALITY_COLORS and ITEM_QUALITY_COLORS[e.quality]
                r.name:SetText(e.name); if c then r.name:SetTextColor(c.r, c.g, c.b) end
                local learned, n = DE.Learned(e.link)
                local exp = learned or DE.Expected(e.link) or {}
                local parts = {}
                for j = 1, math.min(2, #exp) do table.insert(parts, exp[j][1]) end
                r.sub:SetText((learned and "You got: " or "Gives: ") .. table.concat(parts, " or "))
                local best, val = ns.Market and ns.Market.BestAction(e.id, e.link)
                if best then
                    r.best:SetText(best == "Disenchant" and "|cff6bdb80Disenchant|r" or ("|cffffd14d" .. best .. "|r"))
                    r.val:SetText(ns.Market.Money(val))
                else
                    r.best:SetText(""); r.val:SetText("")
                end
                r:SetScript("OnClick", function(self, button)
                    if button == "RightButton" then
                        DB.deBan[e.id] = e.name
                        ns.Alert("Won't disenchant " .. e.name, "Unban it in the Disenchant window settings.")
                        refresh()
                    else
                        setTarget(e)
                    end
                end)
                r:Show()
            else
                r:Hide()
            end
        end
    end
    win.scroll.child:SetHeight(#list * 42 + 4)
    win.count:SetText(#list .. " item" .. (#list == 1 and "" or "s") .. " to disenchant")
    -- point the button at the first item (unless you picked one that's still there)
    local keep
    if btn.target then for _, e in ipairs(list) do if e.bag == btn.target.bag and e.slot == btn.target.slot then keep = e end end end
    setTarget(keep or list[1])
    placeButton()
end
DE.Refresh = refresh

local function toggle()
    if not win then
        local f = UI.Window("PallyPalDisenchant", 380, 540, "Disenchant", "one click per item")
        local c = f.content
        f.count = UI.Title(c, 12); f.count:SetPoint("TOPLEFT")
        -- quality filters
        local q = { { 2, "Green" }, { 3, "Blue" }, { 4, "Purple" } }
        local x = 0
        for _, it in ipairs(q) do
            local b = UI.Button(c, 64, 24, it[2], DB.deQuality[it[1]] and "primary" or nil)
            b.label:SetFont(UI.FONT_SB, 10, "")
            b:SetPoint("TOPRIGHT", -(2 - x) * 68, 2)
            x = x + 1
            local function paint()
                local on = DB.deQuality[it[1]]
                b:SetFill(on and UI.C.pink or UI.C.panel2)
                b.label:SetTextColor(on and 0.1 or 1, on and 0.04 or 1, on and 0.07 or 1)
            end
            b:SetScript("OnClick", function()
                if InCombatLockdown() then return end
                DB.deQuality[it[1]] = not DB.deQuality[it[1]] or nil; paint(); refresh()
            end)
            paint()
        end
        local hint = UI.Text(c, 10, UI.C.muted); hint:SetPoint("TOPLEFT", 0, -24); hint:SetPoint("RIGHT")
        hint:SetText("Click an item to pick it, right-click to never disenchant it. Items in equipment sets are skipped.")
        f.scroll = UI.Scroll(c); f.scroll:SetPoint("TOPLEFT", 0, -50); f.scroll:SetPoint("BOTTOMRIGHT", 0, 96)
        local unban = UI.Button(c, 150, 24, "Clear never-list", "ghost"); unban.label:SetFont(UI.FONT_SB, 10, "")
        unban:SetPoint("BOTTOMRIGHT", 0, 62)
        unban:SetScript("OnClick", function() wipe(DB.deBan); refresh() end)
        local key = UI.Text(c, 10, UI.C.muted); key:SetPoint("BOTTOMLEFT", 0, 68)
        key:SetText("Tip: set a key in Options > Keybindings > AddOns")
        f:HookScript("OnShow", function() C_Timer.After(0, refresh) end)
        f:HookScript("OnHide", function() if not InCombatLockdown() then btn:Hide() end end)
        f:HookScript("OnDragStop", placeButton)
        -- keep the button glued to the window when you drag it
        f:HookScript("OnUpdate", function(self)
            if self.isMovingCheck ~= self:GetLeft() then self.isMovingCheck = self:GetLeft(); placeButton() end
        end)
        win = f
    end
    if InCombatLockdown() then ns.Alert("Finish your fight first") return end
    win:SetShown(not win:IsShown())
    if not win:IsShown() then btn:Hide() end
end
ns.ToggleDisenchant = function() toggle() end

---------------------------------------------------------------------------
-- Learn what disenchanting actually gives
---------------------------------------------------------------------------
local waitingLoot
local ev = CreateFrame("Frame")
ev:SetScript("OnEvent", function(_, event, unit, _, spellID)
    if event == "UNIT_SPELLCAST_SUCCEEDED" then
        if unit ~= "player" or InCombatLockdown() or (issecretvalue and issecretvalue(spellID)) then return end
        local n = safe(C_Spell.GetSpellName, spellID)
        if n == "Disenchant" and lastTarget then
            waitingLoot = { link = lastTarget.link, t = GetTime() }
        end
    elseif event == "LOOT_OPENED" then
        if not waitingLoot or GetTime() - waitingLoot.t > 6 then return end
        local k = bucket(waitingLoot.link)
        waitingLoot = nil
        if not k then return end
        local s = DB.deStats[k] or { n = 0, items = {} }
        s.n = s.n + 1
        for i = 1, (GetNumLootItems() or 0) do
            local _, name, qty = GetLootSlotInfo(i)
            if name then
                local g = s.items[name] or { times = 0, qty = 0 }
                g.times = g.times + 1; g.qty = g.qty + (qty or 1)
                s.items[name] = g
            end
        end
        DB.deStats[k] = s
    elseif event == "BAG_UPDATE_DELAYED" or event == "PLAYER_REGEN_ENABLED" then
        if win and win:IsShown() then C_Timer.After(0.2, refresh)
        elseif not InCombatLockdown() then btn:Hide() end
    end
end)

local prevSlash = ns.HandleSlash
function ns.HandleSlash(msg)
    if msg == "de" or msg == "disenchant" then toggle(); return true end
    if msg == "market" or msg == "ah" then if ns.ToggleMarket then ns.ToggleMarket() end; return true end
    if msg == "prices" or msg == "price" then if ns.Market then ns.Market.TogglePrices() end; return true end
    return prevSlash and prevSlash(msg) or false
end

_G["BINDING_NAME_CLICK PallyPalDEButton:LeftButton"] = "Disenchant next item"

local prevInit = ns.InitLearn
function ns.InitLearn(db)
    if prevInit then prevInit(db) end
    DB = db
    DB.deStats = DB.deStats or {}
    DB.deBan = DB.deBan or {}
    DB.deQuality = DB.deQuality or { [2] = true, [3] = true }
    for _, e in ipairs({ "UNIT_SPELLCAST_SUCCEEDED", "LOOT_OPENED", "BAG_UPDATE_DELAYED", "PLAYER_REGEN_ENABLED" }) do
        pcall(ev.RegisterEvent, ev, e)
    end
end
