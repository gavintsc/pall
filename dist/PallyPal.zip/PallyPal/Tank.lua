-- PallyPal Tank: plans your path to Protection (tank) Paladin.
-- Follows Icy Veins' WoW Forever Protection Paladin guide (the one you picked):
-- https://www.icy-veins.com/wow-forever/protection-paladin-tank-pve-guide
local ADDON, ns = ...
local UI = ns.UI
local DB

local function isTank() return DB and DB.goal == "tank" end

local function inDungeonGroup()
    local inInst, kind = IsInInstance()
    return inInst and (kind == "party" or kind == "raid") and IsInGroup()
end

local function hasShield()
    local id = GetInventoryItemID("player", 17)
    if not id then return false end
    local ok, _, _, _, _, _, classID, subID = pcall(C_Item.GetItemInfoInstant, id)
    return ok and classID == 4 and subID == 6 -- Armor > Shield
end

---------------------------------------------------------------------------
-- Reminders (only inside a dungeon with a group, only for the tank goal)
---------------------------------------------------------------------------
function ns.TankWants(want, buffs, knows)
    if not isTank() or not buffs or not inDungeonGroup() then return end
    if knows("Righteous Fury") and not buffs["Righteous Fury"] then
        table.insert(want, 1, { "Righteous Fury", "Tanking? No Righteous Fury" })
    end
    if knows("Seal of Fury") and not buffs["Seal of Fury"] then
        table.insert(want, { "Seal of Fury", "Tanking? No Seal of Fury" })
    end
end

---------------------------------------------------------------------------
-- Tank lessons
---------------------------------------------------------------------------
local TANK_LESSONS = {
    { id = "t_fury",   text = "Tank: train Seal of Fury + Righteous Fury", hint = "Level 10. Visit your class trainer." },
    { id = "t_shield", text = "Tank: equip a shield",          hint = "Buy one from a vendor or find one. Seal of Fury's absorb needs a shield." },
    { id = "t_taunt",  text = "Tank: taunt with Judgement",    hint = "With Seal of Fury on, Judgement taunts the target for 4 sec." },
    { id = "t_rf",     text = "Tank: turn on Righteous Fury",  hint = "Cast it before tanking a group. It boosts your threat." },
    { id = "t_dungeon",text = "Tank: tank your first dungeon", hint = "Ragefire Chasm in Orgrimmar is the first Horde dungeon. Queue or ask in chat." },
}

local function checkTankLessons()
    if not isTank() or not ns.CompleteLesson then return end
    local knows = function(n) local ok, i = pcall(C_Spell.GetSpellInfo, n) return ok and i end
    if knows("Seal of Fury") and knows("Righteous Fury") then ns.CompleteLesson("t_fury") end
    if hasShield() then ns.CompleteLesson("t_shield") end
end

---------------------------------------------------------------------------
-- Tank path window
---------------------------------------------------------------------------
local PATH = [[
|cfff58cbaWHERE YOU ARE NOW|r
Level like normal. Protection is a fine leveling spec too, but until 10 every Paladin plays the same.

|cfff58cbaLEVEL 10: BECOME A TANK|r
Train |cffffd100Seal of Fury|r and |cffffd100Righteous Fury|r at your class trainer.
|cffffd100Seal of Fury|r: extra Holy damage, an absorb shield when you wear a shield, and |cffffd100Judgement taunts|r the target for 4 sec. This is your taunt.
|cffffd100Righteous Fury|r: 33% more threat, plus extra threat from Holy damage. Keep it on when tanking a group.
Wear a |cffffd100one-handed weapon + shield|r.

|cfff58cbaTALENTS (press N)|r
Icy Veins' leveling build goes |cffffd100Retribution first|r to get |cffffd100Pursuit of Justice|r (faster running), then switches to |cffffd100Protection|r for survival and mana talents.
At level 60 there are two tank builds:
|cffffd100Deep Protection|r: the tankiest. Its capstone |cffffd100Shieldsworn|r makes Holy Strike trigger Holy Shield.
|cffffd100Deep Holy|r: more damage and threat from |cffffd100Holy Shock|r and |cffffd100Holy Conduit|r (helps a lot with mana), but less tanky.

|cfff58cbaTANK ROTATION (one target)|r
1. Keep |cffffd100Righteous Fury|r on.
2. Keep |cffffd100Seal of Fury|r on while tanking.
3. |cffffd100Consecration|r as much as your mana allows.
4. |cffffd100Holy Shield|r as much as possible.
5. |cffffd100Holy Strike|r on cooldown.
6. |cffffd100Judgement|r also taunts while Seal of Fury is on.

|cfff58cbaTANK ROTATION (groups)|r
Same as above, but keeping |cffffd100Consecration|r down matters most: it's your threat on every mob.
Not tanking right now and fighting Undead or Demons? |cffffd100Holy Wrath|r.

|cfff58cbaQUESTING SOLO|r
Keep Seal of Fury. If you don't need to taunt and have mana to spare, swap to |cffffd100Seal of Righteousness|r for more damage. Swap back before you tank.

|cfff58cbaAURA + BLESSING|r
Retribution Aura while leveling, Devotion Aura next best. Blessing of Kings from 20 (Might before).

|cfff58cbaSTATS|r
1. Stamina  2. Spell Power  3. Strength
Early on, weapon damage, hit and crit matter most.

|cfff58cbaMANA|r
Mana stops regenerating for 5 sec after you cast. Have mana at the start of every pull.

|cfff58cbaFIRST GEAR TO LOOK FOR (Horde)|r
|cffffd100Arctic Buckler|r: Horde quest "Blackfathom Villainy".
|cffffd100Worn Turtle Shell Shield|r, |cffffd100Kresh's Back|r: Wailing Caverns.
|cffffd100Commander's Crest|r: Shadowfang Keep.
|cffffd100Painwalker Buckler|r: Scarlet Monastery.
Smite's Mighty Hammer / Rhahk'Zor's Hammer: Deadmines.

|cfff58cbaFIRST DUNGEON|r
Horde: |cffffd100Ragefire Chasm|r (Orgrimmar), from about level 10.

|cfff58cbaLATER|r
Level 32: Improved Seal of Fury (talent).  Level 34: Divine Shield.  Level 40: mount quest.  Level 43: Reckoning (talent).
Protection gets Templar's Bulwark (absorb = 100% of your health for 8 sec) and Swift Judgement (a second taunt).

|cff8d8f96Your guide: Icy Veins' WoW Forever Protection Paladin guide (link at the bottom).|r
]]

local win
local function togglePath()
    if not win then
        local f = UI.Window("PallyPalTank", 480, 560, "Tank path", "Protection Paladin")
        local goalBtn = UI.Button(f, 150, 22, "")
        goalBtn.label:SetFont(STANDARD_TEXT_FONT, 11, "")
        goalBtn:SetPoint("TOPRIGHT", -40, -8)
        local function paint()
            goalBtn:SetText(isTank() and "Goal: Tank" or "Make Tank my goal")
        end
        goalBtn:SetScript("OnClick", function()
            DB.goal = isTank() and "damage" or "tank"
            paint()
            if ns.SetGoal then ns.SetGoal(DB.goal) end
        end)
        f:HookScript("OnShow", paint)
        local sf = UI.Scroll(f.content)
        sf:SetAllPoints()
        local body = UI.Text(sf.child, 12)
        body:SetPoint("TOPLEFT", 2, -2)
        body:SetWidth(440)
        body:SetSpacing(3)
        body:SetText(PATH)
        -- the guide link (WoW can't open websites, so it's a box you can copy from)
        local lbl = UI.Title(sf.child, 10, UI.C.head); lbl:SetPoint("TOPLEFT", body, "BOTTOMLEFT", 0, -14); lbl:SetText("YOUR GUIDE  \194\183  CLICK, THEN CTRL+C")
        local link = UI.Search(sf.child, 440, "")
        link:SetPoint("TOPLEFT", lbl, "BOTTOMLEFT", 0, -6)
        local URL = "https://www.icy-veins.com/wow-forever/protection-paladin-tank-pve-guide"
        link:SetText(URL)
        link:SetScript("OnEditFocusGained", function(self) self:HighlightText() end)
        link:SetScript("OnTextChanged", function(self, user) if user then self:SetText(URL); self:HighlightText() end end)
        sf.child:SetHeight((body:GetStringHeight() or 600) + 90)
        win = f
        paint()
    end
    win:SetShown(not win:IsShown())
end
ns.ToggleTank = function() togglePath() end

function ns.SetGoal(goal)
    DB.goal = goal
    if goal == "tank" and ns.AddLesson then
        for _, l in ipairs(TANK_LESSONS) do
            ns.AddLesson(l, (l.id == "t_rf") and { "Righteous Fury" } or nil)
        end
        checkTankLessons()
    end
    if ns.RebuildBarPlan then ns.RebuildBarPlan() end
    if ns.RefreshReminder then ns.RefreshReminder() end
    if ns.Alert then
        ns.Alert(goal == "tank" and "Goal set: Tank (Protection)" or "Goal set: Damage",
            goal == "tank" and "Tips, lessons and bar layout now follow the tank path." or "Tips and bar layout follow the damage path.")
    end
end

---------------------------------------------------------------------------
-- Events
---------------------------------------------------------------------------
local furyActive = false
local ev = CreateFrame("Frame")
ev:SetScript("OnEvent", function(_, event, unit, _, spellID)
    if not isTank() then return end
    if event == "UNIT_SPELLCAST_SUCCEEDED" and unit == "player" then
        local ok, name = pcall(C_Spell.GetSpellName, spellID)
        if ok and name == "Judgement" then
            -- Judgement while Seal of Fury is on = a taunt
            local okA, aura = pcall(C_UnitAuras.GetAuraDataBySpellName, "player", "Seal of Fury", "HELPFUL")
            if okA and aura and ns.CompleteLesson then ns.CompleteLesson("t_taunt") end
        end
    elseif event == "PLAYER_EQUIPMENT_CHANGED" or event == "SPELLS_CHANGED" or event == "LEARNED_SPELL_IN_SKILL_LINE" then
        checkTankLessons()
    elseif event == "PLAYER_ENTERING_WORLD" or event == "GROUP_ROSTER_UPDATE" then
        if inDungeonGroup() and ns.CompleteLesson then
            -- counts once you're in a dungeon with a group and Righteous Fury is on
            local okA, aura = pcall(C_UnitAuras.GetAuraDataBySpellName, "player", "Righteous Fury", "HELPFUL")
            if okA and aura then ns.CompleteLesson("t_dungeon") end
        end
        if ns.RefreshReminder then C_Timer.After(1, ns.RefreshReminder) end
    end
end)

local prevSlash = ns.HandleSlash
function ns.HandleSlash(msg)
    if msg == "tank" then togglePath(); return true end
    return prevSlash and prevSlash(msg) or false
end

local prevInit = ns.InitLearn
function ns.InitLearn(db)
    if prevInit then prevInit(db) end
    DB = db
    if DB.goal == nil then DB.goal = "tank" end -- default goal: tank
    if isTank() and ns.AddLesson then
        for _, l in ipairs(TANK_LESSONS) do
            ns.AddLesson(l, (l.id == "t_rf") and { "Righteous Fury" } or nil)
        end
    end
    for _, e in ipairs({ "UNIT_SPELLCAST_SUCCEEDED", "PLAYER_EQUIPMENT_CHANGED", "SPELLS_CHANGED",
        "LEARNED_SPELL_IN_SKILL_LINE", "PLAYER_ENTERING_WORLD", "GROUP_ROSTER_UPDATE" }) do
        pcall(ev.RegisterEvent, ev, e)
    end
    C_Timer.After(3, checkTankLessons)
end
