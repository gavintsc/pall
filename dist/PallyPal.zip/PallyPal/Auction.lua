-- PallyPal Auction panel: sits next to the Auction House (Sell / Shop / Scan).
-- Posting and buying always need your click; the game requires that and so do we.
local ADDON, ns = ...
local UI = ns.UI
local Market = ns.Market
local safe = Market.safe
local DB

local panel
local tabs, pages = {}, {}
local current = "sell"

local DURATIONS = { { 1, "12h" }, { 2, "24h" }, { 3, "48h" } }

---------------------------------------------------------------------------
-- small helpers
---------------------------------------------------------------------------
local function iconFor(id) return safe(C_Item.GetItemIconByID, id) or 134400 end

local function row(parent, i, h)
    local r = CreateFrame("Button", nil, parent)
    r:SetHeight(h or 36)
    r:SetPoint("TOPLEFT", 0, -(i - 1) * ((h or 36) + 2)); r:SetPoint("RIGHT")
    UI.Flat(r, { 1, 1, 1, 0 }, { 1, 1, 1, 0 }, "small")
    r:SetScript("OnEnter", function(self) self:SetBackdropColor(1, 1, 1, 0.05) end)
    r:SetScript("OnLeave", function(self) if not self.selected then self:SetBackdropColor(1, 1, 1, 0) end end)
    r.icon = UI.Icon(r, 26); r.icon:SetPoint("LEFT", 6, 0)
    r.name = UI.Title(r, 12); r.name:SetPoint("TOPLEFT", r.icon, "TOPRIGHT", 10, 0); r.name:SetPoint("RIGHT", -110, 0); r.name:SetWordWrap(false)
    r.sub = UI.Text(r, 10, UI.C.muted); r.sub:SetPoint("TOPLEFT", r.name, "BOTTOMLEFT", 0, -2); r.sub:SetPoint("RIGHT", -110, 0); r.sub:SetWordWrap(false)
    r.right = UI.Text(r, 11); r.right:SetPoint("RIGHT", -8, 0); r.right:SetJustifyH("RIGHT")
    return r
end

local function markSel(r, on)
    r.selected = on
    r:SetBackdropColor(0.96, 0.55, 0.73, on and 0.12 or 0)
    r:SetBackdropBorderColor(0.96, 0.55, 0.73, on and 0.45 or 0)
end

---------------------------------------------------------------------------
-- SELL: your bag items, live lowest price, undercut, post
---------------------------------------------------------------------------
local sell = { rows = {}, items = {}, chosen = nil, duration = 2 }

local function sellableItems()
    local out, seen = {}, {}
    for bag = 0, (NUM_BAG_SLOTS or 4) do
        for slot = 1, (safe(C_Container.GetContainerNumSlots, bag) or 0) do
            local info = safe(C_Container.GetContainerItemInfo, bag, slot)
            if info and info.itemID and not info.isBound then
                local loc = ItemLocation and ItemLocation:CreateFromBagAndSlot(bag, slot)
                local valid = not loc or not C_AuctionHouse.IsSellItemValid or safe(C_AuctionHouse.IsSellItemValid, loc, false)
                if valid and info.quality and info.quality >= 1 then
                    local e = seen[info.itemID]
                    if e then
                        e.count = e.count + (info.stackCount or 1)
                    else
                        e = { id = info.itemID, bag = bag, slot = slot, count = info.stackCount or 1, link = info.hyperlink,
                              name = (info.hyperlink and info.hyperlink:match("%[(.-)%]")) or ("item " .. info.itemID), quality = info.quality }
                        seen[info.itemID] = e
                        table.insert(out, e)
                    end
                end
            end
        end
    end
    for _, e in ipairs(out) do e.price = Market.Price(e.id) end
    table.sort(out, function(a, b) return (a.price or 0) * a.count > (b.price or 0) * b.count end)
    return out
end

local function isCommodity(e)
    local loc = ItemLocation:CreateFromBagAndSlot(e.bag, e.slot)
    local st = safe(C_AuctionHouse.GetItemCommodityStatus, loc)
    return st == (Enum.ItemCommodityStatus and Enum.ItemCommodityStatus.Commodity or 2)
end

local function chooseSell(e)
    sell.chosen = e
    local p = sell.page
    p.box:Show()
    p.cIcon:SetIcon(iconFor(e.id))
    p.cName:SetText(e.link or e.name)
    p.qty:SetText(tostring(e.count))
    local base = e.price and math.max(1, e.price - 1) or nil
    p.price:SetText(base and Market.MoneyPlain(base) or "")
    p.live:SetText("Checking the Auction House...")
    p.post:SetEnabled(true)
    -- ask the Auction House for the current listings of this item
    local key = safe(C_AuctionHouse.GetItemKeyFromItem, ItemLocation:CreateFromBagAndSlot(e.bag, e.slot)) or safe(C_AuctionHouse.MakeItemKey, e.id)
    local sorts = { { sortOrder = Enum.AuctionHouseSortOrder and Enum.AuctionHouseSortOrder.Price or 0, reverseSort = false } }
    if key then safe(C_AuctionHouse.SendSearchQuery, key, sorts, true) end
    for i, r in ipairs(sell.rows) do
        markSel(r, r.entry == e)
        if r.entry == e then
            C_Timer.After(0, function()
                local sf = p.list
                local top, h = (i - 1) * 38, sf:GetHeight() or 0
                local cur = sf:GetVerticalScroll() or 0
                if top < cur then sf:SetVerticalScroll(top)
                elseif top + 36 > cur + h then sf:SetVerticalScroll(math.max(0, top + 36 - h)) end
            end)
        end
    end
end

local function onLivePrice(itemID, commodity, key)
    local e = sell.chosen
    if not e or e.id ~= itemID then return end
    local lowest, mine
    if commodity then
        for i = 1, math.min(10, safe(C_AuctionHouse.GetNumCommoditySearchResults, itemID) or 0) do
            local r = safe(C_AuctionHouse.GetCommoditySearchResultInfo, itemID, i)
            if r and r.unitPrice and not (r.containsOwnerItem and r.quantity == r.numOwnerItems) then lowest = r.unitPrice; break end
        end
    else
        for i = 1, math.min(10, safe(C_AuctionHouse.GetNumItemSearchResults, key) or 0) do
            local r = safe(C_AuctionHouse.GetItemSearchResultInfo, key, i)
            if r and r.buyoutAmount and not r.containsOwnerItem then lowest = r.buyoutAmount; break end
        end
    end
    local p = sell.page
    if lowest then
        local undercut = math.max(1, lowest - math.max(1, math.floor(lowest * (DB.undercut or 0) / 100)))
        p.price:SetText(Market.MoneyPlain(undercut))
        p.live:SetText("Lowest " .. Market.Money(lowest) .. ", you list at " .. Market.Money(undercut))
    else
        local v = Market.ItemInfo(e.id).vendor or 0
        p.live:SetText(e.price and ("None listed. Last seen " .. Market.Money(e.price)) or
            (v > 0 and ("None listed. Vendor pays " .. Market.Money(v)) or "None listed. Pick your own price."))
    end
end

local function postChosen()
    local e = sell.chosen
    if not e then return end
    local p = sell.page
    local unit = Market.ParseMoney(p.price:GetText())
    local qty = tonumber(p.qty:GetText()) or 1
    if not unit or unit <= 0 then ns.Alert("Set a price first", "Type it like 1g 20s, or just 1.2 for gold.") return end
    qty = math.max(1, math.min(qty, e.count))
    local loc = ItemLocation:CreateFromBagAndSlot(e.bag, e.slot)
    local ok, err
    if isCommodity(e) then
        ok, err = pcall(C_AuctionHouse.PostCommodity, loc, sell.duration, qty, unit)
    else
        ok, err = pcall(C_AuctionHouse.PostItem, loc, sell.duration, 1, nil, unit)
    end
    if ok then
        ns.Alert("Posted " .. (e.name or "item"), (qty > 1 and (qty .. " for " .. Market.Money(unit) .. " each")) or Market.Money(unit))
        Market.Record(e.id, unit, e.name)
        sell.chosen = nil
        p.box:Hide()
        C_Timer.After(1, function() if pages.sell and pages.sell:IsShown() then pages.sell.refresh() end end)
    else
        ns.Alert("Couldn't post that", "The Auction House said no. Check the price and try again.")
    end
end

local BOX_H = 228

local function layoutSellList()
    local p = sell.page
    p.list:ClearAllPoints()
    p.list:SetPoint("TOPLEFT", 0, -24)
    p.list:SetPoint("BOTTOMRIGHT", 0, p.box:IsShown() and (BOX_H + 10) or 0)
end

local function setDuration(dur)
    for j, x in ipairs(dur) do
        local on = DURATIONS[j][1] == sell.duration
        x:SetFill(on and { 0.96, 0.55, 0.73, 1 } or { 1, 1, 1, 0.04 })
        x:SetBackdropBorderColor(0.96, 0.55, 0.73, on and 1 or 0)
        x.label:SetTextColor(on and 0.1 or 0.75, on and 0.04 or 0.75, on and 0.07 or 0.78)
    end
end

local function buildSell(p)
    sell.page = p
    p.hint = UI.Text(p, 11, UI.C.muted); p.hint:SetPoint("TOPLEFT"); p.hint:SetPoint("RIGHT")
    p.hint:SetText("Your bag items, most valuable first. Pick one to sell.")
    local sf = UI.Scroll(p)
    if sf.SetClipsChildren then sf:SetClipsChildren(true) end
    p.list = sf

    -- selected item box (pinned to the bottom, list shrinks above it)
    local box = CreateFrame("Frame", nil, p)
    box:SetPoint("BOTTOMLEFT"); box:SetPoint("BOTTOMRIGHT"); box:SetHeight(BOX_H)
    UI.Flat(box, UI.C.panel, UI.C.line, "small")
    box:Hide()
    p.box = box
    box:SetScript("OnShow", layoutSellList)
    box:SetScript("OnHide", layoutSellList)

    -- row 1: icon, name, live price line
    p.cIcon = UI.Icon(box, 34); p.cIcon:SetPoint("TOPLEFT", 14, -14)
    p.cName = UI.Title(box, 13); p.cName:SetPoint("TOPLEFT", p.cIcon, "TOPRIGHT", 12, -1); p.cName:SetPoint("RIGHT", -14, 0)
    p.cName:SetWordWrap(false); p.cName:SetJustifyH("LEFT")
    p.live = UI.Text(box, 11, UI.C.muted); p.live:SetPoint("TOPLEFT", p.cName, "BOTTOMLEFT", 0, -4); p.live:SetPoint("RIGHT", -14, 0)
    p.live:SetJustifyH("LEFT"); p.live:SetWordWrap(false)

    -- row 2: price + quantity
    local l1 = UI.Text(box, 10, UI.C.muted); l1:SetPoint("TOPLEFT", 14, -64); l1:SetText("PRICE EACH")
    p.price = UI.Search(box, 196, "e.g. 1g 20s"); p.price:SetPoint("TOPLEFT", 14, -80)
    local l2 = UI.Text(box, 10, UI.C.muted); l2:SetPoint("TOPLEFT", 222, -64); l2:SetText("QUANTITY")
    p.qty = UI.Search(box, 10, "1"); p.qty:SetPoint("TOPLEFT", 222, -80); p.qty:SetPoint("RIGHT", -14, 0); p.qty:SetNumeric(true)

    -- row 3: duration segmented control
    local l3 = UI.Text(box, 10, UI.C.muted); l3:SetPoint("TOPLEFT", 14, -122); l3:SetText("DURATION")
    local seg = CreateFrame("Frame", nil, box)
    seg:SetPoint("TOPLEFT", 14, -138); seg:SetPoint("RIGHT", -14, 0); seg:SetHeight(30)
    UI.Flat(seg, { 0.04, 0.045, 0.055, 1 }, UI.C.line2, "small")
    local dur = {}
    for i, d in ipairs(DURATIONS) do
        local b = UI.Button(seg, 10, 24, d[2], "ghost")
        b:SetScript("OnClick", function() sell.duration = d[1]; setDuration(dur) end)
        dur[i] = b
    end
    seg:SetScript("OnSizeChanged", function(self, w)
        local bw = (w - 6 - 4) / 3
        for i, b in ipairs(dur) do
            b:ClearAllPoints(); b:SetSize(bw, 24); b:SetPoint("LEFT", 3 + (i - 1) * (bw + 2), 0)
        end
    end)
    for i, b in ipairs(dur) do b:SetSize(100, 24); b:SetPoint("LEFT", 3 + (i - 1) * 102, 0) end
    setDuration(dur)

    -- row 4: actions
    local cancel = UI.Button(box, 96, 32, "Cancel", "ghost")
    cancel:SetPoint("BOTTOMLEFT", 14, 14)
    cancel:SetScript("OnClick", function() sell.chosen = nil; box:Hide(); for _, r in ipairs(sell.rows) do markSel(r, false) end end)
    p.post = UI.Button(box, 10, 32, "Post auction", "primary")
    p.post:SetPoint("BOTTOMRIGHT", -14, 14); p.post:SetPoint("LEFT", cancel, "RIGHT", 8, 0)
    p.post:SetScript("OnClick", postChosen)
    layoutSellList()

    function p.refresh()
        local items = sellableItems()
        sell.items = items
        for i = 1, math.max(#items, #sell.rows) do
            local r = sell.rows[i]
            if not r and items[i] then r = row(sf.child, i); sell.rows[i] = r end
            if r then
                local e = items[i]
                if e then
                    r.entry = e
                    r.icon:SetIcon(iconFor(e.id))
                    local c = ITEM_QUALITY_COLORS and ITEM_QUALITY_COLORS[e.quality]
                    r.name:SetText(e.name); if c then r.name:SetTextColor(c.r, c.g, c.b) end
                    r.sub:SetText(e.count > 1 and ("x" .. e.count) or " ")
                    if e.price then r.right:SetText(Market.Money(e.price))
                    else
                        local v = (Market.ItemInfo(e.id) or {}).vendor or 0
                        r.right:SetText(v > 0 and ("|cff8d8f96vendor|r " .. Market.Money(v)) or "|cff5c5e66no data|r")
                    end
                    r:SetScript("OnClick", function() chooseSell(e) end)
                    markSel(r, sell.chosen and sell.chosen.id == e.id or false)
                    r:Show()
                else r:Hide() end
            end
        end
        sf.child:SetHeight(#items * 38 + 4)
        p.hint:SetText(#items > 0 and "Your bag items, most valuable first. Pick one to sell." or "Nothing in your bags can be sold here.")
    end
end

---------------------------------------------------------------------------
-- SHOP: shopping list, search, two-click buying
---------------------------------------------------------------------------
local shop = { rows = {}, results = {}, rrows = {}, pending = nil }

local function browse(text)
    local q = {
        searchString = text,
        sorts = { { sortOrder = Enum.AuctionHouseSortOrder and Enum.AuctionHouseSortOrder.Price or 0, reverseSort = false } },
        filters = {}, itemClassFilters = {},
    }
    shop.page.status:SetText("Searching for \"" .. text .. "\"...")
    if not pcall(C_AuctionHouse.SendBrowseQuery, q) then shop.page.status:SetText("The Auction House is busy. Try again.") end
end

local function setBuyButton(r, label, enabled, kind)
    r.buy:SetText(label)
    r.buy:SetEnabled(enabled)
end

-- step 1: ask for the real price; step 2 (second click): confirm
local function startBuy(r, res)
    local key = res.itemKey
    local info = safe(C_AuctionHouse.GetItemKeyInfo, key) or {}
    shop.pending = { row = r, key = key, commodity = info.isCommodity, id = key.itemID, qty = 1 }
    setBuyButton(r, "Checking...", false)
    if info.isCommodity then
        local qty = 1
        shop.pending.qty = qty
        safe(C_AuctionHouse.StartCommoditiesPurchase, key.itemID, qty)
    else
        local sorts = { { sortOrder = Enum.AuctionHouseSortOrder and Enum.AuctionHouseSortOrder.Price or 0, reverseSort = false } }
        safe(C_AuctionHouse.SendSearchQuery, key, sorts, false)
    end
end

local function confirmBuy()
    local pnd = shop.pending
    if not pnd or not pnd.ready then return end
    local ok
    if pnd.commodity then
        ok = pcall(C_AuctionHouse.ConfirmCommoditiesPurchase, pnd.id, pnd.qty)
    else
        ok = pcall(C_AuctionHouse.PlaceBid, pnd.auctionID, pnd.cost)
    end
    ns.Alert(ok and "Bought it!" or "Couldn't buy that", ok and ("Paid " .. Market.Money(pnd.cost) .. ". It arrives in your mailbox.") or "Someone may have bought it first.")
    setBuyButton(pnd.row, ok and "Bought" or "Buy", not ok)
    shop.pending = nil
end

local function buildShop(p)
    shop.page = p
    local add = UI.Search(p, 236, "Add an item to your list")
    add:SetPoint("TOPLEFT")
    local addBtn = UI.Button(p, 60, 30, "Add")
    addBtn:SetPoint("LEFT", add, "RIGHT", 6, 0)
    local function doAdd()
        local t = add:GetText():gsub("^%s+", ""):gsub("%s+$", "")
        if t ~= "" then table.insert(DB.shop, t); add:SetText(""); p.refresh() end
    end
    addBtn:SetScript("OnClick", doAdd)
    add:SetScript("OnEnterPressed", function(s) doAdd(); s:ClearFocus() end)
    local lbl = UI.Title(p, 10, UI.C.head); lbl:SetPoint("TOPLEFT", 0, -42); lbl:SetText("SHOPPING LIST")
    local sfL = UI.Scroll(p); sfL:SetPoint("TOPLEFT", 0, -58); sfL:SetPoint("RIGHT"); sfL:SetHeight(150)
    local lbl2 = UI.Title(p, 10, UI.C.head); lbl2:SetPoint("TOPLEFT", 0, -218); lbl2:SetText("RESULTS")
    p.status = UI.Text(p, 10, UI.C.muted); p.status:SetPoint("LEFT", lbl2, "RIGHT", 8, 0)
    local sfR = UI.Scroll(p); sfR:SetPoint("TOPLEFT", 0, -234); sfR:SetPoint("BOTTOMRIGHT")

    function p.refresh()
        for i = 1, math.max(#DB.shop, #shop.rows) do
            local r = shop.rows[i]
            local name = DB.shop[i]
            if not r and name then
                r = CreateFrame("Frame", nil, sfL.child); r:SetHeight(28)
                r:SetPoint("TOPLEFT", 0, -(i - 1) * 30); r:SetPoint("RIGHT")
                UI.Flat(r, { 1, 1, 1, (i % 2 == 1) and 0.03 or 0 }, { 1, 1, 1, 0 }, "small")
                r.name = UI.Text(r, 12); r.name:SetPoint("LEFT", 10, 0); r.name:SetWidth(150); r.name:SetWordWrap(false)
                r.price = UI.Text(r, 10, UI.C.muted); r.price:SetPoint("LEFT", r.name, "RIGHT", 6, 0)
                r.go = UI.Button(r, 62, 22, "Search"); r.go.label:SetFont(UI.FONT_SB, 10, ""); r.go:SetPoint("RIGHT", -30, 0)
                r.del = UI.Button(r, 22, 22, "×", "ghost"); r.del:SetPoint("RIGHT", -4, 0)
                shop.rows[i] = r
            end
            if r then
                if name then
                    r.name:SetText(name)
                    local pr = Market.PriceByName(name)
                    r.price:SetText(pr and Market.Money(pr) or "")
                    r.go:SetScript("OnClick", function() browse(name) end)
                    r.del:SetScript("OnClick", function() if DB.shop[i] then table.remove(DB.shop, i) end; p.refresh() end)
                    r:Show()
                else r:Hide() end
            end
        end
        sfL.child:SetHeight(#DB.shop * 30 + 2)
    end

    function p.showResults(results)
        shop.results = results
        p.status:SetText(#results .. " found")
        for i = 1, math.max(#results, #shop.rrows) do
            local r = shop.rrows[i]
            if not r and results[i] then
                r = row(sfR.child, i)
                r.buy = UI.Button(r, 96, 24, "Buy 1", "primary"); r.buy.label:SetFont(UI.FONT_SB, 10, ""); r.buy:SetPoint("RIGHT", -6, 0)
                r.right:ClearAllPoints(); r.right:SetPoint("RIGHT", r.buy, "LEFT", -8, 0)
                shop.rrows[i] = r
            end
            if r then
                local res = results[i]
                if res then
                    local info = safe(C_AuctionHouse.GetItemKeyInfo, res.itemKey) or {}
                    r.icon:SetIcon(info.iconFileID or iconFor(res.itemKey.itemID))
                    r.name:SetText(info.itemName or ("item " .. res.itemKey.itemID))
                    r.sub:SetText((res.totalQuantity or 0) .. " for sale")
                    r.right:SetText(Market.Money(res.minPrice or 0))
                    setBuyButton(r, "Buy 1", true)
                    r.buy:SetScript("OnClick", function()
                        local pnd = shop.pending
                        if pnd and pnd.row == r and pnd.ready then confirmBuy() else startBuy(r, res) end
                    end)
                    r:Show()
                else r:Hide() end
            end
        end
        sfR.child:SetHeight(#results * 38 + 2)
    end
end

-- live price for the pending buy came back: turn the button into "Confirm"
Market.OnCommodityPrice = function(unitPrice, totalPrice)
    local pnd = shop.pending
    if not pnd or not pnd.commodity then return end
    pnd.cost, pnd.ready = totalPrice, true
    setBuyButton(pnd.row, "Confirm " .. Market.Money(totalPrice), true)
end

Market.OnItemSearch = function(itemID, commodity, key)
    -- selling: live lowest price
    if sell.chosen and sell.chosen.id == itemID then onLivePrice(itemID, commodity, key) end
    -- buying a non-commodity item: grab the cheapest auction
    local pnd = shop.pending
    if pnd and not pnd.commodity and pnd.id == itemID and key then
        local r = safe(C_AuctionHouse.GetItemSearchResultInfo, key, 1)
        if r and r.auctionID and r.buyoutAmount then
            pnd.auctionID, pnd.cost, pnd.ready = r.auctionID, r.buyoutAmount, true
            setBuyButton(pnd.row, "Confirm " .. Market.Money(r.buyoutAmount), true)
        else
            setBuyButton(pnd.row, "Sold out", false)
            shop.pending = nil
        end
    end
end

Market.OnBrowse = function(results)
    if pages.shop and pages.shop:IsShown() then pages.shop.showResults(results) end
end

---------------------------------------------------------------------------
-- SCAN
---------------------------------------------------------------------------
local function buildScan(p)
    local big = UI.Title(p, 15); big:SetPoint("TOPLEFT", 0, -4); big:SetText("Full price scan")
    local d = UI.Text(p, 12, UI.C.muted); d:SetPoint("TOPLEFT", big, "BOTTOMLEFT", 0, -6); d:SetPoint("RIGHT")
    d:SetText("Reads every listing on the Auction House at once and saves the lowest price of each item. Takes a few seconds. The game allows one full scan every 15 minutes.")
    local btn = UI.Button(p, 200, 36, "Start full scan", "primary")
    btn:SetPoint("TOPLEFT", d, "BOTTOMLEFT", 0, -16)
    local track = CreateFrame("Frame", nil, p)
    track:SetPoint("TOPLEFT", btn, "BOTTOMLEFT", 0, -16); track:SetPoint("RIGHT"); track:SetHeight(6)
    UI.Flat(track, { 1, 1, 1, 0.06 }, { 1, 1, 1, 0 }, "pill")
    local fill = CreateFrame("Frame", nil, track); fill:SetPoint("TOPLEFT"); fill:SetPoint("BOTTOMLEFT"); fill:SetWidth(6)
    UI.Flat(fill, UI.C.pink, { 1, 1, 1, 0 }, "pill")
    local stat = UI.Text(p, 12); stat:SetPoint("TOPLEFT", track, "BOTTOMLEFT", 0, -14); stat:SetPoint("RIGHT")
    local more = UI.Button(p, 200, 30, "Look up a price")
    more:SetPoint("TOPLEFT", stat, "BOTTOMLEFT", 0, -20)
    more:SetScript("OnClick", Market.TogglePrices)
    function p.refresh()
        local w = track:GetWidth()
        if Market.scanning then
            btn:SetText("Scanning..."); btn:SetEnabled(false)
            fill:SetWidth(math.max(6, w * (Market.scanProgress or 0)))
            if Market.processing then
                stat:SetText("Reading listings... " .. math.floor((Market.scanProgress or 0) * 100) .. "%")
            else
                stat:SetText("Waiting for the Auction House to send every listing. This part is on the game's servers and can take a minute on busy realms. Keep the Auction House open.")
            end
        else
            btn:SetText("Start full scan"); btn:SetEnabled(true)
            fill:SetWidth(DB.lastScan and w or 6)
            stat:SetText(Market.Count() .. " items priced  ·  last full scan " .. Market.Age(DB.lastScan))
        end
    end
    btn:SetScript("OnClick", function()
        local ok, why = Market.StartScan()
        if not ok then ns.Alert("Can't scan yet", why) end
        p.refresh()
    end)
    Market.OnScanChanged = function() if p:IsShown() then p.refresh() end end
end

---------------------------------------------------------------------------
-- Panel shell
---------------------------------------------------------------------------
local function showTab(name)
    current = name
    for k, b in pairs(tabs) do
        local on = k == name
        b:SetFill(on and { 0.96, 0.55, 0.73, 0.14 } or { 1, 1, 1, 0 })
        b:SetBackdropBorderColor(0.96, 0.55, 0.73, on and 0.5 or 0)
        b.label:SetTextColor(on and 1 or 0.6, on and 1 or 0.6, on and 1 or 0.65)
    end
    for k, pg in pairs(pages) do pg:SetShown(k == name) end
    if pages[name] and pages[name].refresh then pages[name].refresh() end
end

local function build()
    panel = UI.Window("PallyPalAuction", 380, 560, "Market", "PallyPal")
    panel.content:SetPoint("TOPLEFT", 18, -104)
    local bar = CreateFrame("Frame", nil, panel)
    bar:SetPoint("TOPLEFT", 18, -58); bar:SetPoint("TOPRIGHT", -18, -58); bar:SetHeight(32)
    for i, t in ipairs({ { "sell", "Sell" }, { "shop", "Shop" }, { "scan", "Scan" } }) do
        local b = UI.Button(bar, 110, 30, t[2], "ghost")
        b:SetPoint("LEFT", (i - 1) * 116, 0)
        b:SetScript("OnClick", function() showTab(t[1]) end)
        tabs[t[1]] = b
        local pg = CreateFrame("Frame", nil, panel.content)
        pg:SetAllPoints()
        pages[t[1]] = pg
    end
    buildSell(pages.sell); buildShop(pages.shop); buildScan(pages.scan)
    panel:HookScript("OnShow", function() showTab(current) end)
end

local function placeNextToAH()
    if not panel then return end
    if ns.DB and ns.DB.layout and ns.DB.layout["win:PallyPalAuction"] then return end -- you moved it: keep it there
    if AuctionHouseFrame then
        panel:ClearAllPoints()
        panel:SetPoint("TOPLEFT", AuctionHouseFrame, "TOPRIGHT", 12, 0)
    end
end

Market.OnAHShow = function()
    if not DB or not DB.ahPanel then return end
    if not panel then build() end
    placeNextToAH()
    panel:Show()
    if DB.autoScan and Market.CanScan() and (not DB.lastScan or time() - DB.lastScan > 15 * 60) then Market.StartScan() end
end
Market.OnAHHide = function() if panel then panel:Hide() end end

ns.ToggleMarket = function()
    if not panel then build() end
    panel:SetShown(not panel:IsShown())
end

local bagEv = CreateFrame("Frame")
bagEv:SetScript("OnEvent", function()
    if panel and panel:IsShown() and current == "sell" and not sell.chosen then pages.sell.refresh() end
end)

local prevInit = ns.InitLearn
function ns.InitLearn(db)
    if prevInit then prevInit(db) end
    DB = db
    if DB.undercut == nil then DB.undercut = 0 end
    pcall(bagEv.RegisterEvent, bagEv, "BAG_UPDATE_DELAYED")
end
