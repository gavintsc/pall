-- PallyPal Professions: which professions to pick as a (future tank) Paladin,
-- where to train them, when to train the next rank, and what to craft next.
-- Picks are from Warcraft Tavern's WoW Forever Paladin guide (Icy Veins'
-- Forever profession guide is still "coming soon").
local ADDON, ns = ...
local UI = ns.UI
local DB

local function ret(ok, ...) if ok then return ... end end
local function safe(f, ...)
    if not f then return end
    return ret(pcall(f, ...))
end

-- Rank caps and the character level each rank needs (Warcraft Tavern's Forever level table)
local RANKS = {
    { cap = 75,  name = "Apprentice", level = 5 },
    { cap = 150, name = "Journeyman", level = 10 },
    { cap = 225, name = "Expert",     level = 20 },
    { cap = 300, name = "Artisan",    level = 35 },
}

local PICKS = {
    { "Mining + Blacksmithing", "Trade_BlackSmithing", "Recommended for you",
      "Plate armor, shields and weapons for all three Paladin specs. Mining feeds it, and spare ore sells well." },
    { "Herbalism + Alchemy", "Trade_Alchemy", "Strong pick",
      "Potions, plus new Forever recipes that add buffs, extra damage and crowd control." },
    { "Mining + Engineering", "Trade_Engineering", "Safe pick",
      "Gadgets, handy effects and new Engineering trinkets." },
}
local SIDE = {
    { "Cooking", "INV_Misc_Food_15", "Food buffs and faster healing between fights." },
    { "First Aid", "Spell_Holy_SealOfSacrifice", "Bandages: free healing that saves your mana." },
    { "Fishing", "Trade_Fishing", "Optional. Relaxing, feeds Cooking, fish sell well." },
}
local PRIMARY = { Mining = 1, Blacksmithing = 1, Herbalism = 1, Alchemy = 1, Engineering = 1, Skinning = 1,
    Leatherworking = 1, Tailoring = 1, Enchanting = 1, Jewelcrafting = 1, Inscription = 1 }

---------------------------------------------------------------------------
-- What you have right now
---------------------------------------------------------------------------
local function mine()
    local out = {}
    if not GetProfessions then return out end
    local list = { safe(GetProfessions) }
    for i = 1, 6 do
        local idx = list[i]
        if idx then
            local name, icon, skill, max = safe(GetProfessionInfo, idx)
            if name then out[name] = { name = name, icon = icon, skill = skill or 0, max = max or 0 } end
        end
    end
    return out
end
ns.MyProfessions = mine

local function nextRank(p)
    for _, r in ipairs(RANKS) do
        if r.cap > (p.max or 0) then return r end
    end
end

-- "Train Journeyman Mining" when you're near the cap and old enough
local function trainNeeded(p)
    local r = nextRank(p)
    if not r or p.max == 0 then return nil end
    if p.skill >= p.max - 25 and UnitLevel("player") >= r.level then return r end
end

-- For the To do panel
function ns.ProfessionTodo()
    if not DB then return {} end
    local out, have, nPrimary = {}, mine(), 0
    local level = UnitLevel("player")
    for name, p in pairs(have) do
        if PRIMARY[name] then nPrimary = nPrimary + 1 end
        local r = name ~= "Fishing" and trainNeeded(p)
        if r then table.insert(out, { text = "Train " .. r.name .. " " .. name, sub = p.skill .. " / " .. p.max .. ". Your trainer has the next rank" }) end
    end
    if ns.FishingNext then
        local t, sub = ns.FishingNext()
        if t then table.insert(out, { text = t, sub = sub }) end
    end
    if level >= 5 and nPrimary < 2 and not DB.profDismiss then
        table.insert(out, { text = nPrimary == 0 and "Pick your professions" or "Pick a second profession", sub = have.Mining and "Blacksmithing pairs with your Mining" or have.Blacksmithing and "Mining feeds your Blacksmithing" or "Mining + Blacksmithing for a tank" })
    end
    return out
end

---------------------------------------------------------------------------
-- What to craft next (read when you open a profession window)
---------------------------------------------------------------------------
local function readRecipes()
    if not (C_TradeSkillUI and C_TradeSkillUI.GetAllRecipeIDs) then return end
    if safe(C_TradeSkillUI.IsTradeSkillLinked) or safe(C_TradeSkillUI.IsTradeSkillGuild) then return end
    local base = safe(C_TradeSkillUI.GetBaseProfessionInfo)
    local prof = base and base.professionName
    if not prof or prof == "" then return end
    local list = {}
    for _, id in ipairs(safe(C_TradeSkillUI.GetAllRecipeIDs) or {}) do
        local r = safe(C_TradeSkillUI.GetRecipeInfo, id)
        -- relativeDifficulty: 0 orange (sure skill-up), 1 yellow (likely), 2 green, 3 grey
        if r and r.learned and r.relativeDifficulty and r.relativeDifficulty <= 1 and not r.isDummyRecipe then
            table.insert(list, { id = id, name = r.name, d = r.relativeDifficulty, n = r.numAvailable or 0, icon = r.icon })
        end
    end
    table.sort(list, function(a, b)
        if (a.n > 0) ~= (b.n > 0) then return a.n > 0 end -- things you can make right now first
        if a.d ~= b.d then return a.d < b.d end
        return (a.name or "") < (b.name or "")
    end)
    DB.profNext = DB.profNext or {}
    DB.profNext[prof] = {}
    for i = 1, math.min(5, #list) do DB.profNext[prof][i] = list[i] end
end

---------------------------------------------------------------------------
-- Window
---------------------------------------------------------------------------
local win
local function refresh()
    if not win or not win:IsShown() then return end
    local c = win.body
    for _, x in ipairs(win.pool.h) do x:Hide() end
    for _, x in ipairs(win.pool.r) do x:Hide() end
    for _, x in ipairs(win.pool.t) do x:Hide() end
    local nh, nr, nt = 0, 0, 0
    local have = mine()
    local y = 0

    -- reuse widgets between refreshes (no new frames every time)
    local function text(size, color)
        nt = nt + 1
        local t = win.pool.t[nt]
        if not t then t = UI.Text(c, 11); t:SetJustifyH("LEFT"); win.pool.t[nt] = t end
        t:SetFont(UI.FONT, size, "")
        local col = color or { 0.85, 0.85, 0.88, 1 }
        t:SetTextColor(col[1], col[2], col[3], col[4] or 1)
        t:ClearAllPoints(); t:Show()
        return t
    end
    local function keep(x) return x end
    local function header(label)
        nh = nh + 1
        local h = win.pool.h[nh]
        if not h then h = UI.Title(c, 10, UI.C.head); win.pool.h[nh] = h end
        h:ClearAllPoints(); h:SetPoint("TOPLEFT", 0, y); h:SetText(label); h:Show()
        y = y - 20
    end
    local function line(icon, title, sub, right, rightColor)
        nr = nr + 1
        local r = win.pool.r[nr]
        if not r then
            r = CreateFrame("Frame", nil, c); r:SetHeight(40)
            r.ic = UI.Icon(r, 28); r.ic:SetPoint("LEFT", 2, 0)
            r.t = UI.Title(r, 12); r.t:SetPoint("TOPLEFT", r.ic, "TOPRIGHT", 10, 1); r.t:SetPoint("RIGHT", -96, 0); r.t:SetJustifyH("LEFT"); r.t:SetWordWrap(false)
            r.s = UI.Text(r, 10, UI.C.muted); r.s:SetPoint("TOPLEFT", r.t, "BOTTOMLEFT", 0, -3); r.s:SetPoint("RIGHT", -96, 0); r.s:SetJustifyH("LEFT"); r.s:SetWordWrap(false)
            r.rt = UI.Text(r, 11, UI.C.muted); r.rt:SetPoint("RIGHT", -4, 0); r.rt:SetJustifyH("RIGHT")
            win.pool.r[nr] = r
        end
        r:ClearAllPoints(); r:SetPoint("TOPLEFT", 0, y); r:SetPoint("RIGHT")
        r.ic:SetIcon(icon); r.t:SetText(title); r.s:SetText(sub or "")
        local rc = rightColor or UI.C.muted
        r.rt:SetText(right or ""); r.rt:SetTextColor(rc[1], rc[2], rc[3], 1)
        r:Show()
        y = y - 44
        return r
    end

    -- your professions
    header("YOURS")
    local any = false
    for name, p in pairs(have) do
        any = true
        local r = name ~= "Fishing" and trainNeeded(p)
        local nr = nextRank(p)
        local sub = r and ("Train " .. r.name .. " now at your trainer")
            or (nr and p.max > 0 and ("Next rank: " .. nr.name .. " at level " .. nr.level .. " and skill " .. (p.max - 25)))
            or "Maxed for now"
        if name == "Fishing" then sub = (ns.FishingNext and select(1, ns.FishingNext())) or "Open the Fishing guide for where to fish next" end
        line(p.icon, name, sub, p.skill .. " / " .. p.max, r and UI.C.pink or nil)
        local nx = DB.profNext and DB.profNext[name]
        if nx and #nx > 0 then
            for i = 1, math.min(3, #nx) do
                local x = nx[i]
                local col = x.d == 0 and "|cffff8040" or "|cffffff00"
                local t = text(11); t:SetPoint("TOPLEFT", 40, y + 2); t:SetPoint("RIGHT", -4, 0); t:SetJustifyH("LEFT")
                t:SetText(col .. "•|r  " .. (x.name or "?") .. (x.n > 0 and ("  |cff6bdb80can make " .. x.n .. "|r") or "  |cff8d8f96need materials|r"))
                y = y - 18
            end
            y = y - 6
        elseif PRIMARY[name] or name == "Cooking" or name == "First Aid" then
            local t = text(10, UI.C.muted); t:SetPoint("TOPLEFT", 40, y + 2); t:SetPoint("RIGHT")
            t:SetText("Open your " .. name .. " window once and Pal will list what to make next.")
            y = y - 22
        end
    end
    if not any then
        local t = text(11, UI.C.muted); t:SetPoint("TOPLEFT", 0, y); t:SetPoint("RIGHT")
        t:SetText(UnitLevel("player") < 5 and "You can learn professions from level 5." or "None yet. Pick two below and visit their trainers.")
        y = y - 26
    end
    y = y - 8

    header("BEST FOR A PALADIN")
    for _, pk in ipairs(PICKS) do
        local a, b = pk[1]:match("(.-) %+ (.+)")
        local got = have[a] and have[b]
        local r = line("Interface\\Icons\\" .. pk[2], pk[1], pk[4], got and "You have it" or pk[3], (got or pk[3] == "Recommended for you") and UI.C.pink or nil)
    end
    y = y - 8

    header("SIDE PROFESSIONS (FREE, LEARN THEM ALL)")
    for _, sd in ipairs(SIDE) do
        local p = have[sd[1]]
        line("Interface\\Icons\\" .. sd[2], sd[1], sd[3], p and (p.skill .. " / " .. p.max) or "Not learned", p and nil or UI.C.pink)
    end
    y = y - 8

    header("WHERE ARE THE TRAINERS?")
    local t = text(11); t:SetPoint("TOPLEFT", 0, y); t:SetPoint("RIGHT"); t:SetJustifyH("LEFT")
    t:SetText("In Undercity (or any big city), talk to a guard and choose Profession Trainer, then the profession. "
        .. "The game puts a flag on your map. Small towns like Brill often have a few trainers too.\n\n"
        .. "Picked the wrong one? You can unlearn a profession from your Professions window (K) and pick another, but you lose its skill.")
    y = y - t:GetStringHeight() - 10
    c:SetHeight(-y + 10)
end

local function toggle()
    if not win then
        local f = UI.Window("PallyPalProfessions", 440, 560, "Professions", "what to learn and train")
        local sf = UI.Scroll(f.content); sf:SetPoint("TOPLEFT"); sf:SetPoint("BOTTOMRIGHT")
        if sf.SetClipsChildren then sf:SetClipsChildren(true) end
        win = f
        win.body = sf.child
        win.pool = { h = {}, r = {}, t = {} }
        f:HookScript("OnShow", function() C_Timer.After(0, refresh) end)
    end
    win:SetShown(not win:IsShown())
end
ns.ToggleProfessions = toggle

---------------------------------------------------------------------------
-- Events
---------------------------------------------------------------------------
local ev = CreateFrame("Frame")
local pending
ev:SetScript("OnEvent", function(_, event)
    if event == "TRADE_SKILL_SHOW" or event == "TRADE_SKILL_LIST_UPDATE" then
        if pending then return end
        pending = true
        C_Timer.After(1, function() pending = false; readRecipes(); refresh(); if ns.RefreshTodo then ns.RefreshTodo() end end)
    else
        if pending then return end
        pending = true
        C_Timer.After(2, function() pending = false; refresh() end)
    end
end)

local prevSlash = ns.HandleSlash
function ns.HandleSlash(msg)
    if msg == "prof" or msg == "professions" then toggle(); return true end
    return prevSlash and prevSlash(msg) or false
end

local prevInit = ns.InitLearn
function ns.InitLearn(db)
    if prevInit then prevInit(db) end
    DB = db
    for _, e in ipairs({ "TRADE_SKILL_SHOW", "TRADE_SKILL_LIST_UPDATE", "SKILL_LINES_CHANGED", "PLAYER_LEVEL_UP" }) do
        pcall(ev.RegisterEvent, ev, e)
    end
end
