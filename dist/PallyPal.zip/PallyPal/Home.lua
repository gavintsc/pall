-- PallyPal Home: Pal button, home menu, guided screen tour, settings
local ADDON, ns = ...
local LOGO = "Interface\\AddOns\\PallyPal\\Media\\logo"
local DB
local UI = ns.UI

local function say(msg, important) if ns.say then ns.say(msg, important) end end

---------------------------------------------------------------------------
-- Tour: highlights real parts of your screen and explains them
---------------------------------------------------------------------------
local function firstFrame(names)
    for _, n in ipairs(names or {}) do
        local fr = _G[n]
        if fr and fr.IsShown and fr:IsShown() then return fr end
    end
end

local PAGES = {
    { t = "Hi, I'm Pal!",
      b = "I'm here to help you learn WoW and your Paladin.\n\nThis quick tour shows what everything on your screen is. Click |cffffd100Next|r.\n\nOpen me anytime by typing |cffffd100/pal|r in chat, from the AddOns button by your minimap, or with a key you set in Options > Keybindings > AddOns.\n\nI never change your spell icons, action bars, minimap or map." },
    { t = "Moving around",
      b = "|cffffd100W A S D|r  walk\n|cffffd100Hold right mouse + move mouse|r  turn and look around\n|cffffd100Space|r  jump\n|cffffd100Mouse wheel|r  zoom in and out\n\n|cffffd100Right-click|r is your do-stuff button: talk to people, attack monsters, loot bodies.\n\n|cffffd100Tab|r targets the nearest enemy. Name colors: |cffff4040red|r attacks you, |cffffff00yellow|r only fights back, |cff40ff40green|r is friendly." },
    { t = "Your action bar", hl = { "MainActionBar", "MainMenuBar", "ActionButton1" },
      b = "These buttons are your spells. Press |cffffd1001, 2, 3...|r or click them.\n\nNew spells go in your spellbook (press |cffffd100P|r). Drag them from the book onto empty buttons.\n\nHover any spell and PallyPal adds a |cfff58cbapink note|r saying what it does and when to use it." },
    { t = "The minimap", hl = { "MinimapCluster", "Minimap" },
      b = "A small map of the area around you.\n\n|cffffd100!|r (yellow) = someone has a quest for you\n|cffffd100?|r (yellow) = a quest is ready to turn in\n\nPress |cffffd100M|r for the big map." },
    { t = "Your quests", hl = { "ObjectiveTrackerFrame", "QuestWatchFrame" },
      b = "Quests are how you level up.\n\n1. Find a yellow |cffffd100!|r and right-click the person.\n2. Click Accept.\n3. Do what it asks. Progress shows here on the right.\n4. Go back to the yellow |cffffd100?|r to turn it in for XP, gold and gear.\n\nPress |cffffd100L|r to see all your quests." },
    { t = "Chat", hl = { "ChatFrame1" },
      b = "Messages from the game and other players show up here.\n\nMy tips show up here too. They start with |cfff58cbaPallyPal:|r\n\nPress |cffffd100Enter|r to type a message." },
    { t = "Menus and bags", hl = { "MicroMenuContainer", "MicroMenu", "CharacterMicroButton" },
      b = "These little buttons open the game's menus. Or use the keys:\n\n|cffffd100C|r  your character and gear\n|cffffd100B|r  bags\n|cffffd100P|r  spellbook\n|cffffd100N|r  talents (from level 10)\n|cffffd100L|r  quest log\n|cffffd100M|r  map\n|cffffd100Esc|r  game menu and settings" },
    { t = "Your Paladin in 3 steps",
      b = "|cfff58cbaBefore a fight|r\nTurn on an |cffffd100Aura|r and a |cffffd100Blessing|r. My pink box at the top reminds you.\n\n|cfff58cbaDuring a fight|r\nKeep a |cffffd100Seal|r on (30 sec). Use |cffffd100Judgement|r and |cffffd100Holy Strike|r whenever they're ready. Judgement doesn't use up your Seal.\n\n|cfff58cbaAfter a fight|r\nSpend leftover mana on |cffffd100Holy Light|r, or use |cffffd100Cannibalize|r (heals health and mana). Drink if your blue bar is low.\n\n|cff888888Checked against Icy Veins' WoW Forever guides.|r" },
    { t = "You're ready!", final = true,
      b = "I also help in the background:\n\n- Sell your grey junk and repair at any vendor\n- Warn you when your gear is breaking\n- Tell you when to visit your trainer and what unlocks at each level\n- Explain new spells when you learn them\n- Sort your quests by importance\n\nNext, try your |cffffd100Lessons|r. They tick off as you play." },
}

local tour, glow
local page = 1

local function makeGlow()
    -- a pink outline drawn ON TOP of a game frame. It never moves or changes the frame itself.
    glow = CreateFrame("Frame", nil, UIParent, "BackdropTemplate")
    glow:SetFrameStrata("FULLSCREEN_DIALOG")
    glow:EnableMouse(false)
    glow:SetBackdrop({ edgeFile = UI.FLAT, edgeSize = 2 })
    glow:SetBackdropBorderColor(unpack(UI.C.pink))
    local fill = glow:CreateTexture(nil, "BACKGROUND")
    fill:SetPoint("TOPLEFT", 2, -2); fill:SetPoint("BOTTOMRIGHT", -2, 2)
    fill:SetColorTexture(0.96, 0.55, 0.73, 0.08)
    local tag = CreateFrame("Frame", nil, glow, "BackdropTemplate")
    UI.Flat(tag, UI.C.pinkD, UI.C.pink)
    tag:SetSize(78, 20)
    tag:SetPoint("BOTTOMLEFT", glow, "TOPLEFT", 0, 4)
    local t = UI.Text(tag, 11, { 1, 1, 1, 1 }); t:SetPoint("CENTER"); t:SetText("This one")
    local ag = glow:CreateAnimationGroup()
    local a = ag:CreateAnimation("Alpha")
    a:SetFromAlpha(1); a:SetToAlpha(0.45); a:SetDuration(0.8)
    ag:SetLooping("BOUNCE")
    glow.ag = ag
    glow:Hide()
end

local function showPage()
    local p = PAGES[page]
    if tour.ghost then tour.ghost:Hop() end
    tour.head:SetText(p.t)
    tour.body:SetText(p.b)
    tour.count:SetText(page .. " / " .. #PAGES)
    tour.back:SetEnabled(page > 1)
    tour.next:SetText(p.final and "Open Lessons" or "Next")
    for i, d in ipairs(tour.dots) do d:SetColorTexture(unpack(i == page and UI.C.pink or { 0.25, 0.26, 0.3, 1 })) end
    glow:Hide(); glow.ag:Stop()
    local target = p.hl and firstFrame(p.hl)
    if target then
        glow:ClearAllPoints()
        glow:SetPoint("TOPLEFT", target, "TOPLEFT", -6, 6)
        glow:SetPoint("BOTTOMRIGHT", target, "BOTTOMRIGHT", 6, -6)
        glow:Show(); glow.ag:Play()
    elseif p.hl then
        tour.body:SetText(p.b .. "\n\n|cff8d8f96(It isn't on screen right now. Target a mob to see it.)|r")
    end
end

local function closeTour()
    if tour then tour:Hide() end
    if glow then glow:Hide(); glow.ag:Stop() end
end

local function openTour()
    if InCombatLockdown() then say("Finish your fight first, then I'll show you around.", true) return end
    if not tour then
        makeGlow()
        local f = UI.Window("PallyPalTour", 420, 360, "Tour", "what am I looking at?")
        f:ClearAllPoints()
        f:SetPoint("CENTER", 0, 60)
        f:SetScript("OnHide", function() if glow then glow:Hide(); glow.ag:Stop() end end)
        local c = f.content
        local logo = UI.Ghost(c, 46)
        logo:SetPoint("TOPLEFT", 0, 2)
        logo:SetScript("OnClick", function(self) self:Wiggle() end)
        f.ghost = logo
        f.head = UI.Title(c, 17)
        f.head:SetPoint("LEFT", logo, "RIGHT", 12, 0)
        f.head:SetPoint("RIGHT", 0, 0)
        f.body = UI.Text(c, 12)
        f.body:SetPoint("TOPLEFT", logo, "BOTTOMLEFT", 0, -14)
        f.body:SetPoint("RIGHT", 0, 0)
        f.body:SetJustifyV("TOP")
        f.body:SetSpacing(3)
        UI.Divider(f, -312)
        f.back = UI.Button(f, 80, 26, "Back", "ghost")
        f.back:SetPoint("BOTTOMLEFT", 14, 12)
        f.back:SetScript("OnClick", function() page = math.max(1, page - 1); showPage() end)
        f.next = UI.Button(f, 120, 26, "Next", "primary")
        f.next:SetPoint("BOTTOMRIGHT", -14, 12)
        f.next:SetScript("OnClick", function()
            if PAGES[page].final then
                closeTour()
                if ns.ToggleLessons then ns.ToggleLessons() end
            else
                page = page + 1; showPage()
            end
        end)
        f.dots = {}
        local w = #PAGES * 10
        for i = 1, #PAGES do
            local d = f:CreateTexture(nil, "ARTWORK")
            d:SetSize(6, 6)
            d:SetPoint("BOTTOM", f, "BOTTOM", -w / 2 + (i - 1) * 10 + 3, 22)
            f.dots[i] = d
        end
        f.count = UI.Text(f, 10, UI.C.muted)
        f.count:Hide()
        tour = f
    end
    page = 1
    tour:Show()
    showPage()
    if tour.ghost then tour.ghost:Drop() end
    DB.toured = true
end
ns.OpenTour = openTour

---------------------------------------------------------------------------
-- Settings (switches, grouped). Also listed in the game's own AddOns options.
---------------------------------------------------------------------------
local SECTIONS = {
    { "Vendor", {
        { "sellGrey",    "Sell grey junk automatically" },
        { "repair",      "Repair gear automatically" },
        { "guildRepair", "Use guild money for repairs first" },
    } },
    { "Reminders", {
        { "buffs",       "Missing Aura / Blessing buttons (click to cast)" },
        { "hideResting", "Hide those buttons in towns and inns" },
        { "tips",        "Tips after fights (low health / mana)" },
        { "durability",  "Warn me when gear is breaking" },
        { "trainer",     "Level-up alerts (trainer + new unlocks)" },
    } },
    { "Learning", {
        { "coach",       "Explain new spells and track lessons" },
        { "tooltips",    "PallyPal notes on spell tooltips" },
        { "bestiaryTips","Show my drop rates on mob tooltips" },
    } },
    { "Quests", {
        { "sortQuests",  "Sort my quest tracker by importance" },
    } },
    { "Map", {
        { "mapPins",     "Pal pins on the world map" },
        { "mapFlights",  "Show every flight path (pink = not learned yet)" },
        { "miniPins",    "Show flight paths to learn on the minimap too" },
    } },
    { "Bars", {
        { "autoBars",    "Put newly learned spells in empty bar slots" },
    } },
    { "Market", {
        { "marketTips",  "Auction prices on item tooltips" },
        { "ahPanel",     "Open the Market panel next to the Auction House" },
        { "autoScan",    "Full scan when I open the Auction House (every 15 min)" },
    } },
    { "Interface", {
        { "todo",        "Show the To do panel" },
        { "quiet",       "Quiet mode: fewer chat messages" },
        { "minimapHide", "Show a Pal button on the minimap", true },
    } },
}

local settings
local function openSettings()
    if not settings then
        local rowsN = 0
        for _, sec in ipairs(SECTIONS) do rowsN = rowsN + #sec[2] end
        local f = UI.Window("PallyPalSettings", 420, 560, "Settings")
        local sf = UI.Scroll(f.content)
        sf:SetPoint("TOPLEFT", 0, 0); sf:SetPoint("BOTTOMRIGHT", 0, 48)
        local c = sf.child
        c:SetWidth(384)
        local y = 0
        f.toggles = {}
        for _, sec in ipairs(SECTIONS) do
            local h = UI.Title(c, 10, UI.C.head)
            h:SetPoint("TOPLEFT", 0, y)
            h:SetText(sec[1]:upper())
            y = y - 22
            for _, it in ipairs(sec[2]) do
                local key = it[1]
                local inv = it[3]
                local row = UI.Toggle(c, it[2], function()
                    local v = DB[key] and true or false
                    if inv then return not v end
                    return v
                end, function(v)
                    if inv then v = not v end
                    DB[key] = v
                    if key == "minimapHide" and ns.UpdateMinimapButton then ns.UpdateMinimapButton() end
                    if ns.RefreshReminder then ns.RefreshReminder() end
                    if ns.RefreshTodo then ns.RefreshTodo() end
                    if ns.RefreshMapPins then ns.RefreshMapPins() end
                end)
                row:SetPoint("TOPLEFT", 0, y)
                row:SetPoint("RIGHT", 0, 0)
                local other = ns.ConflictFor and ns.ConflictFor(key)
                if other then
                    row.note:SetText("Handled by " .. other .. ", so PallyPal stays out of the way.")
                    row:SetAlpha(0.6)
                end
                table.insert(f.toggles, row)
                y = y - (other and 40 or 32)
            end
            y = y - 14
        end
        c:SetHeight(-y + 10)
        local tourBtn = UI.Button(f, 184, 32, "Restart the tour")
        tourBtn:SetPoint("BOTTOMLEFT", 18, 18)
        tourBtn:SetScript("OnClick", function() f:Hide(); openTour() end)
        local moveBtn = UI.Button(f, 184, 32, "Edit layout", "primary")
        moveBtn:SetPoint("BOTTOMRIGHT", -18, 18)
        moveBtn:SetScript("OnClick", function() f:Hide(); UI.SetEditMode(true) end)
        f:HookScript("OnShow", function() for _, r in ipairs(f.toggles) do r:Refresh() end end)
        settings = f
    end
    settings:SetShown(not settings:IsShown())
end
ns.OpenSettings = openSettings

---------------------------------------------------------------------------
-- Home menu
---------------------------------------------------------------------------
local home
local function toggleHome()
    if not home then
        -- WoW-styled menu: icon rail on the left, pixel-art banner, details on the right
        local GOLD = { 1, 1, 1 }
        local GLY = UI.MEDIA .. "icons\\"
        local WOWF = (GameFontNormal and GameFontNormal:GetFont()) or STANDARD_TEXT_FONT
        local function wowText(parent, size, color, title)
            local fs = parent:CreateFontString(nil, "OVERLAY")
            local ok = fs:SetFont(title and (UI.FONT_B or UI.FONT) or UI.FONT, size, "")
            if not ok then fs:SetFont(WOWF, size, "") end
            fs:SetShadowOffset(1, -1); fs:SetShadowColor(0, 0, 0, 0.9)
            local c = color or { 0.92, 0.9, 0.86 }
            fs:SetTextColor(c[1], c[2], c[3])
            fs:SetJustifyH("LEFT")
            return fs
        end

        local f = UI.Window("PallyPalHome", 640, 560, "")
        -- remember where the menu was so the page opens in the same spot, with a Back arrow
        local function leave() f:Hide() end -- only for things that aren't pages (tour, edit layout)
        if f.title then f.title:Hide() end
        for _, r in ipairs({ f:GetRegions() }) do
            if r.GetTexture and r:GetObjectType() == "Texture" and r:GetDrawLayer() == "ARTWORK" and r:GetWidth() == 18 then r:Hide() end
        end
        if f.SetBackdropColor then f:SetBackdropColor(0.07, 0.07, 0.08, 0.98); f:SetBackdropBorderColor(1, 1, 1, 0.08) end

        -- left rail
        local rail = CreateFrame("Frame", nil, f)
        rail:SetPoint("TOPLEFT", 10, -10); rail:SetPoint("BOTTOMLEFT", 10, 10); rail:SetWidth(48)
        UI.Flat(rail, { 0, 0, 0, 1 }, { 1, 1, 1, 0.06 }, "pill")

        -- banner
        local banner = CreateFrame("Frame", nil, f)
        banner:SetPoint("TOPLEFT", rail, "TOPRIGHT", 10, 0); banner:SetPoint("TOPRIGHT", -10, -10); banner:SetHeight(220)
        local art = banner:CreateTexture(nil, "BACKGROUND")
        art:SetAllPoints(); art:SetTexture(UI.MEDIA .. "art1"); art:SetTexCoord(0, 1, 0.09, 0.91)
        local fade = banner:CreateTexture(nil, "BORDER")
        fade:SetPoint("BOTTOMLEFT"); fade:SetPoint("BOTTOMRIGHT"); fade:SetHeight(90)
        fade:SetColorTexture(1, 1, 1, 1)
        if fade.SetGradient and CreateColor then fade:SetGradient("VERTICAL", CreateColor(0.03, 0.03, 0.05, 0.95), CreateColor(0.03, 0.03, 0.05, 0)) else fade:SetVertexColor(0, 0, 0, 0.4) end
        local edge = banner:CreateTexture(nil, "OVERLAY")
        edge:SetPoint("BOTTOMLEFT"); edge:SetPoint("BOTTOMRIGHT"); edge:SetHeight(1); edge:SetColorTexture(1, 1, 1, 0)

        local logo = UI.Ghost(banner, 54)
        logo:SetPoint("BOTTOMLEFT", 16, 14)
        local hi = wowText(banner, 26, GOLD, true)
        hi:SetPoint("BOTTOMLEFT", logo, "BOTTOMRIGHT", 12, 22); hi:SetText("PallyPal")
        local sub = wowText(banner, 12, { 0.85, 0.82, 0.78 })
        sub:SetPoint("TOPLEFT", hi, "BOTTOMLEFT", 2, -2); sub:SetText("Your Paladin's ghostly companion")
        local POKES = { "Boo! ...was that scary?", "I'm a ghost, but a friendly one.", "Tanks go in first. That's you!",
            "Seal on, Judgement, Holy Strike. Easy.", "Have you checked your quests?", "Hehe, that tickles." }
        logo:SetScript("OnClick", function(self) self:Wiggle(); self:Hop(); sub:SetText(POKES[math.random(#POKES)]) end)

        -- detail area
        local body = CreateFrame("Frame", nil, f)
        body:SetPoint("TOPLEFT", banner, "BOTTOMLEFT", 6, -16); body:SetPoint("BOTTOMRIGHT", -16, 52)
        local dIcon = CreateFrame("Frame", nil, body); dIcon:SetSize(44, 44); dIcon:SetPoint("TOPLEFT")
        UI.Flat(dIcon, { 0, 0, 0, 1 }, { 1, 1, 1, 0.08 }, "small")
        local dGly = dIcon:CreateTexture(nil, "ARTWORK"); dGly:SetSize(22, 22); dGly:SetPoint("CENTER")
        function dIcon:SetIcon(t) dGly:SetTexture(t) end
        local dName = wowText(body, 17, GOLD, true); dName:SetPoint("TOPLEFT", dIcon, "TOPRIGHT", 14, -2)
        local dDesc = wowText(body, 13); dDesc:SetPoint("TOPLEFT", dName, "BOTTOMLEFT", 0, -6); dDesc:SetWidth(470)
        dDesc:SetWordWrap(true)
        local openBtn = UI.Button(body, 130, 32, "Open", "primary")
        openBtn:SetPoint("TOPLEFT", dIcon, "BOTTOMLEFT", 0, -20)

        -- "Up next" list, shown when nothing is picked
        local upHead = wowText(body, 10, { 0.55, 0.55, 0.6 }, true); upHead:SetPoint("TOPLEFT"); upHead:SetText("UP NEXT")
        local ups = {}
        for i = 1, 4 do
            local r = CreateFrame("Button", nil, body); r:SetHeight(30)
            r:SetPoint("TOPLEFT", 0, -24 - (i - 1) * 32); r:SetPoint("RIGHT")
            r.ic = UI.Icon(r, 22); r.ic:SetPoint("LEFT", 2, 0)
            r.t = wowText(r, 13); r.t:SetPoint("LEFT", r.ic, "RIGHT", 10, 0); r.t:SetPoint("RIGHT", -6, 0); r.t:SetWordWrap(false)
            local hl = r:CreateTexture(nil, "BACKGROUND"); hl:SetAllPoints(); hl:SetColorTexture(GOLD[1], GOLD[2], GOLD[3], 0)
            r:SetScript("OnEnter", function() hl:SetColorTexture(GOLD[1], GOLD[2], GOLD[3], 0.08) end)
            r:SetScript("OnLeave", function() hl:SetColorTexture(GOLD[1], GOLD[2], GOLD[3], 0) end)
            ups[i] = r
        end
        local detail = { dIcon, dName, dDesc, openBtn }
        local function showOverview()
            for _, x in ipairs(detail) do x:Hide() end
            upHead:Show()
            local list = ns.TodoItems and ns.TodoItems() or {}
            for i, r in ipairs(ups) do
                local it = list[i]
                if it then
                    r.ic:SetIcon(it.icon); r.t:SetText(it.text .. (it.sub and ("  |cff9a948a" .. it.sub .. "|r") or ""))
                    r:SetScript("OnClick", function() if it.click then go(it.click) end end)
                    r:Show()
                elseif i == 1 then
                    r.ic:SetIcon("Interface\\Icons\\INV_Misc_Note_02"); r.t:SetText("All caught up. Go adventure!"); r:SetScript("OnClick", nil); r:Show()
                else r:Hide() end
            end
        end

        -- pages open inside the menu, on the right of the rail
        local host = CreateFrame("Frame", nil, f)
        host:SetPoint("TOPLEFT", rail, "TOPRIGHT", 10, 0); host:SetPoint("BOTTOMRIGHT", -10, 10)
        local overviewParts = { banner, body, foot = nil }
        local function setOverview(on)
            banner:SetShown(on); body:SetShown(on)
            if f.foot then f.foot:SetShown(on) end
        end
        host.onEmbed = function(page)
            f.page = page
            setOverview(false)
            f:SetSize(math.max(640, 68 + page:GetWidth() - 10), math.max(560, page:GetHeight() + 8))
        end
        host.onPageClosed = function(page)
            if f.page == page then f.page = nil end
            if f.switching then return end
            f:SetSize(640, 560)
            setOverview(true)
            showOverview()
        end
        local function go(fn)
            if f.page then f.switching = true; f.page:Hide(); f.switching = false end
            UI.embedInto = { t = GetTime(), host = host }
            fn()
            if UI.embedInto and not f.page then fn() end -- it was already open somewhere: the first call closed it
            UI.embedInto = nil
            if not f.page then f:SetSize(640, 560); setOverview(true); showOverview() end
        end
        f.go = go

        local items = {
            { "Tour", "What am I looking at? A guided tour of your screen, one piece at a time.", openTour, "INV_Misc_Map_01", "map", leave = true },
            { "Tank path", "Your plan from now until you're tanking dungeons: talents, spells and gear.", function() if ns.ToggleTank then ns.ToggleTank() end end, "Ability_Defend", "shield" },
            { "Quest priority", "Your quests, most important first. Track them and read what each one wants.", function() if ns.ToggleQuests then ns.ToggleQuests() end end, "INV_Misc_Note_01", "list" },
            { "Lessons", "Small goals that teach you the Paladin by playing.", function() if ns.ToggleLessons then ns.ToggleLessons() end end, "INV_Misc_Book_09", "book" },
            { "Paladin basics", "Your spells explained, and how a fight should go.", function() if ns.ToggleGuide then ns.ToggleGuide() end end, "Spell_Holy_HolyBolt", "sun" },
            { "Set up my bars", "Put your spells on the right keys in one click.", function() if ns.ToggleBars then ns.ToggleBars() end end, "INV_Misc_Gear_01", "grid" },
            { "Market", "Auction House prices and quick selling.", function() if ns.ToggleMarket then ns.ToggleMarket() end end, "INV_Misc_Coin_02", "coin" },
            { "Disenchant", "Turn spare gear into enchanting dust, one click per item.", function() if ns.ToggleDisenchant then ns.ToggleDisenchant() end end, "INV_Enchant_Disenchant", "sparkle" },
            { "Professions", "What to learn, when to train, and what to craft next.", function() if ns.ToggleProfessions then ns.ToggleProfessions() end end, "Trade_BlackSmithing", "hammer" },
            { "Fishing", "Your fishing progress from 1 to 300: where to fish, lures, and how to unlock each rank.", function() if ns.ToggleFishing then ns.ToggleFishing() end end, "Trade_Fishing", "fish" },
            { "Flights to learn", "Every flight path on your continent you haven't picked up yet.", function() if ns.ToggleFlights then ns.ToggleFlights() end end, "Ability_Mount_Wyvern_01", "wing" },
            { "Bestiary", "Mobs you've met and what they drop.", function() if ns.ToggleIndex then ns.ToggleIndex() end end, "INV_Misc_Bone_HumanSkull_01", "skull" },
        }
        local picked
        local function pick(it, btn)
            if f.page then return end
            picked = btn
            upHead:Hide(); for _, r in ipairs(ups) do r:Hide() end
            for _, x in ipairs(detail) do x:Show() end
            dIcon:SetIcon(GLY .. it[5]); dName:SetText(it[1]); dDesc:SetText(it[2])
            openBtn:SetScript("OnClick", function() if it.leave then leave(); it[3]() else go(it[3]) end end)
        end
        local rbtns = {}
        local homeB = CreateFrame("Button", nil, rail); homeB:SetSize(34, 34); homeB:SetPoint("TOP", 0, -10)
        local hbg = homeB:CreateTexture(nil, "BACKGROUND"); hbg:SetAllPoints(); hbg:SetTexture(UI.MEDIA .. "circle"); hbg:SetVertexColor(1, 1, 1, 1)
        local hic = homeB:CreateTexture(nil, "ARTWORK"); hic:SetSize(18, 18); hic:SetPoint("CENTER"); hic:SetTexture(GLY .. "home"); hic:SetVertexColor(0, 0, 0)
        homeB:SetScript("OnEnter", function() if not f.page then showOverview() end end)
        homeB:SetScript("OnClick", function() if f.page then f.page:Hide() else showOverview() end end)
        for i, it in ipairs(items) do
            local b = CreateFrame("Button", nil, rail)
            b:SetSize(32, 32); b:SetPoint("TOP", 0, -50 - (i - 1) * 32)
            local hl = b:CreateTexture(nil, "BACKGROUND"); hl:SetAllPoints(); hl:SetTexture(UI.MEDIA .. "circle"); hl:SetVertexColor(1, 1, 1, 0)
            local ic = b:CreateTexture(nil, "ARTWORK"); ic:SetSize(18, 18); ic:SetPoint("CENTER"); ic:SetTexture(GLY .. it[5]); ic:SetAlpha(0.5)
            b:SetScript("OnEnter", function() hl:SetVertexColor(1, 1, 1, 0.12); ic:SetAlpha(1); pick(it, b) end)
            b:SetScript("OnLeave", function() hl:SetVertexColor(1, 1, 1, 0); ic:SetAlpha(0.5) end)
            b:SetScript("OnClick", function() if it.leave then leave(); it[3]() else go(it[3]) end end)
            rbtns[i] = b
        end
        -- edit layout + settings live at the bottom of the rail
        local function railFoot(gly, y, tipName, tipDesc, fn)
            local b = CreateFrame("Button", nil, rail)
            b:SetSize(34, 34); b:SetPoint("BOTTOM", 0, y)
            local hl = b:CreateTexture(nil, "BACKGROUND"); hl:SetAllPoints(); hl:SetTexture(UI.MEDIA .. "circle"); hl:SetVertexColor(1, 1, 1, 0)
            local ic = b:CreateTexture(nil, "ARTWORK"); ic:SetSize(18, 18); ic:SetPoint("CENTER"); ic:SetTexture(GLY .. gly); ic:SetAlpha(0.5)
            b:SetScript("OnEnter", function() hl:SetVertexColor(1, 1, 1, 0.12); ic:SetAlpha(1); pick({ tipName, tipDesc, fn, nil, gly }, b) end)
            b:SetScript("OnLeave", function() hl:SetVertexColor(1, 1, 1, 0); ic:SetAlpha(0.5) end)
            b:SetScript("OnClick", function() if gly == "move" then leave(); fn() else go(fn) end end)
        end
        railFoot("gear", 10, "Settings", "Turn PallyPal's helpers on or off.", openSettings)
        railFoot("move", 46, "Edit layout", "Drag PallyPal's boxes anywhere on your screen.", function() UI.SetEditMode(true) end)

        -- mouse back over the banner = overview again
        banner:EnableMouse(true)
        banner:SetScript("OnEnter", showOverview)

        local foot = wowText(f, 11, { 0.6, 0.58, 0.54 })
        f.foot = foot
        foot:SetPoint("BOTTOMLEFT", rail, "BOTTOMRIGHT", 14, 10)
        foot:SetText("Hover an icon to read about it, click to open.   /pal anytime  ·  " .. ((C_AddOns and C_AddOns.GetAddOnMetadata and C_AddOns.GetAddOnMetadata(ADDON, "Version")) or ""))
        local artN = 0
        f:HookScript("OnShow", function()
            artN = artN % 4 + 1; art:SetTexture(UI.MEDIA .. "art" .. artN) -- a different WoW scene each time
            logo:Drop(); sub:SetText("Your Paladin's ghostly companion"); showOverview() end)
        showOverview()
        home = f
    end
    home:SetShown(not home:IsShown())
end
ns.ToggleHome = toggleHome
UI.OpenHome = function(x, top)
    if not (home and home:IsShown()) then toggleHome() end
    -- come back in the same spot the page was
    if home and x and top then home:ClearAllPoints(); home:SetPoint("TOP", UIParent, "BOTTOMLEFT", x, top) end
end

-- Keybindings (Options > Keybindings > AddOns > PallyPal)
BINDING_HEADER_PALLYPAL = "PallyPal"
BINDING_NAME_PALLYPAL_HOME = "Open Pal"
BINDING_NAME_PALLYPAL_QUESTS = "Quest priority"
BINDING_NAME_PALLYPAL_TOUR = "Screen tour"
function PallyPal_ToggleHome() toggleHome() end
function PallyPal_OpenTour() openTour() end
function PallyPal_ToggleQuests() if ns.ToggleQuests then ns.ToggleQuests() end end

-- The game's built-in AddOns menu (the button by the minimap) can open Pal too
function PallyPal_OnCompartmentClick(_, button)
    if button == "RightButton" then openTour() else toggleHome() end
end
function PallyPal_OnCompartmentEnter(_, menuButton)
    GameTooltip:SetOwner(menuButton, "ANCHOR_LEFT")
    GameTooltip:AddLine("|cfff58cbaPallyPal|r")
    GameTooltip:AddLine("Click: open Pal   Right-click: tour", 1, 1, 1)
    GameTooltip:Show()
end
function PallyPal_OnCompartmentLeave() GameTooltip:Hide() end

-- Also show up under Esc > Options > AddOns
local function registerOptions()
    if not (Settings and Settings.RegisterCanvasLayoutCategory) then return end
    local panel = CreateFrame("Frame")
    local t = UI.Text(panel, 16, { 1, 1, 1, 1 }); t:SetPoint("TOPLEFT", 16, -16); t:SetText("PallyPal")
    local d = UI.Text(panel, 12, UI.C.muted); d:SetPoint("TOPLEFT", t, "BOTTOMLEFT", 0, -8)
    d:SetText("All PallyPal options live in its own Settings window.")
    local b = UI.Button(panel, 180, 26, "Open PallyPal settings", "primary")
    b:SetPoint("TOPLEFT", d, "BOTTOMLEFT", 0, -14)
    b:SetScript("OnClick", function() if SettingsPanel then HideUIPanel(SettingsPanel) end; openSettings() end)
    pcall(function()
        local cat = Settings.RegisterCanvasLayoutCategory(panel, "PallyPal")
        Settings.RegisterAddOnCategory(cat)
    end)
end

---------------------------------------------------------------------------
-- Minimap button (classic style, sits on the minimap ring; draggable)
---------------------------------------------------------------------------
local mb
local function placeButton()
    local a = math.rad(DB.minimapAngle or 210)
    local r = (Minimap:GetWidth() / 2) + 10
    mb:ClearAllPoints()
    mb:SetPoint("CENTER", Minimap, "CENTER", math.cos(a) * r, math.sin(a) * r)
end

function ns.UpdateMinimapButton()
    if mb then mb:SetShown(not DB.minimapHide) end
end

local function makeMinimapButton()
    if not Minimap then return end
    mb = CreateFrame("Button", "PallyPalMinimapButton", Minimap)
    mb:SetSize(32, 32)
    mb:SetFrameStrata("MEDIUM")
    mb:SetFrameLevel(8)
    mb:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    mb:RegisterForDrag("LeftButton")
    local icon = mb:CreateTexture(nil, "ARTWORK")
    icon:SetTexture(LOGO)
    icon:SetSize(20, 20)
    icon:SetPoint("CENTER", 0, 0)
    local mask = mb:CreateMaskTexture()
    mask:SetTexture("Interface\\CharacterFrame\\TempPortraitAlphaMask", "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
    mask:SetAllPoints(icon)
    icon:AddMaskTexture(mask)
    local border = mb:CreateTexture(nil, "OVERLAY")
    border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    border:SetSize(54, 54)
    border:SetPoint("TOPLEFT")
    mb:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
    mb:SetScript("OnClick", function(_, btn)
        if btn == "RightButton" then openTour() else toggleHome() end
    end)
    mb:SetScript("OnDragStart", function(self)
        self:SetScript("OnUpdate", function()
            local mx, my = Minimap:GetCenter()
            local cx, cy = GetCursorPosition()
            local s = Minimap:GetEffectiveScale()
            DB.minimapAngle = math.deg(math.atan2(cy / s - my, cx / s - mx))
            placeButton()
        end)
    end)
    mb:SetScript("OnDragStop", function(self) self:SetScript("OnUpdate", nil) end)
    mb:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:AddLine("|cfff58cbaPallyPal|r")
        GameTooltip:AddLine("Click: open Pal", 1, 1, 1)
        GameTooltip:AddLine("Right-click: screen tour", 1, 1, 1)
        GameTooltip:AddLine("Drag: move this button", 0.6, 0.6, 0.6)
        GameTooltip:Show()
    end)
    mb:SetScript("OnLeave", function() GameTooltip:Hide() end)
    placeButton()
    ns.UpdateMinimapButton()
end

---------------------------------------------------------------------------
-- Slash + init (chained onto the other modules)
---------------------------------------------------------------------------
local prevSlash = ns.HandleSlash
function ns.HandleSlash(msg)
    if msg == "tour" then openTour(); return true
    elseif msg == "home" then toggleHome(); return true
    elseif msg == "settings" or msg == "options" or msg == "config" then openSettings(); return true
    elseif msg == "todo" then DB.todo = not DB.todo; if ns.RefreshTodo then ns.RefreshTodo() end; return true
    end
    return prevSlash and prevSlash(msg) or false
end

local ev = CreateFrame("Frame")
ev:SetScript("OnEvent", function(self, event)
    if event == "PLAYER_ENTERING_WORLD" then
        self:UnregisterEvent("PLAYER_ENTERING_WORLD")
        -- first time ever: show the tour, but never inside a dungeon or fight
        if not DB.toured and not IsInInstance() then
            C_Timer.After(3, function() if not InCombatLockdown() then openTour() end end)
        end
    elseif event == "PLAYER_REGEN_DISABLED" then
        closeTour() -- get out of the way as soon as a fight starts
    end
end)

local prevInit = ns.InitLearn
function ns.InitLearn(db)
    if prevInit then prevInit(db) end
    DB = db
    if not DB.minimapMigrated then DB.minimapHide = true; DB.minimapMigrated = true end
    makeMinimapButton()
    registerOptions()
    ev:RegisterEvent("PLAYER_ENTERING_WORLD")
    ev:RegisterEvent("PLAYER_REGEN_DISABLED")
end
