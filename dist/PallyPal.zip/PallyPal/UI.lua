-- PallyPal UI kit: rounded glass panels, soft shadows, Inter font, rounded icons.
-- Everything here builds PallyPal's own frames. Nothing reskins or moves Blizzard frames.
local ADDON, ns = ...
local UI = {}
ns.UI = UI

local MEDIA = "Interface\\AddOns\\PallyPal\\Media\\"
UI.MEDIA = MEDIA
UI.FLAT = "Interface\\Buttons\\WHITE8x8"
UI.FONT = MEDIA .. "fonts\\Inter-Regular.ttf"
UI.FONT_SB = MEDIA .. "fonts\\Inter-SemiBold.ttf"
UI.FONT_B = MEDIA .. "fonts\\Inter-Bold.ttf"

UI.C = {
    bg     = { 0.070, 0.070, 0.078, 0.98 },
    panel  = { 0.105, 0.105, 0.115, 1 },
    panel2 = { 0.140, 0.140, 0.152, 1 },
    hover  = { 0.180, 0.180, 0.195, 1 },
    line   = { 1, 1, 1, 0.06 },
    line2  = { 1, 1, 1, 0.10 },
    head   = { 0.52, 0.52, 0.57, 1 },
    pink   = { 0.96, 0.55, 0.73, 1 },
    pinkD  = { 0.50, 0.23, 0.37, 1 },
    pinkBg = { 0.96, 0.55, 0.73, 0.10 },
    text   = { 0.93, 0.92, 0.89, 1 },
    muted  = { 0.56, 0.57, 0.62, 1 },
    gold   = { 1.00, 0.82, 0.30, 1 },
    green  = { 0.42, 0.86, 0.50, 1 },
    red    = { 1.00, 0.47, 0.47, 1 },
}
local C = UI.C

---------------------------------------------------------------------------
-- Rounded shapes (9-slice textures, so corners stay crisp at any size)
---------------------------------------------------------------------------
local SHAPES = {
    panel = { fill = "r12_fill", edge = "r12_edge", m = 16 },
    small = { fill = "r6_fill",  edge = "r6_edge",  m = 8 },
    pill  = { fill = "pill_fill", edge = "pill_edge", m = 15 },
}

local function slice(tex, file, m)
    tex:SetTexture(MEDIA .. file)
    if tex.SetTextureSliceMargins then
        tex:SetTextureSliceMargins(m, m, m, m)
        if tex.SetTextureSliceMode then tex:SetTextureSliceMode(0) end
    end
end

-- UI.Flat(frame, bgColor, borderColor, shape) gives any frame a rounded body + hairline border.
-- It also keeps SetBackdropColor / SetBackdropBorderColor working, so older code still works.
function UI.Flat(f, bg, border, shape)
    local sh = SHAPES[shape or "small"]
    if not f.ppFill then
        f.ppFill = f:CreateTexture(nil, "BACKGROUND", nil, -7)
        f.ppFill:SetAllPoints()
        f.ppEdge = f:CreateTexture(nil, "BORDER", nil, -7)
        f.ppEdge:SetAllPoints()
        f.SetBackdropColor = function(self, r, g, b, a) self.ppFill:SetVertexColor(r, g, b, a or 1) end
        f.SetBackdropBorderColor = function(self, r, g, b, a) self.ppEdge:SetVertexColor(r, g, b, a or 1) end
        f.SetBackdrop = function(self, v) self.ppFill:SetShown(v ~= nil); self.ppEdge:SetShown(v ~= nil) end
    end
    slice(f.ppFill, sh.fill, sh.m)
    slice(f.ppEdge, sh.edge, sh.m)
    f.ppFill:Show(); f.ppEdge:Show()
    f:SetBackdropColor(unpack(bg or C.bg))
    f:SetBackdropBorderColor(unpack(border or C.line2))
end

function UI.Shadow(f, spread, alpha)
    spread = spread or 26
    local s = f:CreateTexture(nil, "BACKGROUND", nil, -8)
    slice(s, "softshadow", 48)
    s:SetPoint("TOPLEFT", -spread, spread - 6)
    s:SetPoint("BOTTOMRIGHT", spread, -spread - 6)
    s:SetVertexColor(0, 0, 0, alpha or 0.9)
    f.ppShadow = s
    return s
end

---------------------------------------------------------------------------
-- Text
---------------------------------------------------------------------------
function UI.Text(parent, size, color, flags, font)
    local fs = parent:CreateFontString(nil, "OVERLAY")
    if not fs:SetFont(font or UI.FONT, size or 12, flags or "") then
        fs:SetFont(STANDARD_TEXT_FONT, size or 12, flags or "") -- fallback if the font can't load
    end
    fs:SetTextColor(unpack(color or C.text))
    fs:SetJustifyH("LEFT")
    fs:SetWordWrap(true)
    fs:SetShadowOffset(0, 0)
    return fs
end

function UI.Title(parent, size, color)
    return UI.Text(parent, size or 14, color or { 1, 1, 1, 1 }, "", UI.FONT_SB)
end

function UI.Divider(parent, y, inset)
    inset = inset or 16
    local t = parent:CreateTexture(nil, "ARTWORK")
    t:SetColorTexture(unpack(C.line))
    t:SetHeight(1)
    t:SetPoint("TOPLEFT", inset, y)
    t:SetPoint("TOPRIGHT", -inset, y)
    return t
end

-- Rounded game icon (uses the real spell/item art from the game)
function UI.Icon(parent, size, texture)
    local holder = CreateFrame("Frame", nil, parent)
    holder:SetSize(size, size)
    local t = holder:CreateTexture(nil, "ARTWORK")
    t:SetAllPoints()
    t:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    local mask = holder:CreateMaskTexture()
    mask:SetTexture(MEDIA .. "iconmask", "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
    mask:SetAllPoints(t)
    t:AddMaskTexture(mask)
    holder.tex = t
    function holder:SetIcon(tex) t:SetTexture(tex or 134400) end
    holder:SetIcon(texture)
    return holder
end

-- Icon helper: spell texture if known, else a file path, else "?"
function UI.SpellIcon(name, fallback)
    local ok, tex = pcall(C_Spell.GetSpellTexture, name)
    if ok and tex then return tex end
    return fallback and ("Interface\\Icons\\" .. fallback) or 134400
end

---------------------------------------------------------------------------
-- Buttons
---------------------------------------------------------------------------
-- kind: nil (default), "primary", "ghost"
function UI.Button(parent, w, h, label, kind)
    local b = CreateFrame("Button", nil, parent)
    b:SetSize(w, h)
    local fill = kind == "primary" and { 0.93, 0.93, 0.94, 1 } or (kind == "ghost" and { 1, 1, 1, 0 } or C.panel2)
    local hoverFill = kind == "primary" and { 1, 1, 1, 1 } or (kind == "ghost" and { 1, 1, 1, 0.05 } or C.hover)
    local edge = kind == "primary" and { 1, 1, 1, 0.0 } or C.line2
    UI.Flat(b, fill, edge, "small")
    b.label = UI.Text(b, 12, kind == "primary" and { 0.06, 0.06, 0.07, 1 } or { 1, 1, 1, 1 }, "", UI.FONT_SB)
    b.label:SetPoint("CENTER", 0, 0)
    b.label:SetJustifyH("CENTER")
    b.label:SetWordWrap(false)
    b.label:SetText(label)
    b.kind = kind
    b.SetText = function(self, t) self.label:SetText(t) end
    b.SetFill = function(self, c) fill = c; self:SetBackdropColor(unpack(c)) end
    b:SetScript("OnEnter", function(self) if self:IsEnabled() then self:SetBackdropColor(unpack(hoverFill)) end end)
    b:SetScript("OnLeave", function(self) self:SetBackdropColor(unpack(fill)) end)
    b:SetScript("OnMouseDown", function(self) if self:IsEnabled() then self.label:SetPoint("CENTER", 0, -1) end end)
    b:SetScript("OnMouseUp", function(self) self.label:SetPoint("CENTER", 0, 0) end)
    b:HookScript("OnDisable", function(self) self:SetAlpha(0.35) end)
    b:HookScript("OnEnable", function(self) self:SetAlpha(1) end)
    return b
end

-- Menu tile: icon + title + caption
function UI.MenuItem(parent, w, title, caption, primary, icon)
    local b = CreateFrame("Button", nil, parent)
    b:SetSize(w, 58)
    local fill = primary and { 0.96, 0.55, 0.73, 0.10 } or C.panel
    local edge = primary and { 0.96, 0.55, 0.73, 0.35 } or C.line
    UI.Flat(b, fill, edge, "small")
    local x = 14
    if icon then
        b.icon = UI.Icon(b, 32, icon)
        b.icon:SetPoint("LEFT", 12, 0)
        x = 54
    end
    b.label = UI.Title(b, 13)
    b.label:SetPoint("TOPLEFT", x, -12)
    b.label:SetPoint("RIGHT", -10, 0)
    b.label:SetWordWrap(false)
    b.label:SetText(title)
    b.cap = UI.Text(b, 11, C.muted)
    b.cap:SetPoint("TOPLEFT", b.label, "BOTTOMLEFT", 0, -3)
    b.cap:SetPoint("RIGHT", -10, 0)
    b.cap:SetWordWrap(false)
    b.cap:SetText(caption)
    b.SetText = function(self, t) self.label:SetText(t) end
    b:SetScript("OnEnter", function(self)
        self:SetBackdropColor(unpack(primary and { 0.96, 0.55, 0.73, 0.16 } or C.hover))
        self:SetBackdropBorderColor(unpack(primary and { 0.96, 0.55, 0.73, 0.6 } or C.line2))
    end)
    b:SetScript("OnLeave", function(self) self:SetBackdropColor(unpack(fill)); self:SetBackdropBorderColor(unpack(edge)) end)
    return b
end

-- On/off switch
function UI.Toggle(parent, label, getter, setter)
    local row = CreateFrame("Button", nil, parent)
    row:SetHeight(26)
    local track = CreateFrame("Frame", nil, row)
    track:SetSize(32, 18)
    track:SetPoint("RIGHT", 0, 0)
    UI.Flat(track, C.panel2, C.line2, "pill")
    local knob = track:CreateTexture(nil, "OVERLAY")
    knob:SetTexture(MEDIA .. "circle")
    knob:SetSize(12, 12)
    local text = UI.Text(row, 12)
    text:SetPoint("LEFT", 0, 0)
    text:SetPoint("RIGHT", track, "LEFT", -12, 0)
    text:SetText(label)
    row.label = text
    row.note = UI.Text(row, 10, C.muted)
    row.note:SetPoint("TOPLEFT", text, "BOTTOMLEFT", 0, -2)
    row.note:SetPoint("RIGHT", track, "LEFT", -12, 0)
    local function paint()
        local on = getter()
        knob:ClearAllPoints()
        if on then
            knob:SetPoint("RIGHT", -3, 0); knob:SetVertexColor(1, 1, 1)
            track:SetBackdropColor(unpack(C.pink)); track:SetBackdropBorderColor(1, 1, 1, 0)
        else
            knob:SetPoint("LEFT", 3, 0); knob:SetVertexColor(0.55, 0.56, 0.6)
            track:SetBackdropColor(unpack(C.panel2)); track:SetBackdropBorderColor(unpack(C.line2))
        end
    end
    row:SetScript("OnClick", function() setter(not getter()); paint() end)
    row:SetScript("OnShow", paint)
    row.Refresh = paint
    paint()
    return row
end

---------------------------------------------------------------------------
-- Saved positions + Edit layout mode
---------------------------------------------------------------------------
local movers = {}
local editing = false

local function savePos(frame, key)
    if not ns.DB then return end
    ns.DB.layout = ns.DB.layout or {}
    local p, _, rp, x, y = frame:GetPoint()
    ns.DB.layout[key] = { p, rp, math.floor(x + 0.5), math.floor(y + 0.5) }
end

local function restorePos(frame, key, default)
    local l = ns.DB and ns.DB.layout and ns.DB.layout[key]
    frame:ClearAllPoints()
    if l then
        frame:SetPoint(l[1], UIParent, l[2], l[3], l[4])
    elseif default then
        frame:SetPoint(default[1], UIParent, default[2], default[3], default[4])
    else
        frame:SetPoint("CENTER")
    end
end
UI.RestorePos = restorePos

-- Register something the player can move in Edit layout mode.
function UI.RegisterMover(frame, key, label, default, onEdit)
    frame:SetMovable(true)
    frame:SetClampedToScreen(true)
    local ov = CreateFrame("Frame", nil, UIParent)
    ov:SetFrameStrata("DIALOG")
    ov:SetAllPoints(frame)
    UI.Flat(ov, { 0.96, 0.55, 0.73, 0.16 }, C.pink, "small")
    local t = UI.Title(ov, 11, { 1, 1, 1, 1 })
    t:SetPoint("CENTER")
    t:SetText(label)
    ov:EnableMouse(true)
    ov:RegisterForDrag("LeftButton")
    ov:SetScript("OnDragStart", function() frame:StartMoving() end)
    ov:SetScript("OnDragStop", function() frame:StopMovingOrSizing(); savePos(frame, key) end)
    ov:Hide()
    movers[key] = { frame = frame, overlay = ov, default = default, onEdit = onEdit }
    if ns.DB then restorePos(frame, key, default) end
end

function UI.ApplyLayout()
    for key, m in pairs(movers) do restorePos(m.frame, key, m.default) end
end

local banner
function UI.SetEditMode(on)
    if on and InCombatLockdown() then
        UI.Toast("Finish your fight first", "Layout can be edited out of combat.")
        return
    end
    editing = on
    if not banner then
        banner = CreateFrame("Frame", "PallyPalEditBanner", UIParent)
        banner:SetSize(460, 52)
        banner:SetPoint("TOP", 0, -24)
        banner:SetFrameStrata("FULLSCREEN_DIALOG")
        UI.Flat(banner, C.bg, { 0.96, 0.55, 0.73, 0.5 }, "panel")
        UI.Shadow(banner)
        local t = UI.Title(banner, 13); t:SetPoint("TOPLEFT", 16, -10); t:SetText("Edit layout")
        local d = UI.Text(banner, 11, C.muted); d:SetPoint("TOPLEFT", t, "BOTTOMLEFT", 0, -2)
        d:SetText("Drag the pink boxes. Windows move by their title bar.")
        local done = UI.Button(banner, 70, 28, "Done", "primary"); done:SetPoint("RIGHT", -12, 0)
        done:SetScript("OnClick", function() UI.SetEditMode(false) end)
        local reset = UI.Button(banner, 70, 28, "Reset", "ghost"); reset:SetPoint("RIGHT", done, "LEFT", -8, 0)
        reset:SetScript("OnClick", function()
            if ns.DB then ns.DB.layout = {} end
            UI.ApplyLayout()
            UI.Toast("Layout reset", "Everything is back in its default spot.")
        end)
    end
    banner:SetShown(on)
    for _, m in pairs(movers) do
        m.overlay:SetShown(on)
        if m.onEdit then m.onEdit(on) end
    end
end
function UI.IsEditing() return editing end

---------------------------------------------------------------------------
-- Windows
---------------------------------------------------------------------------
function UI.Window(name, w, h, title, sub)
    local f = CreateFrame("Frame", name, UIParent)
    f:SetSize(w, h)
    f:SetFrameStrata("HIGH")
    f:SetToplevel(true)
    f:SetClampedToScreen(true)
    f:SetMovable(true)
    f:EnableMouse(true)
    UI.Flat(f, C.bg, C.line2, "panel")
    UI.Shadow(f, 22, 0.55)

    local icon = f:CreateTexture(nil, "ARTWORK")
    icon:SetTexture(MEDIA .. "ghost")
    icon:SetSize(18, 18)
    icon:SetPoint("TOPLEFT", 16, -14)
    icon:SetAlpha(0); icon:SetWidth(1) -- cleaner title bar: no icon
    f.icon = icon
    f.title = UI.Title(f, 14)
    f.title:SetPoint("LEFT", icon, "RIGHT", 2, 0)
    f.title:SetText(title)
    if sub then
        f.sub = UI.Text(f, 11, C.muted)
        f.sub:SetPoint("LEFT", f.title, "RIGHT", 8, 0)
        f.sub:SetText(sub)
    end
    f.divider = UI.Divider(f, -46)
    f.wname = name

    -- drag by the title bar; position is remembered
    local drag = CreateFrame("Frame", nil, f)
    f.drag = drag
    drag:SetPoint("TOPLEFT"); drag:SetPoint("TOPRIGHT", -44, 0); drag:SetHeight(46)
    drag:EnableMouse(true)
    drag:RegisterForDrag("LeftButton")
    drag:SetScript("OnDragStart", function() f:StartMoving() end)
    drag:SetScript("OnDragStop", function() f:StopMovingOrSizing(); savePos(f, "win:" .. name) end)

    local x = CreateFrame("Button", nil, f)
    x:SetSize(26, 26)
    x:SetFrameLevel(drag:GetFrameLevel() + 10)
    x:SetPoint("TOPRIGHT", -12, -10)
    local xb = x:CreateTexture(nil, "BACKGROUND")
    xb:SetTexture(MEDIA .. "circle"); xb:SetAllPoints(); xb:SetVertexColor(1, 1, 1, 0)
    x.t = UI.Text(x, 15, C.muted)
    x.t:SetPoint("CENTER", 0, 1)
    x.t:SetText("×")
    x:SetScript("OnEnter", function() x.t:SetTextColor(1, 1, 1); xb:SetVertexColor(1, 1, 1, 0.08) end)
    x:SetScript("OnLeave", function() x.t:SetTextColor(unpack(C.muted)); xb:SetVertexColor(1, 1, 1, 0) end)
    x:SetScript("OnClick", function() f:Hide() end)
    f.close = x

    -- "Back" arrow: shows when this window was opened from the Pal menu
    local back = CreateFrame("Button", nil, f)
    back:SetSize(30, 30); back:SetPoint("TOPLEFT", 8, -8)
    back:SetFrameLevel(drag:GetFrameLevel() + 10) -- above the drag strip, or it eats the click
    back:RegisterForClicks("LeftButtonUp")
    local bb = back:CreateTexture(nil, "BACKGROUND"); bb:SetTexture(MEDIA .. "circle"); bb:SetAllPoints(); bb:SetVertexColor(1, 1, 1, 0.06)
    back.t = UI.Text(back, 15, C.muted); back.t:SetPoint("CENTER", -1, 1); back.t:SetText("<")
    back:SetScript("OnEnter", function()
        back.t:SetTextColor(1, 1, 1); bb:SetVertexColor(1, 1, 1, 0.14)
        GameTooltip:SetOwner(back, "ANCHOR_BOTTOM"); GameTooltip:AddLine("Back to the Pal menu", 1, 1, 1); GameTooltip:Show()
    end)
    back:SetScript("OnLeave", function() back.t:SetTextColor(unpack(C.muted)); bb:SetVertexColor(1, 1, 1, 0.06); GameTooltip:Hide() end)
    back:SetScript("OnClick", function()
        local x, top = f:GetCenter(), f:GetTop()
        f:Hide()
        if UI.OpenHome then UI.OpenHome(x, top) end
    end)
    back:Hide()
    f.back = back
    -- opened from the Pal menu: show it INSIDE the menu instead of as a popup
    f:HookScript("OnShow", function()
        local into = UI.embedInto
        if into and GetTime() - into.t < 1 and name ~= "PallyPalHome" and not f.embedded then
            UI.embedInto = nil
            UI.Embed(f, into.host)
        end
    end)
    f:HookScript("OnHide", function()
        if not f.embedded then return end
        local host = f.embedded
        if f:IsShown() then f:Hide() end -- the menu closed around it: close the page too
        UI.Unembed(f)
        if host.onPageClosed then host.onPageClosed(f) end
    end)

    f.content = CreateFrame("Frame", nil, f)
    f.content:SetPoint("TOPLEFT", 18, -60)
    f.content:SetPoint("BOTTOMRIGHT", -18, 18)

    -- soft fade + rise when opened
    local ag = f:CreateAnimationGroup()
    local a = ag:CreateAnimation("Alpha"); a:SetFromAlpha(0); a:SetToAlpha(1); a:SetDuration(0.08)
    f:HookScript("OnShow", function() ag:Stop(); ag:Play(); PlaySound(SOUNDKIT and SOUNDKIT.IG_MAINMENU_OPEN or 850) end)
    f:HookScript("OnHide", function() PlaySound(SOUNDKIT and SOUNDKIT.IG_MAINMENU_CLOSE or 851) end)

    restorePos(f, "win:" .. name)
    tinsert(UISpecialFrames, name)
    f:Hide()
    return f
end

-- Put a window inside another frame (the Pal menu) without its own chrome
local CHROME = { "ppFill", "ppEdge", "ppShadow", "close", "back", "drag", "divider" }
function UI.Embed(f, host)
    f.embedded = host
    f:SetParent(host)
    f:ClearAllPoints()
    f:SetPoint("TOPLEFT", host, "TOPLEFT", -14, 6)
    f:SetFrameLevel(host:GetFrameLevel() + 5)
    for _, k in ipairs(CHROME) do if f[k] then f[k]:Hide() end end
    if host.onEmbed then host.onEmbed(f) end
end
function UI.Unembed(f)
    f.embedded = nil
    f:SetParent(UIParent)
    f:SetFrameStrata("HIGH")
    for _, k in ipairs(CHROME) do if f[k] and k ~= "back" then f[k]:Show() end end
    f:ClearAllPoints()
    restorePos(f, "win:" .. (f.wname or ""))
    if f:GetNumPoints() == 0 then f:SetPoint("CENTER") end
end

-- Scroll area (mouse wheel, no Blizzard scrollbar)
function UI.Scroll(parent)
    local sf = CreateFrame("ScrollFrame", nil, parent)
    local child = CreateFrame("Frame", nil, sf)
    child:SetSize(10, 10)
    sf:SetScrollChild(child)
    sf:EnableMouseWheel(true)
    sf:SetScript("OnMouseWheel", function(self, d)
        local max = math.max(0, child:GetHeight() - self:GetHeight())
        self:SetVerticalScroll(math.min(max, math.max(0, self:GetVerticalScroll() - d * 40)))
    end)
    sf:SetScript("OnSizeChanged", function(self, w) child:SetWidth(w) end)
    sf.child = child
    return sf
end

function UI.Search(parent, w, placeholder)
    local e = CreateFrame("EditBox", nil, parent)
    e:SetSize(w, 30)
    UI.Flat(e, { 0.04, 0.045, 0.055, 1 }, C.line2, "small")
    if not e:SetFont(UI.FONT, 12, "") then e:SetFont(STANDARD_TEXT_FONT, 12, "") end
    e:SetTextColor(1, 1, 1)
    e:SetTextInsets(12, 12, 0, 0)
    e:SetAutoFocus(false)
    e:SetScript("OnEscapePressed", e.ClearFocus)
    e:SetScript("OnEnterPressed", e.ClearFocus)
    e:SetScript("OnEditFocusGained", function(s) s:SetBackdropBorderColor(unpack(C.pink)) end)
    e:SetScript("OnEditFocusLost", function(s) s:SetBackdropBorderColor(unpack(C.line2)) end)
    local ph = UI.Text(e, 12, C.muted)
    ph:SetPoint("LEFT", 12, 0)
    ph:SetText(placeholder)
    e:HookScript("OnTextChanged", function(s) ph:SetShown(s:GetText() == "") end)
    return e
end

---------------------------------------------------------------------------
-- Toast popup (movable in Edit layout)
---------------------------------------------------------------------------
local toast
local function ensureToast()
    if toast then return toast end
    toast = CreateFrame("Frame", "PallyPalToast", UIParent)
    toast:SetSize(320, 54)
    toast:SetFrameStrata("MEDIUM")
    UI.Flat(toast, C.bg, C.line2, "panel")
    UI.Shadow(toast, 22, 0.75)
    toast.icon = UI.Ghost(toast, 30)
    toast.icon:SetPoint("LEFT", 12, 0)
    toast.icon:EnableMouse(false)
    toast.msg = UI.Title(toast, 12)
    toast.msg:SetPoint("TOPLEFT", toast.icon, "TOPRIGHT", 12, 0)
    toast.msg:SetPoint("RIGHT", -14, 0)
    toast.msg:SetWordWrap(false)
    toast.sub = UI.Text(toast, 11, C.muted)
    toast.sub:SetPoint("TOPLEFT", toast.msg, "BOTTOMLEFT", 0, -3)
    toast.sub:SetPoint("RIGHT", -14, 0)
    local ag = toast:CreateAnimationGroup()
    local fin = ag:CreateAnimation("Alpha"); fin:SetFromAlpha(0); fin:SetToAlpha(1); fin:SetDuration(0.2); fin:SetOrder(1)
    local rise = ag:CreateAnimation("Translation"); rise:SetOffset(0, 8); rise:SetDuration(0.25); rise:SetSmoothing("OUT"); rise:SetOrder(1)
    local hold = ag:CreateAnimation("Alpha"); hold:SetFromAlpha(1); hold:SetToAlpha(1); hold:SetDuration(4); hold:SetOrder(2)
    local fout = ag:CreateAnimation("Alpha"); fout:SetFromAlpha(1); fout:SetToAlpha(0); fout:SetDuration(0.5); fout:SetOrder(3)
    ag:SetScript("OnFinished", function() if not editing then toast:Hide() end end)
    toast.ag = ag
    toast:Hide()
    UI.RegisterMover(toast, "toast", "Popups", { "TOP", "TOP", 0, -210 }, function(on)
        if on then
            toast.ag:Stop(); toast:SetAlpha(1)
            toast.msg:SetText("Popups show up here"); toast.sub:SetText("Level ups, lessons, new quests")
            toast:Show()
        else
            toast:Hide()
        end
    end)
    return toast
end
UI.EnsureToast = ensureToast

function UI.Toast(msg, sub)
    local t = ensureToast()
    t.msg:SetText(msg)
    t.sub:SetText(sub or "")
    t:SetHeight(sub and sub ~= "" and 56 or 44)
    t:Show()
    t.ag:Stop(); t.ag:Play()
    C_Timer.After(0.2, function() t.icon:Hop() end)
end

-- Called once saved variables are loaded
function UI.Init(db)
    ns.DB = db
    db.layout = db.layout or {}
    ensureToast()
    UI.ApplyLayout()
end

---------------------------------------------------------------------------
-- Ghost Pal: animated mascot (float, blink, drop-in, hop, wiggle).
-- Every frame his position is worked out from scratch inside his own box,
-- so nothing can pile up and he can never wander off.
---------------------------------------------------------------------------
local MEDIA_G = "Interface\\AddOns\\PallyPal\\Media\\"

function UI.Ghost(parent, size)
    local g = CreateFrame("Button", nil, parent)
    g:SetSize(size, size)

    local shadow = g:CreateTexture(nil, "BACKGROUND")
    shadow:SetTexture(MEDIA_G .. "shadow")
    shadow:SetPoint("BOTTOM", g, "BOTTOM", 0, -size * 0.04)

    local body = g:CreateTexture(nil, "ARTWORK")
    body:SetTexture(MEDIA_G .. "ghost")
    local blink = g:CreateTexture(nil, "ARTWORK")
    blink:SetTexture(MEDIA_G .. "ghost_blink")
    blink:Hide()
    g.tex, g.blink, g.shadow = body, blink, shadow

    local t0 = GetTime() + math.random() * 3
    local dropT, hopT, wigT
    local blinkEnd, nextBlink = 0, GetTime() + 2 + math.random() * 3

    local function place(y, sx, sy, rot, alpha)
        -- keep him inside his box no matter what
        y = math.max(-size * 0.05, math.min(size * 0.75, y))
        sx = math.max(0.7, math.min(1.3, sx)); sy = math.max(0.7, math.min(1.3, sy))
        local t = body:IsShown() and body or blink
        t:SetPoint("BOTTOM", g, "BOTTOM", 0, y) -- same anchor point: replaces, no relayout of the others
        t:SetSize(size * sx, size * sy)
        if t.SetRotation then t:SetRotation(rot) end
        t:SetAlpha(alpha)
        local lift = math.min(1, y / (size * 0.75))
        shadow:SetSize(size * 0.8 * (1 - lift * 0.45), size * 0.2 * (1 - lift * 0.45))
        shadow:SetAlpha(alpha * (1 - lift * 0.5))
    end

    local acc = 0
    g:SetScript("OnUpdate", function(_, el)
        acc = acc + (el or 0)
        if acc < 0.033 then return end -- 30 updates a second is plenty for a little ghost
        acc = 0
        local now = GetTime()
        -- gentle float
        local y = (math.sin((now - t0) * 2.2) + 1) * size * 0.035
        local sx, sy, rot, alpha = 1, 1, 0, 1
        -- drop in: fall, squash, settle
        if dropT then
            local p = (now - dropT) / 0.6
            if p >= 1 or p < 0 then dropT = nil
            elseif p < 0.45 then
                local q = p / 0.45
                y = y + size * 0.6 * (1 - q * q)
                alpha = math.min(1, q * 3)
            else
                local q = (p - 0.45) / 0.55
                local k = math.sin(q * math.pi) * (1 - q)
                sx, sy = 1 + 0.2 * k, 1 - 0.2 * k
            end
        end
        -- hop: jump up, squash on landing
        if hopT then
            local p = (now - hopT) / 0.5
            if p >= 1 or p < 0 then hopT = nil
            elseif p < 0.6 then
                local q = p / 0.6
                y = y + size * 0.22 * 4 * q * (1 - q)
            else
                local q = (p - 0.6) / 0.4
                sx, sy = 1 + 0.14 * (1 - q), 1 - 0.14 * (1 - q)
            end
        end
        -- wiggle: little shake
        if wigT then
            local p = (now - wigT) / 0.35
            if p >= 1 or p < 0 then wigT = nil
            else rot = math.sin(p * math.pi * 4) * 0.18 * (1 - p) end
        end
        -- blink every few seconds
        if now >= nextBlink then blinkEnd = now + 0.12; nextBlink = now + 2.5 + math.random() * 3.5 end
        local closed = now < blinkEnd
        body:SetShown(not closed); blink:SetShown(closed)
        place(y, sx, sy, rot, alpha)
    end)

    function g:Hop() if not hopT then hopT = GetTime() end end
    function g:Drop() dropT = GetTime(); hopT = nil end
    function g:Wiggle() wigT = GetTime() end
    g:SetScript("OnEnter", function(self) self:Hop() end)
    place(0, 1, 1, 0, 1)
    return g
end

-- Put a window at a default spot unless the player already moved it
function UI.DefaultPos(f, point, x, y)
    local key = "win:" .. (f:GetName() or "")
    if ns.DB and ns.DB.layout and ns.DB.layout[key] then return end
    f:ClearAllPoints()
    f:SetPoint(point, UIParent, point, x, y)
end
