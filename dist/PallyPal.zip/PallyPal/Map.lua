-- PallyPal Map pins: every flight path on top of the normal world map and
-- minimap. Nothing of the game's own map is changed or hidden: the pins are a
-- separate layer you can switch off any time (Settings > Map, or the
-- "Pal pins" button in the corner of the world map).
--
--   Pink ring (pulsing) ... a flight path you haven't learned yet, go get it
--   Grey ring ............. already learned
--
-- Open any flight master once and Pal remembers EVERY flight path on that
-- continent, including the ones you haven't found yet, so they show up too.
-- "Flights to learn" (map button or /pal flights) lists the missing ones.
-- Click a pin to drop the game's own waypoint arrow on it. Right-click clears it.
local ADDON, ns = ...
local UI = ns.UI
local DB

local MEDIA = "Interface\\AddOns\\PallyPal\\Media\\"
local TOP_QUESTS = 5

local function ret(ok, ...) if ok then return ... end end
local function safe(f, ...)
    if not f then return end
    return ret(pcall(f, ...))
end
local function secret(v) return issecretvalue and issecretvalue(v) end

---------------------------------------------------------------------------
-- Flight paths you know (learned when you open any flight master map)
---------------------------------------------------------------------------
local function rememberFlightPaths()
    local mapID = safe(GetTaxiMapID)
    local nodes = mapID and safe(C_TaxiMap and C_TaxiMap.GetAllTaxiNodes, mapID) or {}
    local unreachable = Enum.FlightPathState and Enum.FlightPathState.Unreachable or 2
    DB.knownFP = DB.knownFP or {}
    DB.fpAll = DB.fpAll or {}
    for _, n in ipairs(nodes) do
        if n.nodeID and n.state ~= nil then
            local known = n.state ~= unreachable
            if known then
                DB.knownFP[n.nodeID] = true
                if n.name then DB.knownFP[n.name] = true end
            end
            local pos = n.position
            if pos and pos.x and pos.x > 0 then
                DB.fpAll[n.nodeID] = { name = n.name, x = pos.x, y = pos.y, map = mapID }
            end
        end
    end
    DB.fpChecked = true
end

-- move a point from one map to another (continent <-> zone) through world coordinates
local function convert(fromMap, x, y, toMap)
    if fromMap == toMap then return x, y end
    if not (C_Map.GetWorldPosFromMapPos and C_Map.GetMapPosFromWorldPos and CreateVector2D) then return end
    local cont, world = safe(C_Map.GetWorldPosFromMapPos, fromMap, CreateVector2D(x, y))
    if not cont or not world then return end
    local _, pos = safe(C_Map.GetMapPosFromWorldPos, cont, world, toMap)
    if pos and pos.x and pos.x >= 0 and pos.x <= 1 and pos.y >= 0 and pos.y <= 1 then return pos.x, pos.y end
end

local function fpKnown(n)
    if not DB.knownFP then return nil end
    return DB.knownFP[n.nodeID] or (n.name and DB.knownFP[n.name]) or false
end

---------------------------------------------------------------------------
-- Collect everything worth pinning on one map
---------------------------------------------------------------------------
local function collect(mapID)
    local out, seen = {}, {}
    if not mapID or not DB.mapFlights then return out end
    local enemy = (UnitFactionGroup("player") == "Horde") and 2 or 1 -- Enum.FlightPathFaction: 1 Horde, 2 Alliance
    -- what the game itself knows about this map
    for _, n in ipairs(safe(C_TaxiMap and C_TaxiMap.GetTaxiNodesForMap, mapID) or {}) do
        local pos = n.position
        if pos and pos.x and n.faction ~= enemy then
            seen[n.nodeID or n.name] = true
            if n.name then seen[n.name] = true end
            table.insert(out, { kind = "fp", x = pos.x, y = pos.y, name = n.name or "Flight path", known = fpKnown(n) })
        end
    end
    -- plus every flight path Pal saw on a flight master's map (finds the hidden ones)
    for id, f in pairs(DB.fpAll or {}) do
        if not seen[id] and not (f.name and seen[f.name]) then
            local x, y = convert(f.map, f.x, f.y, mapID)
            if x then
                table.insert(out, { kind = "fp", x = x, y = y, name = f.name or "Flight path", known = fpKnown({ nodeID = id, name = f.name }) })
            end
        end
    end
    return out
end

---------------------------------------------------------------------------
-- Pin widget (shared look for world map and minimap)
---------------------------------------------------------------------------
local PINK = { 0.96, 0.55, 0.73 }

local function setAtlasOr(tex, atlas, file)
    if not (atlas and tex.SetAtlas and pcall(tex.SetAtlas, tex, atlas)) or not tex:GetAtlas() then
        tex:SetTexture(file)
    end
end

local function newPin(parent, size)
    local p = CreateFrame("Button", nil, parent)
    p:SetSize(size, size)
    p:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    p.ring = p:CreateTexture(nil, "BACKGROUND")
    p.ring:SetTexture(MEDIA .. "circle"); p.ring:SetAllPoints()
    p.bg = p:CreateTexture(nil, "BORDER")
    p.bg:SetTexture(MEDIA .. "circle"); p.bg:SetPoint("TOPLEFT", 2, -2); p.bg:SetPoint("BOTTOMRIGHT", -2, 2)
    p.bg:SetVertexColor(0.08, 0.085, 0.1, 0.95)
    p.icon = p:CreateTexture(nil, "ARTWORK")
    p.icon:SetPoint("TOPLEFT", 4, -4); p.icon:SetPoint("BOTTOMRIGHT", -4, 4)
    p.num = p:CreateFontString(nil, "OVERLAY")
    if not p.num:SetFont(UI.FONT_B or STANDARD_TEXT_FONT, math.floor(size * 0.55), "") then p.num:SetFont(STANDARD_TEXT_FONT, math.floor(size * 0.55), "") end
    p.num:SetPoint("CENTER", 0, 0)
    -- soft pulse for "go here" pins
    p.glow = p:CreateTexture(nil, "BACKGROUND", nil, -1)
    p.glow:SetTexture(MEDIA .. "circle"); p.glow:SetPoint("CENTER"); p.glow:SetSize(size * 1.7, size * 1.7)
    p.glow:SetVertexColor(PINK[1], PINK[2], PINK[3], 0.25)
    local ag = p.glow:CreateAnimationGroup(); ag:SetLooping("BOUNCE")
    local a = ag:CreateAnimation("Alpha"); a:SetFromAlpha(0.15); a:SetToAlpha(0.6); a:SetDuration(0.9)
    p.pulse = ag

    p:SetScript("OnEnter", function(self) ns.MapPinTooltip(self) end)
    p:SetScript("OnLeave", function() GameTooltip:Hide() end)
    p:SetScript("OnClick", function(self, btn) ns.MapPinClick(self, btn) end)
    return p
end

local function style(p, d)
    p.data = d
    p.num:SetText(""); p.icon:Show(); p.glow:Hide(); p.pulse:Stop()
    p.icon:SetTexCoord(0, 1, 0, 1); p.icon:SetVertexColor(1, 1, 1)
    if d.kind == "fp" then
        setAtlasOr(p.icon, "TaxiNode_Neutral", "Interface\\Minimap\\Tracking\\FlightMaster")
        if d.known == false then
            p.ring:SetVertexColor(PINK[1], PINK[2], PINK[3], 1)
            p.glow:Show(); p.pulse:Play()
        else
            p.ring:SetVertexColor(0.45, 0.47, 0.52, 1)
        end
    elseif d.kind == "avail" then
        setAtlasOr(p.icon, "QuestNormal", "Interface\\GossipFrame\\AvailableQuestIcon")
        p.ring:SetVertexColor(1, 0.82, 0.2, 1)
    elseif d.kind == "turnin" then
        setAtlasOr(p.icon, "QuestTurnin", "Interface\\GossipFrame\\ActiveQuestIcon")
        p.ring:SetVertexColor(1, 0.82, 0.2, 1)
        p.glow:SetVertexColor(1, 0.82, 0.2, 0.3); p.glow:Show(); p.pulse:Play()
    elseif d.kind == "top" then
        p.icon:Hide()
        p.ring:SetVertexColor(PINK[1], PINK[2], PINK[3], 1)
        p.num:SetText(d.rank); p.num:SetTextColor(1, 1, 1)
    end
    if d.kind ~= "turnin" then p.glow:SetVertexColor(PINK[1], PINK[2], PINK[3], 0.25) end
end

function ns.MapPinTooltip(p)
    local d = p.data; if not d then return end
    GameTooltip:SetOwner(p, "ANCHOR_RIGHT")
    if d.kind == "fp" then
        GameTooltip:AddLine(d.name, 1, 1, 1)
        if d.known == false then
            GameTooltip:AddLine("Flight path you haven't learned yet.", PINK[1], PINK[2], PINK[3])
            GameTooltip:AddLine("Talk to the flight master here once to unlock it.", 0.8, 0.8, 0.8, true)
        elseif d.known then
            GameTooltip:AddLine("Flight path (learned)", 0.6, 0.6, 0.65)
        else
            GameTooltip:AddLine("Flight path", 0.6, 0.6, 0.65)
            GameTooltip:AddLine("Open any flight master once and Pal will mark which ones you still need.", 0.8, 0.8, 0.8, true)
        end
    elseif d.kind == "avail" then
        GameTooltip:AddLine(d.name, 1, 0.82, 0.2)
        GameTooltip:AddLine("New quest you can pick up here.", 0.8, 0.8, 0.8)
        if d.line and d.line ~= d.name then GameTooltip:AddLine("Story: " .. d.line, 0.6, 0.6, 0.65) end
    elseif d.kind == "turnin" then
        GameTooltip:AddLine(d.name, 1, 0.82, 0.2)
        GameTooltip:AddLine("Done! Turn it in here.", 0.4, 0.9, 0.5)
    elseif d.kind == "top" then
        GameTooltip:AddLine("#" .. d.rank .. "  " .. d.name, 1, 1, 1)
        GameTooltip:AddLine((d.why or "") .. "  (PallyPal priority)", PINK[1], PINK[2], PINK[3])
    end
    GameTooltip:AddLine(" ")
    GameTooltip:AddLine("Click: show the arrow to here.  Right-click: clear it.", 0.55, 0.55, 0.6, true)
    GameTooltip:Show()
end

function ns.MapPinClick(p, btn)
    local d = p.data; if not d then return end
    if btn == "RightButton" then
        safe(C_Map.ClearUserWaypoint); return
    end
    local mapID = p.mapID
    if mapID and C_Map.CanSetUserWaypointOnMap and safe(C_Map.CanSetUserWaypointOnMap, mapID) and UiMapPoint then
        local pt = safe(UiMapPoint.CreateFromCoordinates, mapID, d.x, d.y)
        if pt then
            safe(C_Map.SetUserWaypoint, pt)
            if C_SuperTrack then safe(C_SuperTrack.SetSuperTrackedUserWaypoint, true) end
        end
    end
    if d.id and (d.kind == "top" or d.kind == "turnin") then
        safe(C_QuestLog.AddQuestWatch, d.id)
        if C_SuperTrack then safe(C_SuperTrack.SetSuperTrackedQuestID, d.id) end
    end
    PlaySound(SOUNDKIT and SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON or 856)
end

---------------------------------------------------------------------------
-- World map layer
---------------------------------------------------------------------------
local world = { pins = {}, scale = 0 }

local function worldRefresh()
    local layer = world.layer
    if not layer then return end
    for _, p in ipairs(world.pins) do p:Hide() end
    if not DB.mapPins or not WorldMapFrame:IsShown() then return end
    local mapID = WorldMapFrame:GetMapID()
    local child = WorldMapFrame.ScrollContainer.Child
    local w, h = child:GetWidth(), child:GetHeight()
    local cs = safe(WorldMapFrame.ScrollContainer.GetCanvasScale, WorldMapFrame.ScrollContainer) or 1
    local s = 1 / math.max(0.2, cs)
    world.scale = cs
    for i, d in ipairs(collect(mapID)) do
        local p = world.pins[i] or newPin(layer, 22)
        world.pins[i] = p
        style(p, d)
        p.mapID = mapID
        p:SetScale(s)
        p:ClearAllPoints()
        p:SetPoint("CENTER", layer, "TOPLEFT", d.x * w / s, -d.y * h / s)
        p:SetFrameLevel(layer:GetFrameLevel() + (d.kind == "top" and 30 or d.kind == "turnin" and 20 or 10))
        p:Show()
    end
end

local function buildWorld()
    if world.layer or not WorldMapFrame or not WorldMapFrame.ScrollContainer then return end
    local child = WorldMapFrame.ScrollContainer.Child
    local layer = CreateFrame("Frame", "PallyPalMapLayer", child)
    layer:SetAllPoints(child)
    layer:SetFrameStrata("HIGH")
    world.layer = layer
    -- zooming changes the canvas scale: keep pins the same size on screen
    layer:SetScript("OnUpdate", function(self, el)
        self.t = (self.t or 0) + el
        if self.t < 0.1 then return end
        self.t = 0
        local cs = safe(WorldMapFrame.ScrollContainer.GetCanvasScale, WorldMapFrame.ScrollContainer) or 1
        if math.abs(cs - world.scale) > 0.001 then worldRefresh() end
    end)
    hooksecurefunc(WorldMapFrame, "OnMapChanged", function() C_Timer.After(0, worldRefresh) end)
    WorldMapFrame:HookScript("OnShow", function() C_Timer.After(0, worldRefresh) end)

    -- small on/off pill in the bottom left corner of the map
    local b = CreateFrame("Button", nil, WorldMapFrame.ScrollContainer)
    b:SetSize(96, 24); b:SetPoint("BOTTOMLEFT", 10, 10)
    b:SetFrameStrata("HIGH"); b:SetFrameLevel(layer:GetFrameLevel() + 50)
    UI.Flat(b, { 0.08, 0.085, 0.1, 0.92 }, { 1, 1, 1, 0.12 }, "pill")
    b.dot = b:CreateTexture(nil, "ARTWORK"); b.dot:SetTexture(MEDIA .. "circle"); b.dot:SetSize(8, 8); b.dot:SetPoint("LEFT", 10, 0)
    b.t = UI.Text(b, 11); b.t:SetPoint("LEFT", b.dot, "RIGHT", 7, 0)
    local function paint()
        b.t:SetText(DB.mapPins and "Pal pins" or "Pal pins off")
        b.dot:SetVertexColor(DB.mapPins and PINK[1] or 0.4, DB.mapPins and PINK[2] or 0.4, DB.mapPins and PINK[3] or 0.45)
    end
    b:SetScript("OnClick", function() DB.mapPins = not DB.mapPins; paint(); worldRefresh(); ns.RefreshMapPins() end)
    b:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:AddLine("PallyPal map pins", 1, 1, 1)
        GameTooltip:AddLine("Pink ring: flight path to learn", PINK[1], PINK[2], PINK[3])
        GameTooltip:AddLine("Grey ring: flight path you have", 0.6, 0.6, 0.65)
        GameTooltip:AddLine("Click to turn them on or off.", 0.55, 0.55, 0.6)
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)
    world.toggle = b

    -- second pill: list of flight paths you still need
    local f = CreateFrame("Button", nil, WorldMapFrame.ScrollContainer)
    f:SetSize(150, 24); f:SetPoint("LEFT", b, "RIGHT", 6, 0)
    f:SetFrameStrata("HIGH"); f:SetFrameLevel(layer:GetFrameLevel() + 50)
    UI.Flat(f, { 0.08, 0.085, 0.1, 0.92 }, { 0.96, 0.55, 0.73, 0.5 }, "pill")
    f.t = UI.Text(f, 11); f.t:SetPoint("CENTER")
    f:SetScript("OnClick", function() ns.ToggleFlights() end)
    f:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:AddLine("Flight paths to learn", 1, 1, 1)
        GameTooltip:AddLine("Every flight path on this continent you haven't picked up yet. Click one to get an arrow to it.", 0.8, 0.8, 0.8, true)
        GameTooltip:Show()
    end)
    f:SetScript("OnLeave", function() GameTooltip:Hide() end)
    world.flights = f

    world.paint = function()
        paint()
        local n = ns.MissingFlights and #ns.MissingFlights() or 0
        f.t:SetText(DB.fpChecked and ("Flights to learn: " .. n) or "Flights to learn")
        f:SetWidth((f.t:GetStringWidth() or 120) + 28)
    end
    world.paint()
end

---------------------------------------------------------------------------
-- Flights to learn: every unlearned flight path on your continent
---------------------------------------------------------------------------
local function continentOf(mapID)
    local cont = Enum.UIMapType and Enum.UIMapType.Continent or 2
    local guard = 0
    while mapID and guard < 10 do
        local info = safe(C_Map.GetMapInfo, mapID)
        if not info then return end
        if info.mapType == cont then return mapID end
        mapID = info.parentMapID; guard = guard + 1
    end
end

function ns.MissingFlights()
    local out = {}
    if not DB or not DB.fpChecked then return out end
    local here = safe(C_Map.GetBestMapForUnit, "player")
    local cont = continentOf(here)
    local pos = here and safe(C_Map.GetPlayerMapPosition, here, "player")
    local px, py
    if pos and pos.x and not secret(pos.x) and cont then px, py = convert(here, pos.x, pos.y, cont) end
    for id, f in pairs(DB.fpAll or {}) do
        if not DB.knownFP[id] and not (f.name and DB.knownFP[f.name]) and (not cont or f.map == cont) then
            local zone = safe(C_Map.GetMapInfoAtPosition, f.map, f.x, f.y)
            local d = (px and ((f.x - px) ^ 2 + (f.y - py) ^ 2) ^ 0.5) or 9
            table.insert(out, { id = id, name = f.name or "Flight path", x = f.x, y = f.y, map = f.map, zone = zone and zone.name, zoneID = zone and zone.mapID, d = d })
        end
    end
    table.sort(out, function(a, b) return a.d < b.d end)
    return out
end

local function waypointTo(e)
    local mapID, x, y = e.zoneID, nil, nil
    if mapID then x, y = convert(e.map, e.x, e.y, mapID) end
    if not x then mapID, x, y = e.map, e.x, e.y end
    if UiMapPoint and safe(C_Map.CanSetUserWaypointOnMap, mapID) then
        local pt = safe(UiMapPoint.CreateFromCoordinates, mapID, x, y)
        if pt then
            safe(C_Map.SetUserWaypoint, pt)
            if C_SuperTrack then safe(C_SuperTrack.SetSuperTrackedUserWaypoint, true) end
            if ns.Alert then ns.Alert("Arrow set: " .. e.name, e.zone or "") end
        end
    end
end

local fwin
local function fillFlights()
    if not fwin or not fwin:IsShown() then return end
    local list = ns.MissingFlights()
    for _, r in ipairs(fwin.rows) do r:Hide() end
    if not DB.fpChecked then
        fwin.empty:SetText("Talk to any flight master once (open their map) and Pal will remember every flight path on the continent, including the ones you haven't found yet.")
        fwin.empty:Show(); return
    end
    fwin.empty:SetShown(#list == 0)
    fwin.empty:SetText("You have every flight path Pal knows about on this continent. Nice!")
    for i, e in ipairs(list) do
        local r = fwin.rows[i]
        if not r then
            r = CreateFrame("Button", nil, fwin.body); r:SetHeight(40)
            r:SetPoint("TOPLEFT", 0, -(i - 1) * 42); r:SetPoint("RIGHT")
            UI.Flat(r, { 1, 1, 1, 0.03 }, { 1, 1, 1, 0.06 }, "small")
            r.ic = r:CreateTexture(nil, "ARTWORK"); r.ic:SetSize(22, 22); r.ic:SetPoint("LEFT", 10, 0)
            setAtlasOr(r.ic, "TaxiNode_Neutral", "Interface\\Minimap\\Tracking\\FlightMaster")
            r.t = UI.Title(r, 12); r.t:SetPoint("TOPLEFT", r.ic, "TOPRIGHT", 10, 2); r.t:SetPoint("RIGHT", -90, 0); r.t:SetJustifyH("LEFT"); r.t:SetWordWrap(false)
            r.s = UI.Text(r, 10, UI.C.muted); r.s:SetPoint("TOPLEFT", r.t, "BOTTOMLEFT", 0, -2)
            r.go = UI.Text(r, 11, UI.C.pink); r.go:SetPoint("RIGHT", -12, 0); r.go:SetText("Show me")
            r:SetScript("OnEnter", function(self) self:SetBackdropColor(0.96, 0.55, 0.73, 0.1) end)
            r:SetScript("OnLeave", function(self) self:SetBackdropColor(1, 1, 1, 0.03) end)
            fwin.rows[i] = r
        end
        r.t:SetText(e.name); r.s:SetText(e.zone or "")
        r:SetScript("OnClick", function() waypointTo(e) end)
        r:Show()
    end
    fwin.body:SetHeight(#list * 42 + 4)
end

function ns.ToggleFlights()
    if not fwin then
        local f = UI.Window("PallyPalFlights", 360, 440, "Flights to learn", "closest first")
        local sf = UI.Scroll(f.content); sf:SetPoint("TOPLEFT"); sf:SetPoint("BOTTOMRIGHT")
        if sf.SetClipsChildren then sf:SetClipsChildren(true) end
        f.body = sf.child; f.rows = {}
        f.empty = UI.Text(f.content, 12, UI.C.muted); f.empty:SetPoint("TOPLEFT"); f.empty:SetPoint("RIGHT"); f.empty:SetJustifyH("LEFT")
        f:HookScript("OnShow", function() C_Timer.After(0, fillFlights) end)
        fwin = f
    end
    fwin:SetShown(not fwin:IsShown())
end

---------------------------------------------------------------------------
-- Minimap layer: only pins near you (flight paths to learn, quests)
---------------------------------------------------------------------------
-- minimap diameter in yards per zoom level (same numbers every map addon uses)
local OUTDOOR = { [0] = 466 + 2 / 3, 400, 333 + 1 / 3, 266 + 2 / 3, 200, 133 + 1 / 3 }
local INDOOR  = { [0] = 300, 240, 180, 120, 80, 50 }

local mini = { pins = {}, data = {}, mapID = nil }

local function miniCollect()
    local mapID = safe(C_Map.GetBestMapForUnit, "player")
    mini.mapID = mapID
    local list = {}
    for _, d in ipairs(collect(mapID)) do
        if not (d.kind == "fp" and d.known ~= false) then table.insert(list, d) end -- skip flight paths you already have
    end
    mini.data = list
    mini.size = mapID and { safe(C_Map.GetMapWorldSize, mapID) } or {}
end

local function miniUpdate()
    for _, p in ipairs(mini.pins) do if p:IsShown() then p:Hide() end end
    if not (DB.miniPins and DB.mapPins) or not mini.mapID or not Minimap:IsVisible() then return end
    local W, H = mini.size[1], mini.size[2]
    if not W or W == 0 then return end
    local pos = safe(C_Map.GetPlayerMapPosition, mini.mapID, "player")
    if not pos then return end
    local px, py = pos.x, pos.y
    if not px or secret(px) or secret(py) then return end
    local zoom = Minimap:GetZoom()
    local indoors = tonumber(GetCVar("minimapZoom") or "0") ~= zoom -- same trick other map addons use
    local yards = ((indoors and INDOOR or OUTDOOR)[zoom] or 300) / 2
    local radius = Minimap:GetWidth() / 2
    local rotate = GetCVar("rotateMinimap") == "1"
    local facing = rotate and safe(GetPlayerFacing) or nil
    if facing and secret(facing) then facing = nil end
    local n = 0
    for _, d in ipairs(mini.data) do
        local dx = (d.x - px) * W           -- yards east
        local dy = -(d.y - py) * H          -- yards north
        if facing then
            local c, s = math.cos(-facing), math.sin(-facing)
            dx, dy = dx * c - dy * s, dx * s + dy * c
        end
        local dist = math.sqrt(dx * dx + dy * dy)
        if dist < yards * 0.92 then
            n = n + 1
            local p = mini.pins[n] or newPin(Minimap, 16)
            mini.pins[n] = p
            if p.data ~= d then style(p, d) end
            p.mapID = mini.mapID
            p:ClearAllPoints()
            p:SetPoint("CENTER", Minimap, "CENTER", dx / yards * radius, dy / yards * radius)
            p:SetFrameLevel(Minimap:GetFrameLevel() + 6)
            p:Show()
        end
    end
end

---------------------------------------------------------------------------
-- Refresh + events
---------------------------------------------------------------------------
ns.MapCollect = function(id) return collect(id) end
function ns.RefreshMapPins()
    if not DB then return end
    miniCollect(); miniUpdate()
    if WorldMapFrame and WorldMapFrame:IsShown() then worldRefresh() end
    if world.paint then world.paint() end
    fillFlights()
end

local pending
local function soon()
    if pending then return end
    pending = true
    C_Timer.After(1.5, function() pending = false; if not InCombatLockdown() then ns.RefreshMapPins() end end)
end

local ev = CreateFrame("Frame")
ev:SetScript("OnEvent", function(_, event, ...)
    if event == "ADDON_LOADED" then
        if ... == "Blizzard_WorldMap" then buildWorld() end
        return
    end
    if event == "TAXIMAP_OPENED" then rememberFlightPaths() end
    soon()
end)

local prevSlash = ns.HandleSlash
function ns.HandleSlash(msg)
    if msg == "flights" or msg == "fp" or msg == "flight" then ns.ToggleFlights(); return true end
    return prevSlash and prevSlash(msg) or false
end

local prevInit = ns.InitLearn
function ns.InitLearn(db)
    if prevInit then prevInit(db) end
    DB = db
    for k, v in pairs({ mapPins = true, mapFlights = true, miniPins = true }) do
        if DB[k] == nil then DB[k] = v end
    end
    if WorldMapFrame then buildWorld() end
    for _, e in ipairs({ "ADDON_LOADED", "PLAYER_ENTERING_WORLD", "ZONE_CHANGED_NEW_AREA", "ZONE_CHANGED", "TAXIMAP_OPENED", "PLAYER_LEVEL_UP", "MINIMAP_UPDATE_ZOOM" }) do
        pcall(ev.RegisterEvent, ev, e)
    end
    -- minimap pins move as you walk: cheap update 10 times a second
    local t = 0
    local f = CreateFrame("Frame")
    f:SetScript("OnUpdate", function(_, el)
        t = t + el
        if t < 0.2 then return end
        t = 0
        if #mini.data > 0 then miniUpdate() end
    end)
    C_Timer.After(3, ns.RefreshMapPins)
end
